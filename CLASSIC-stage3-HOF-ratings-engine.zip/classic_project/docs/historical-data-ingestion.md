# Historical data ingestion contract

CLASSIC must not publish a season rating unless the player-season total is sourced and verified. The initial rating engine expects one record per player-season with: `playerId`, `canonicalId`, `season`, `position`, `pprFantasyPoints`, `sourceUrl`, and `verified`. A cohort must contain at least 10 verified records for the same season and position.

Recommended next ingestion format is CSV with those columns plus the underlying passing/rushing/receiving/kicking/defensive components, `dataProvider`, `retrievedAt`, and `completeness`. Preserve source attribution per record. Do not merge missing stat categories as zero. Distinguish true zero from unavailable.

The official Pro Football Hall of Fame enshrinement roster is used for Hall of Fame membership, not for statistical performance: https://www.profootballhof.com/hall-of-famers/years.

The official NFL stats pages and reputable historical archives may be used as source candidates, subject to access/licensing review. No third-party dataset should be silently treated as official.
