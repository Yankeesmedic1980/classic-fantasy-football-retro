# Mock Draft Lab — implementation report

## Scope and safety

Mock Draft Lab is part of CLASSIC at `/mock-lab` and `/mock-lab/:id`; it is not a separate app or a local-only mockup. Sessions, seats, player snapshots, private queues, picks, activity, status, and deadlines are persisted in PostgreSQL.

The live league schema, live draft routes and mutation engine, and permanent identity-lock code were not modified. The only use of a real league by the new feature is a membership-authorized **read** to copy its approved, retired, non-sample player records. Later changes to that league do not change an existing mock's snapshot.

## Implemented behavior

- Four, six, eight, ten, or twelve teams; fifteen-round snake draft.
- Randomized order using server-side randomness, or manually arranged order.
- Human/CPU seat configuration and a selectable human seat for the host.
- Private invitation codes and links; authenticated participants only. Invitations fill the first open human seat before the draft starts. Rejoining is idempotent.
- Untimed human picks, or a configurable five-to-600-second clock. Expired human picks use the manager's queue first, then the configured basic heuristic.
- Two deterministic CPU strategies: **needs** prioritizes unfilled starting positions by remaining need; **balanced** takes the first snapshot entry filling a starting slot, then the bench. Neither uses statistical rankings or predictive AI.
- CPU picks, human picks, deadline catch-up, queues, joining, and host controls share a transaction serialized by the mock session's database row lock.
- Searchable player-season pool with name, NFL team, season, and position; current/upcoming picks; full snake board; activity; all team rosters.
- Persisted private queues with reordering/removal. Other participants cannot see another manager's queue, including through export.
- Identity exclusion applies to every season of the selected canonical identity within that mock. A separate mock can independently select the same identity.
- Three-second polling, matching CLASSIC's existing synchronization approach; not WebSockets or online presence.
- Host start, pause, resume, and restart. All human seats must be filled and the pool must have enough eligible identities and positions before starting.
- Restart creates a **new** private session, retains members/settings/pool, and preserves all original picks/results. An unfinished original is paused instead of continuing to make unexpected picks.
- Completed results/history and participant-only JSON export.
- Responsive setup and room pages, with horizontal scrolling inside the large board/pool where needed.

## Database changes

Added only:

1. `classic_mock_sessions`
   - Session ID, unique invite code, JSONB session document, creation time, next automated-action timestamp.
   - Due-action index for persistent clock/CPU scheduling.
2. `classic_mock_picks`
   - Mock ID, canonical player identity, player-season ID, team, pick number, roster slot, automated flag, pick time.
   - Primary key `(mock_id, canonical_id)` prevents multiple seasons of one identity.
   - Unique `(mock_id, pick_number)` prevents duplicate pick numbers.
   - Its only foreign key references `classic_mock_sessions`, never a real league or a permanent lock.

The development database received additive `CREATE TABLE` / `CREATE INDEX` statements. No existing league table was changed, no real league rows or permanent locks were inserted/updated/deleted, and no production migration or publishing action was performed.

The Drizzle definitions include these new tables for the normal publishing schema workflow. The application does not run migrations on startup.

## Automated verification actually run

- `pnpm --filter @workspace/api-spec run codegen` — passed; generated client hooks, types, server validation, and library typecheck.
- `pnpm --filter @workspace/api-server test:mocks` — **14 tests passed**, using the development PostgreSQL database:
  1. Allowed team sizes, random/manual order, owner seat, and timer validation.
  2. Membership, invitation seats, rejoin, host permissions, and full-human-lobby requirement.
  3. Shared CLASSIC snake progression and fifteen-round limit.
  4. Persisted cross-season mock identity exclusion.
  5. Independent database identity and pick-number constraints.
  6. Same identity available in different mocks; before/after checksums of real league rows and permanent locks unchanged; no foreign key to live tables.
  7. Rejection of out-of-turn picks, unknown assets, ineligible real-pool records, and full position/bench capacity.
  8. Queue persistence/privacy/reordering, queue-first timer pick, and cross-season queue cleanup.
  9. Disabled timer, pause/resume remaining time, and CPU scheduling/selection.
  10. Both CPU strategies finish twelve-team, 180-pick mocks with full legal rosters and 180 unique identities.
  11. Restart preserves original picks and permits a fresh session to select those identities again.
  12. Insufficient/unapproved real-player snapshots cannot start.
  13. Concurrent invitations cannot claim the same open human seat.
  14. Concurrent owner submissions serialize to one saved pick.
- `pnpm run typecheck` — passed across the workspace.
- `pnpm --filter @workspace/classic run typecheck` — passed after the final mobile navigation adjustment.
- `PORT=25442 BASE_PATH=/ pnpm --filter @workspace/classic run build` — passed. Existing UI sourcemap diagnostics and a bundle-size warning were non-fatal.
- Restarted both managed app services; API build/start and frontend startup succeeded.
- HTTP checks: `/api/healthz` returned 200; unauthenticated mock list, private room, and export requests returned 401.
- Inspected the actual signed-out lab at a 390×844 phone viewport; corrected crowded header labels.

Domain tests use rolled-back transactions or delete only their own explicitly created mock fixtures. The full live-league test suite was **not** rerun as part of this change. Full-draft tests advance simulated timestamps; they do not wait through 180 real-world clock intervals.

## Authenticated multiplayer verification

One end-to-end journey with **two separate Clerk-authenticated browser contexts** passed:

- Owner created a four-seat private illustrative mock; friend joined via the invite code and saw the same persistent session.
- Friend was denied host-only start (`403`); unauthenticated room requests returned `401`.
- Owner queued Jerry Rice privately; it survived reload and did not appear in the friend's queue.
- Both managers drafted; CPU seats auto-picked; both browsers subsequently showed the same six persisted picks.
- Every season of drafted identities disappeared from the eligible pool.
- JSON export contained the same picks; restart created a distinct empty lobby and retained all six picks in the original paused room and history.
- Mobile 390×844 checks on the signed-in lab and room confirmed there was no page-wide horizontal overflow. The in-room board/upcoming-picks strip scrolls within its own region.
- At the time of this test, real `classic_leagues` and `classic_identity_locks` each had zero rows; their before/after checksums matched. The new mock sessions/picks persisted separately.

Owner/friend pause and resume, timer expiry in a live browser, and creating a real-player snapshot were not exercised in this browser journey; their related server rules are covered by automated tests where noted. No production sign-up journey or published deployment was changed/tested.

## Limitations and operational notes

- The default player pool is explicitly **illustrative and unverified**, including fictional filler identities. It reuses only the sample **player records**, not the public Legends League's generated teams, picks, or activity.
- A real-player source requires the user to belong to a saved league with enough non-sample, commissioner-approved retired identities. Retirement/season approvals are commissioner attestations, not external verification. This feature does not supply an official historical dataset or performance statistics.
- Automation runs while the API process is active. Persisted deadlines catch up after a host restart/idle period, including on authenticated room reads. Catch-up is bounded to thirty automated picks per transaction; additional ticks/polls continue it. This is not a separate always-on job service.
- The pool displays at most 200 matches; search or filter to find others. The full snapshot remains stored and available to the server and export.
- There is no mock scoring, standings, predictive AI, manager presence, or per-seat CPU personality model. Those are not implied by the draft UI.
- No mock deletion, seat reassignment after creation, or timer/settings editing after creation was added. Create another mock to change its configuration.
- New functionality is in the workspace/preview until the owner publishes the update. This implementation did not change the existing public deployment.

## File manifest

### Added application files

- `artifacts/api-server/src/lib/mock-model.ts`
- `artifacts/api-server/src/lib/mock-store.ts`
- `artifacts/api-server/src/lib/mock-engine.ts`
- `artifacts/api-server/src/lib/mock-worker.ts`
- `artifacts/api-server/src/lib/mock.test.ts`
- `artifacts/api-server/src/routes/mock-drafts.ts`
- `artifacts/classic/src/lib/mock.ts`
- `artifacts/classic/src/pages/mock-lab.tsx`
- `artifacts/classic/src/pages/mock-room.tsx`
- `lib/db/src/schema/mock-drafts.ts`
- `docs/mock-draft-lab.md`

### Modified application/configuration files

- `artifacts/api-server/package.json` — mock test command and inclusion in the normal test command.
- `artifacts/api-server/src/index.ts` — start the mock-only deadline worker.
- `artifacts/api-server/src/routes/index.ts` — mount the new router.
- `artifacts/classic/src/App.tsx` — two new routes.
- `artifacts/classic/src/components/league-shell.tsx` — shared navigation entry and compact phone labels.
- `lib/api-spec/openapi.yaml` — mock contracts and endpoints.
- `lib/db/src/schema/index.ts` — export the new schema.
- `replit.md` — document the user's mock isolation/preservation rules.

### Regenerated API files

- `lib/api-client-react/src/generated/api.ts`
- `lib/api-client-react/src/generated/api.schemas.ts`
- `lib/api-zod/src/generated/api.ts`
- `lib/api-zod/src/generated/types/index.ts`
- New `lib/api-zod/src/generated/types/` files:
  `mockCommand.ts`, `mockCommandAction.ts`, `mockCommandDirection.ts`,
  `mockInput.ts`, `mockInputCpuStrategy.ts`, `mockInputPoolSource.ts`,
  `mockInvitation.ts`, `mockPick.ts`, `mockResult.ts`, `mockSeatInput.ts`,
  `mockSeatInputKind.ts`, `mockState.ts`, `mockStateCpuStrategy.ts`,
  `mockStatePoolSource.ts`, `mockStateStatus.ts`, `mockSummary.ts`,
  `mockSummaryStatus.ts`, `mockTeam.ts`, `mockTeamKind.ts`.

An unrelated pre-existing deleted conversation attachment was left untouched.
