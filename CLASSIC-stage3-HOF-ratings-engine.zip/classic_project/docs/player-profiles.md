# Historical Player Profiles & CLASSIC Performance Ratings

## Current implementation status

The application now has a reusable player-season profile dialog accessible from the Player Seasons list, drafted-player cells on the draft board, and roster entries. It shows the season/team/position metadata already stored in the league player record, labels sample/unverified versus commissioner-approved records, and explicitly reports biography, statistics, and performance rating as unavailable when the underlying verified data is absent. It also permits selecting another season of the same canonical player already present in that league's player pool for a side-by-side metadata comparison.

## Data limitations (intentional)

The current `Player` record contains only `id`, `canonicalId`, `name`, `position`, `nflTeam`, `season`, `retired`, `approved`, and `sample`. It does not contain statistics, biography, awards, sources, fantasy points, or rating inputs. Commissioner approval is an eligibility flag, not independent statistical verification. Therefore this implementation does not invent biographies, awards, statistics, performance ratings, tiers, or positional ranks.

## Remaining work

- Add a sourced historical player-season data ingestion pipeline and provenance fields.
- Add validated position-specific stat models, era/position normalization cohorts, and transparent 0–100 rating calculations.
- Add verified biography/career/accomplishment records and source links.
- Expand comparison to multiple players and show verified stats/fantasy scoring when available.
- Add draft-board sorting by rating once ratings can be calculated from complete verified data.
- Add tests for data completeness, rating calculations, and profile rendering.

No database schema, API contract, league transaction, draft, or permanent identity-lock logic was changed for this UI stage.

## Hall of Fame indicator (UI stage)

A CLASSIC-designed gold `HOF` seal is now shown beside player names on the Player Seasons list, draft board, roster, and profile header when a player record carries a verified `hallOfFame` status of `inducted`. The optional status shape supports `inductionYear` and `source`; a verified `not_inducted` value can be represented as well. Missing status is treated as **unknown**, never as not inducted. The seal is an original CLASSIC visual indicator and is not an official Pro Football Hall of Fame logo.

Important: this UI stage does not add Hall of Fame facts to existing player records, and does not claim that any specific player is a Hall of Famer. The current API/player data contract does not yet store this field. A later sourced-data migration must add the field to the API/database and populate it only from an authoritative Hall of Fame source before real players display the seal.


## Verified Hall of Fame registry (Stage 3)

The client now resolves Hall of Fame badges from a local registry of 43 players in the current illustrative pool. Every listed induction year is matched to the Pro Football Hall of Fame's official year-by-year enshrinement page: https://www.profootballhof.com/hall-of-famers/years. This registry includes the 2026 class and is intentionally limited to player names already represented in the sample pool. It is not a complete 387-member Hall of Fame database. Names not found remain unknown and receive no badge; they are not marked as non-members. The CLASSIC badge remains an original visual indicator, not the Hall's official logo.

## CLASSIC rating engine (Stage 3)

A standalone rating function now calculates a 0-100 percentile within a same-season, same-position cohort using verified PPR fantasy point totals. It requires at least 10 verified cohort records, preserves the source URL, reports cohort size and method, and returns no rating when inputs are unverified or incomplete. This is a transparent initial scoring method, not yet a fully era-adjusted historical model. Automated tests have been added for the calculation, but could not be executed in this environment because project dependencies are not installed. It is not displayed as a player's live rating until a validated historical stat dataset is ingested.

## Remaining data work

- Expand the Hall of Fame registry to all current enshrinees and add name aliases only with source-backed identity matching.
- Import verified season totals and underlying stat components, with source URLs and completeness flags.
- Add source-specific historical data adapters; seasons before modern public datasets need a separate archival source.
- Replace the initial same-season position percentile with a documented era-adjusted model after enough verified cohorts exist.
- Add biographies and career accomplishments from licensed or otherwise permitted authoritative sources.
