import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import { CLERK_PROXY_PATH, clerkProxyMiddleware, getClerkProxyHost } from "./middlewares/clerkProxyMiddleware";
import { classicErrors } from "./routes/classic";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(cors({credentials:true, origin:false}));
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({ extended: true }));
app.use(clerkMiddleware((req) => ({
  publishableKey: publishableKeyFromHost(
    getClerkProxyHost(req) ?? "",
    process.env.CLERK_PUBLISHABLE_KEY,
  ),
})));
app.use((req,res,next)=>{
  if(!["GET","HEAD","OPTIONS"].includes(req.method) && req.headers.origin) {
    const host=getClerkProxyHost(req);
    try {
      if(new URL(req.headers.origin).host !== host) {res.status(403).json({error:"Cross-origin requests are not allowed."});return;}
    } catch {res.status(403).json({error:"Invalid request origin."});return;}
  }
  next();
});

app.use("/api", router);
app.use(classicErrors);

export default app;
