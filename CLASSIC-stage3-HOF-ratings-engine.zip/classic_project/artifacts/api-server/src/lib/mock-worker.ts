import { logger } from "./logger";
import { advanceMock } from "./mock-engine";
import { loadMock, mockTransaction, saveMock } from "./mock-store";

let started = false;
export function startMockWorker() {
  if (started) return;
  started = true;
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try {
      await mockTransaction(async client => {
        // Multiple API instances can run this safely; an in-flight session is
        // skipped, and each pick still has database identity/pick constraints.
        const due = await client.query("SELECT id FROM classic_mock_sessions WHERE next_action_at <= now() ORDER BY next_action_at LIMIT 10 FOR UPDATE SKIP LOCKED");
        for (const row of due.rows) {
          const s = await loadMock(client, row.id);
          await advanceMock(client, s);
          await saveMock(client, s);
        }
      });
    } catch (err) { logger.error({ err }, "Mock automation tick failed"); }
    finally { running = false; }
  }, 1000);
  timer.unref();
}
