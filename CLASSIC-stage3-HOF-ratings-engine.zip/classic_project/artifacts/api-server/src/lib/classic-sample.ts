import { uid, type Player, type State } from "./classic-model";

// Illustrative identity/season records only. No historical stats or externally
// verified retirement/season approvals are claimed.
const legends: [string, string, string, number][] = [
  ["Jerry Rice","WR","SF",1995],["Barry Sanders","RB","DET",1997],["Peyton Manning","QB","DEN",2013],
  ["LaDainian Tomlinson","RB","SD",2006],["Randy Moss","WR","NE",2007],["Tony Gonzalez","TE","KC",2004],
  ["Joe Montana","QB","SF",1989],["Walter Payton","RB","CHI",1977],["Emmitt Smith","RB","DAL",1995],
  ["Marvin Harrison","WR","IND",2002],["Terrell Owens","WR","SF",2001],["Shannon Sharpe","TE","DEN",1996],
  ["Brett Favre","QB","GB",1996],["Dan Marino","QB","MIA",1984],["Tom Brady","QB","NE",2007],
  ["Drew Brees","QB","NO",2011],["Steve Young","QB","SF",1994],["Kurt Warner","QB","STL",1999],
  ["Marshall Faulk","RB","STL",2000],["Eric Dickerson","RB","LAR",1984],["Jim Brown","RB","CLE",1963],
  ["Adrian Peterson","RB","MIN",2012],["Priest Holmes","RB","KC",2003],["Shaun Alexander","RB","SEA",2005],
  ["Roger Craig","RB","SF",1988],["Edgerrin James","RB","IND",2000],["Thurman Thomas","RB","BUF",1991],
  ["Marcus Allen","RB","LAR",1985],["Terrell Davis","RB","DEN",1998],["Curtis Martin","RB","NYJ",2004],
  ["Calvin Johnson","WR","DET",2012],["Larry Fitzgerald","WR","ARI",2008],["Cris Carter","WR","MIN",1995],
  ["Isaac Bruce","WR","STL",1995],["Torry Holt","WR","STL",2003],["Andre Johnson","WR","HOU",2008],
  ["Reggie Wayne","WR","IND",2007],["Steve Smith","WR","CAR",2005],["Hines Ward","WR","PIT",2002],
  ["Tim Brown","WR","OAK",1997],["Michael Irvin","WR","DAL",1995],["Sterling Sharpe","WR","GB",1992],
  ["Rob Gronkowski","TE","NE",2011],["Antonio Gates","TE","SD",2009],["Jason Witten","TE","DAL",2012],
  ["Dallas Clark","TE","IND",2009],["Ozzie Newsome","TE","CLE",1984],["Kellen Winslow","TE","SD",1980],
  ["Adam Vinatieri","K","NE",2004],["Morten Andersen","K","ATL",1995],["Jason Elam","K","DEN",1998],
  ["Sebastian Janikowski","K","OAK",2011],["David Akers","K","SF",2011],["Gary Anderson","K","MIN",1998],
  ["John Elway","QB","DEN",1993],["Warren Moon","QB","HOU",1990],["Jim Kelly","QB","BUF",1991],
  ["Troy Aikman","QB","DAL",1992],["Donovan McNabb","QB","PHI",2004],["Randall Cunningham","QB","MIN",1998],
  ["Eddie George","RB","TEN",2000],["Jamal Lewis","RB","BAL",2003],["Fred Taylor","RB","JAX",2003],
  ["Corey Dillon","RB","NE",2004],["Jamaal Charles","RB","KC",2013],["Matt Forte","RB","CHI",2013],
  ["Arian Foster","RB","HOU",2010],["Steven Jackson","RB","STL",2006],["Clinton Portis","RB","DEN",2003],
  ["Ahman Green","RB","GB",2003],["LeSean McCoy","RB","PHI",2013],["Frank Gore","RB","SF",2006],
  ["Rod Smith","WR","DEN",2000],["Jimmy Smith","WR","JAX",1999],["Chad Johnson","WR","CIN",2005],
  ["Anquan Boldin","WR","ARI",2005],["Wes Welker","WR","NE",2011],["Brandon Marshall","WR","CHI",2012],
  ["Jordy Nelson","WR","GB",2014],["Donald Driver","WR","GB",2006],["Greg Jennings","WR","GB",2010],
];
const canonical = (name: string) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
export function samplePlayers(): Player[] {
  const rows: Player[] = legends.map(([name,position,nflTeam,season]) => ({
    id: `${canonical(name)}-${season}`, canonicalId: canonical(name), name, position, nflTeam, season,
    retired: false, approved: false, sample: true,
  }));
  for (const [name,position,nflTeam,season] of legends.slice(0, 20)) {
    rows.push({ id: `${canonical(name)}-${season-1}`, canonicalId:canonical(name), name,position,nflTeam,season:season-1,retired:false,approved:false,sample:true });
  }
  // Additional explicitly fictional test records make a full 12-team draft possible.
  for (const position of ["QB","RB","WR","TE","K","DEF"]) for (let i=1;i<=24;i++) {
    const name = `Sample ${position === "DEF" ? "Defense" : position} ${String(i).padStart(2,"0")}`;
    rows.push({id:`test-${position}-${i}-1990`,canonicalId:`test-${position}-${i}`,name,position,nflTeam:"TEST",season:1990,retired:false,approved:false,sample:true});
  }
  return rows;
}
export function makeSample(): State {
  const players = samplePlayers();
  const teams = ["Gridiron Legends","Sunday Greats","The Gold Standard","Fourth & Forever","Dynasty Architects","Old School Huddle","End Zone Icons","The Throwbacks"].map((name,i) => ({
    id:`sample-team-${i+1}`,name,userId:`sample-manager-${i+1}`,draftOrder:i+1,waiverPriority:i+1,
  }));
  const acquisitions = players.slice(0, 11).map((p,i)=>({
    canonicalId:p.canonicalId,playerId:p.id,teamId:teams[i<8?i:15-i]!.id,active:true,slot:p.position,pickNumber:i+1,
  }));
  return {
    league:{id:"sample",name:"The Legends League",commissionerId:"sample-manager-1",mode:"sample",maxTeams:12,status:"paused",pickNumber:12,waiverHours:24,inviteCode:"READ-ONLY"},
    teams,players,acquisitions,trades:[],claims:[],
    activity:[{id:uid(),message:"Welcome to CLASSIC. This is a read-only sample league, not verified historical data.",createdAt:new Date().toISOString()},
      ...acquisitions.slice(-4).reverse().map(a=>({id:uid(),message:`${teams.find(t=>t.id===a.teamId)!.name} selected ${players.find(p=>p.id===a.playerId)!.name}. Identity permanently locked.`,createdAt:new Date().toISOString()}))],
  };
}
