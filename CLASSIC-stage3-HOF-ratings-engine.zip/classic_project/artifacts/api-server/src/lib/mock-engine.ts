import type { PoolClient } from "@workspace/db";
import type { MockCommand } from "@workspace/api-zod";
import { ensure, uid } from "./classic-model";
import { randomBytes } from "node:crypto";
import { assertMember, chooseAutomatic, currentTeam, logMock, mockEligible, mockSlot, scheduleTurn, validateMockPool, type MockDocument, type MockPlayer } from "./mock-model";
import { insertMock } from "./mock-store";

export async function makeMockPick(client: PoolClient, s: MockDocument, player: MockPlayer, automated: boolean, at = Date.now()) {
  ensure(s.status === "drafting", "This mock draft is not running.");
  const team = currentTeam(s);
  ensure(team, "The draft is already complete.");
  ensure(s.players.some(p => p.id === player.id), "This player-season is not in the mock pool.");
  ensure(!s.picks.some(p => p.canonicalId === player.canonicalId), "This identity is already selected. Every other season is unavailable in this mock.", 409);
  ensure(mockEligible(s, team, player), "This player is ineligible or there is no valid roster slot.");
  const pick = {
    canonicalId: player.canonicalId, playerId: player.id, teamId: team.id, pickNumber: s.pickNumber,
    slot: mockSlot(s, team.id, player)!, automated, createdAt: new Date(at).toISOString(),
  };
  // This is the ONLY pick-write destination; never a live league lock table.
  await client.query("INSERT INTO classic_mock_picks (mock_id,canonical_id,player_id,team_id,pick_number,slot,automated,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
    [s.id, pick.canonicalId, pick.playerId, pick.teamId, pick.pickNumber, pick.slot, pick.automated, pick.createdAt]);
  s.picks.push(pick);
  s.pickNumber++;
  for (const id of Object.keys(s.queues)) s.queues[id] = s.queues[id]!.filter(id =>
    s.players.find(p => p.id === id)?.canonicalId !== player.canonicalId);
  logMock(s, `Pick ${pick.pickNumber}: ${team.name} selected ${player.name}, ${player.season} (${player.position} · ${player.nflTeam})${automated ? team.kind === "cpu" ? " · basic CPU strategy" : " · timer autopick" : ""}.`, at);
  scheduleTurn(s, at);
}
// Persistent deadlines allow safe catch-up after a process restart or idle host.
// Bounded transactions keep long offline sessions from monopolizing a request.
export async function advanceMock(client: PoolClient, s: MockDocument, now = Date.now(), limit = 30) {
  let count = 0;
  while (s.status === "drafting" && s.deadlineAt && Date.parse(s.deadlineAt) <= now && count < limit) {
    const team = currentTeam(s)!;
    const at = Date.parse(s.deadlineAt);
    const p = chooseAutomatic(s, team);
    if (!p) {
      s.status = "paused"; s.deadlineAt = null;
      logMock(s, "Mock paused: no eligible unlocked identity fits the current team's roster.");
      break;
    }
    await makeMockPick(client, s, p, true, at);
    count++;
  }
  return count;
}
export async function runMockCommand(client: PoolClient, s: MockDocument, userId: string, cmd: MockCommand, now = Date.now()) {
  const me = assertMember(s, userId);
  const owner = () => ensure(s.ownerId === userId, "Only the mock host can do that.", 403);
  let message = "";
  switch (cmd.action) {
    case "start":
      owner(); ensure(s.status === "lobby", "This mock has already started.");
      ensure(s.teams.every(t => t.kind === "cpu" || t.userId), "Invite a manager into every human seat before starting.");
      validateMockPool(s);
      s.status = "drafting"; scheduleTurn(s, now);
      message = "Mock draft started. No real league locks will be created."; break;
    case "pause":
      owner(); ensure(s.status === "drafting", "Only a running mock can be paused.");
      s.remainingMs = s.deadlineAt ? Math.max(0, Date.parse(s.deadlineAt) - now) : null;
      s.status = "paused"; s.deadlineAt = null; message = "Mock draft paused."; break;
    case "resume": {
      owner(); ensure(s.status === "paused", "Only a paused mock can be resumed.");
      const remaining = s.remainingMs;
      s.status = "drafting"; scheduleTurn(s, now);
      if (remaining !== null) s.deadlineAt = new Date(now + Math.max(1, remaining)).toISOString();
      message = "Mock draft resumed."; break;
    }
    case "pick": {
      ensure(s.status === "drafting", "This mock draft is not running.");
      ensure(currentTeam(s)?.id === me.id, "It is not your team's turn.", 409);
      const p = s.players.find(p => p.id === cmd.playerId);
      ensure(p, "Player-season not found.", 404);
      await makeMockPick(client, s, p, false, now);
      return { id: s.id, message: `Selected ${p.name}, ${p.season}.` };
    }
    case "queueAdd": {
      ensure(s.status !== "completed", "Completed mock queues cannot change.");
      const p = s.players.find(p => p.id === cmd.playerId);
      ensure(p && mockEligible(s, me, p), "This player is locked, ineligible, or cannot fit your roster.");
      const q = s.queues[me.id] ??= [];
      ensure(q.length < 100, "Your queue is limited to 100 seasons.");
      ensure(!q.includes(p.id), "This season is already queued.");
      q.push(p.id); message = "Added to your private queue."; break;
    }
    case "queueRemove":
    case "queueMove": {
      ensure(s.status !== "completed", "Completed mock queues cannot change.");
      const q = s.queues[me.id] ??= [];
      const i = q.indexOf(cmd.playerId ?? "");
      ensure(i >= 0, "That season is not in your queue.");
      if (cmd.action === "queueRemove") q.splice(i, 1);
      else {
        ensure(cmd.direction === -1 || cmd.direction === 1, "Choose up or down.");
        const j = i + cmd.direction;
        ensure(j >= 0 && j < q.length, "Already at the edge of your queue.");
        [q[i], q[j]] = [q[j]!, q[i]!];
      }
      // Queue changes intentionally do not leak into public session activity.
      return { id: s.id, message: "Private queue updated." };
    }
    case "restart": {
      owner();
      const next: MockDocument = {
        ...structuredClone(s), id: uid(), inviteCode: randomBytes(12).toString("hex").toUpperCase(),
        status: "lobby", picks: [], activity: [], queues: {}, pickNumber: 1, deadlineAt: null,
        remainingMs: null, createdAt: new Date(now).toISOString(), restartedFrom: s.id,
      };
      if (s.status === "drafting") { s.status = "paused"; s.deadlineAt = null; s.remainingMs = null; }
      logMock(s, "A new practice session was created from this mock. These results are preserved.", now);
      logMock(next, `Restarted as a fresh mock. Prior session results are preserved. ${s.dataLabel}.`, now);
      await insertMock(client, next);
      return { id: next.id, message: "Fresh mock created. Original results and picks were preserved." };
    }
  }
  if (!cmd.action.startsWith("queue")) logMock(s, message, now);
  return { id: s.id, message };
}
