import { randomBytes, randomInt } from "node:crypto";
import type { MockInput, MockState, MockSummary } from "@workspace/api-zod";
// Reuse only pure, read-only football rules. Never import live mutation logic.
import { ensure, SLOTS, slotAllowed, teamForPick, uid } from "./classic-model";

export type MockDocument = Omit<MockState, "viewerTeamId" | "currentTeamId" | "isOwner" | "queue" | "serverNow"> & {
  queues: Record<string, string[]>;
  remainingMs: number | null;
};
export type MockTeam = MockDocument["teams"][number];
export type MockPlayer = MockDocument["players"][number];
export function currentTeam(s: MockDocument, pick = s.pickNumber) {
  const ordered = s.teams.map(t => ({ ...t, userId: t.userId ?? "", waiverPriority: t.draftOrder }));
  const team = teamForPick(ordered, pick);
  return s.teams.find(t => t.id === team?.id);
}
export function assertMember(s: MockDocument, userId: string) {
  const team = s.teams.find(t => t.kind === "human" && t.userId === userId);
  ensure(team, "You are not a participant in this private mock draft.", 403);
  return team;
}
export function joinMockSeat(s: MockDocument, userId: string, name?: string) {
  const existing = s.teams.find(t => t.userId === userId);
  if (existing) return existing;
  ensure(s.status === "lobby", "New managers cannot join after the mock starts.");
  const seat = s.teams.find(t => t.kind === "human" && !t.userId);
  ensure(seat, "All human seats are filled.", 409);
  if (name !== undefined) { ensure(name.trim().length >= 2, "Team name needs at least two characters."); seat.name = name.trim(); }
  seat.userId = userId;
  logMock(s, `${seat.name} joined a human seat.`);
  return seat;
}
export function logMock(s: MockDocument, message: string, at = Date.now()) {
  s.activity.unshift({ id: uid(), message, createdAt: new Date(at).toISOString() });
}
export function mockSlot(s: MockDocument, teamId: string, player: MockPlayer): string | undefined {
  const picks = s.picks.filter(p => p.teamId === teamId);
  if (picks.length >= 15) return undefined;
  return Object.keys(SLOTS).find(slot =>
    slotAllowed(player.position, slot) && picks.filter(p => p.slot === slot).length < SLOTS[slot]!);
}
export function mockEligible(s: MockDocument, team: MockTeam, p: MockPlayer) {
  return (s.poolSource === "illustrative" || (!p.sample && p.approved && p.retired))
    && !s.picks.some(pick => pick.canonicalId === p.canonicalId) && !!mockSlot(s, team.id, p);
}
export function chooseAutomatic(s: MockDocument, team: MockTeam): MockPlayer | undefined {
  // Queue preference is deterministic; never interprets display order as stats.
  for (const id of s.queues[team.id] ?? []) {
    const p = s.players.find(p => p.id === id);
    if (p && mockEligible(s, team, p)) return p;
  }
  const candidates = s.players.filter(p => mockEligible(s, team, p));
  if (s.cpuStrategy === "balanced") return candidates.find(p => mockSlot(s, team.id, p) !== "Bench") ?? candidates[0];
  return candidates.map((p, i) => {
    const slot = mockSlot(s, team.id, p)!;
    const filled = s.picks.filter(pick => pick.teamId === team.id && pick.slot === slot).length;
    return { p, score: slot === "Bench" ? 0 : 100 + (SLOTS[slot]! - filled) / SLOTS[slot]!, i };
  }).sort((a, b) => b.score - a.score || a.i - b.i)[0]?.p;
}
export function scheduleTurn(s: MockDocument, at = Date.now()) {
  s.remainingMs = null;
  if (s.status !== "drafting") { s.deadlineAt = null; return; }
  const team = currentTeam(s);
  if (!team) {
    s.status = "completed"; s.deadlineAt = null;
    logMock(s, "Mock draft complete. Results are saved; no real league transactions were created.", at);
    return;
  }
  const delay = team.kind === "cpu" ? 1000 : s.timerSeconds * 1000;
  s.deadlineAt = delay ? new Date(at + delay).toISOString() : null;
}
export function validateMockInput(input: MockInput) {
  ensure([4, 6, 8, 10, 12].includes(input.teams.length), "Choose 4, 6, 8, 10, or 12 teams.");
  ensure(input.name.trim().length >= 2, "Name must contain at least two characters.");
  ensure(input.ownerSeat < input.teams.length && input.teams[input.ownerSeat]?.kind === "human", "Choose a human seat for yourself.");
  ensure(input.timerSeconds === 0 || input.timerSeconds >= 5, "Timer must be disabled or at least five seconds.");
  ensure(input.teams.every(t => t.name.trim().length >= 2), "Each team needs a name.");
  ensure(input.randomOrder || (new Set(input.teams.map(t => t.draftOrder)).size === input.teams.length
    && input.teams.every(t => t.draftOrder >= 1 && t.draftOrder <= input.teams.length)), "Manual draft order must contain each position exactly once.");
}
export function createMockDocument(input: MockInput, userId: string, players: MockPlayer[], dataLabel: string): MockDocument {
  validateMockInput(input);
  const order = Array.from({ length: input.teams.length }, (_, i) => i + 1);
  if (input.randomOrder) for (let i = order.length - 1; i > 0; i--) {
    const j = randomInt(i + 1); [order[i], order[j]] = [order[j]!, order[i]!];
  }
  const doc: MockDocument = {
    id: uid(), name: input.name.trim(), ownerId: userId, status: "lobby",
    teams: input.teams.map((t, i) => ({ id: uid(), name: t.name.trim(), kind: t.kind, draftOrder: input.randomOrder ? order[i]! : t.draftOrder, userId: i === input.ownerSeat ? userId : null })),
    players: structuredClone(players), picks: [], activity: [], queues: {}, remainingMs: null,
    timerSeconds: input.timerSeconds, cpuStrategy: input.cpuStrategy, poolSource: input.poolSource,
    dataLabel, inviteCode: randomBytes(12).toString("hex").toUpperCase(), pickNumber: 1, deadlineAt: null,
    createdAt: new Date().toISOString(), restartedFrom: null,
  };
  logMock(doc, `Mock created. ${dataLabel}. Completely isolated from real leagues.`);
  return doc;
}
export function validateMockPool(s: MockDocument) {
  const players = s.players.filter(p => s.poolSource === "illustrative" || (!p.sample && p.retired && p.approved));
  ensure(new Set(players.map(p => p.canonicalId)).size >= s.teams.length * 15,
    `This pool needs at least ${s.teams.length * 15} unique eligible player identities for ${s.teams.length} teams.`);
  for (const position of ["QB", "RB", "WR", "TE", "K", "DEF"]) {
    ensure(new Set(players.filter(p => p.position === position).map(p => p.canonicalId)).size >= (SLOTS[position] ?? 1) * s.teams.length,
      `Not enough eligible ${position} identities to fill every starting roster.`);
  }
  ensure(new Set(players.filter(p => ["RB", "WR", "TE"].includes(p.position)).map(p => p.canonicalId)).size >= s.teams.length * 6,
    "Not enough RB/WR/TE identities to fill starters and FLEX slots.");
}
export function mockView(s: MockDocument, userId: string): MockState {
  const me = assertMember(s, userId);
  const { queues, remainingMs: _remaining, ...visible } = s;
  return { ...visible, viewerTeamId: me.id, currentTeamId: currentTeam(s)?.id ?? null, isOwner: s.ownerId === userId, queue: queues[me.id] ?? [], serverNow: new Date().toISOString() };
}
export function mockSummary(s: MockDocument): MockSummary {
  return { id: s.id, name: s.name, ownerId: s.ownerId, status: s.status, teamCount: s.teams.length, pickCount: s.pickNumber - 1, dataLabel: s.dataLabel, createdAt: s.createdAt };
}
