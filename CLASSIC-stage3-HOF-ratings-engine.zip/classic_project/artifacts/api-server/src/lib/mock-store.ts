import { pool, type PoolClient } from "@workspace/db";
import { ensure } from "./classic-model";
import type { MockDocument } from "./mock-model";

export async function mockTransaction<T>(fn: (client: PoolClient) => Promise<T>) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}
export async function loadMock(client: PoolClient, id: string, lock = true): Promise<MockDocument> {
  const result = await client.query(`SELECT state FROM classic_mock_sessions WHERE id=$1${lock ? " FOR UPDATE" : ""}`, [id]);
  ensure(result.rows[0], "Mock draft not found.", 404);
  const s = result.rows[0].state as MockDocument;
  const picks = await client.query(`SELECT canonical_id AS "canonicalId",player_id AS "playerId",team_id AS "teamId",pick_number AS "pickNumber",slot,automated,created_at AS "createdAt" FROM classic_mock_picks WHERE mock_id=$1 ORDER BY pick_number`, [id]);
  s.picks = picks.rows.map(p => ({ ...p, createdAt: (p.createdAt as Date).toISOString() }));
  return s;
}
export async function saveMock(client: PoolClient, s: MockDocument) {
  await client.query("UPDATE classic_mock_sessions SET state=$2::jsonb,next_action_at=$3 WHERE id=$1",
    [s.id, JSON.stringify({ ...s, picks: [] }), s.status === "drafting" ? s.deadlineAt : null]);
}
export async function insertMock(client: PoolClient, s: MockDocument) {
  await client.query("INSERT INTO classic_mock_sessions (id,invite_code,state,next_action_at) VALUES ($1,$2,$3::jsonb,$4)",
    [s.id, s.inviteCode, JSON.stringify({ ...s, picks: [] }), s.deadlineAt]);
}
