import { test, after } from "node:test";
import assert from "node:assert/strict";
import { pool, type PoolClient } from "@workspace/db";
import { CreateMockDraftBody, GetMockDraftResponse } from "@workspace/api-zod";
import { samplePlayers } from "./classic-sample";
import { assertMember, chooseAutomatic, createMockDocument, currentTeam, joinMockSeat, mockSlot, mockView, validateMockInput, type MockDocument } from "./mock-model";
import { SLOTS } from "./classic-model";
import { advanceMock, makeMockPick, runMockCommand } from "./mock-engine";
import { insertMock, loadMock, mockTransaction, saveMock } from "./mock-store";

const input = (n = 4) => CreateMockDraftBody.parse({
  name: "Isolated automated practice", ownerSeat: 0, randomOrder: false, timerSeconds: 0,
  cpuStrategy: "needs", poolSource: "illustrative",
  teams: Array.from({ length: n }, (_, i) => ({ name: `Manager ${i + 1}`, kind: "human", draftOrder: i + 1 })),
});
function fixture(n = 4) {
  const s = createMockDocument(input(n), "mock-test-owner", samplePlayers(), "Illustrative unverified test records");
  s.teams.forEach((t, i) => { t.userId = i ? `mock-test-human-${i}` : "mock-test-owner"; });
  return s;
}
async function isolated(fn: (s: MockDocument, client: PoolClient) => Promise<void>) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const s = fixture();
    await insertMock(client, s);
    await fn(s, client);
  } finally { await client.query("ROLLBACK"); client.release(); }
}
async function start(c: PoolClient, s: MockDocument, at = Date.now()) {
  await runMockCommand(c, s, s.ownerId, { action: "start" }, at);
}
after(async () => { await pool.end(); });

test("mock creation validates allowed sizes, manual order, owner seat and timers", () => {
  for (const n of [4, 6, 8, 10, 12]) assert.doesNotThrow(() => validateMockInput(input(n)));
  assert.throws(() => validateMockInput({ ...input(), teams: input().teams.slice(0, 3) }), /Choose 4/);
  const duplicate = input(); duplicate.teams[1]!.draftOrder = 1;
  assert.throws(() => validateMockInput(duplicate), /exactly once/);
  const cpuOwner = input(); cpuOwner.teams[0]!.kind = "cpu";
  assert.throws(() => validateMockInput(cpuOwner), /human seat/);
  assert.throws(() => validateMockInput({ ...input(), timerSeconds: 1 }), /five seconds/);
  const randomized = createMockDocument({ ...input(), randomOrder: true }, "owner", samplePlayers(), "Illustrative");
  assert.deepEqual(randomized.teams.map(t => t.draftOrder).sort(), [1, 2, 3, 4]);
});
test("private mock membership, invitation seats, idempotent rejoin and host authority", async () => isolated(async (s, c) => {
  assert.throws(() => assertMember(s, "outsider"), /not a participant/);
  assert.throws(() => mockView(s, "outsider"), /not a participant/);
  await assert.rejects(runMockCommand(c, s, s.teams[1]!.userId!, { action: "start" }), /Only the mock host/);
  s.teams[1]!.userId = null;
  await assert.rejects(start(c, s), /every human seat/);
  const joined = joinMockSeat(s, "friend", "Friend's team");
  assert.equal(joined.id, s.teams[1]!.id);
  assert.equal(joinMockSeat(s, "friend").id, joined.id);
  assert.throws(() => joinMockSeat(s, "other-friend"), /filled/);
  await start(c, s);
  assert.throws(() => joinMockSeat(s, "new-friend"), /after the mock starts/);
}));
test("snake progression is shared with CLASSIC and stops after fifteen rounds", async () => isolated(async (s, c) => {
  await start(c, s);
  const expected = [0, 1, 2, 3, 3, 2, 1, 0, 0];
  for (const i of expected) {
    assert.equal(currentTeam(s)?.id, s.teams[i]!.id);
    await makeMockPick(c, s, chooseAutomatic(s, currentTeam(s)!)!, false);
  }
  assert.equal(currentTeam(s, 61), undefined);
}));
test("cross-season mock identity lock is persisted and blocks all alternate seasons", async () => isolated(async (s, c) => {
  await start(c, s);
  const first = s.players[0]!, other = s.players.find(p => p.canonicalId === first.canonicalId && p.id !== first.id)!;
  await runMockCommand(c, s, s.ownerId, { action: "pick", playerId: first.id });
  await assert.rejects(runMockCommand(c, s, s.teams[1]!.userId!, { action: "pick", playerId: other.id }), /identity is already selected/);
  await saveMock(c, s);
  const reloaded = await loadMock(c, s.id);
  assert.equal(reloaded.picks[0]!.canonicalId, first.canonicalId);
  assert.equal(reloaded.pickNumber, 2);
  assert.equal(GetMockDraftResponse.parse(mockView(reloaded, s.ownerId)).picks.length, 1);
}));
test("database independently enforces mock identity and pick-number uniqueness", async () => isolated(async (s, c) => {
  await start(c, s);
  await makeMockPick(c, s, s.players[0]!, false);
  for (const [canonicalId, pickNumber] of [[s.players[0]!.canonicalId, 2], ["different-identity", 1]] as const) {
    await c.query("SAVEPOINT duplicate_mock");
    await assert.rejects(c.query("INSERT INTO classic_mock_picks(mock_id,canonical_id,player_id,team_id,pick_number,slot,automated,created_at) VALUES($1,$2,$3,$4,$5,'Bench',false,now())",
      [s.id, canonicalId, "other-season", s.teams[1]!.id, pickNumber]), (e: unknown) => (e as {code: string}).code === "23505");
    await c.query("ROLLBACK TO SAVEPOINT duplicate_mock");
  }
}));
test("different mocks select the same identity without any real-league writes", async () => isolated(async (s, c) => {
  // The combined test command runs files serially: the live suite's temporary,
  // committed concurrency fixtures must not race this real-table checksum.
  const snapshot = async () => (await c.query(`SELECT
    (SELECT md5(coalesce(jsonb_agg(to_jsonb(l) ORDER BY id)::text,'')) FROM classic_leagues l) AS leagues,
    (SELECT md5(coalesce(jsonb_agg(to_jsonb(k) ORDER BY league_id,canonical_id)::text,'')) FROM classic_identity_locks k) AS locks`)).rows[0];
  const before = await snapshot();
  const other = fixture(); await insertMock(c, other);
  for (const doc of [s, other]) {
    await start(c, doc); await makeMockPick(c, doc, doc.players[0]!, false); await saveMock(c, doc);
  }
  const rows = await c.query("SELECT count(*) FROM classic_mock_picks WHERE mock_id=ANY($1::text[])", [[s.id, other.id]]);
  assert.equal(Number(rows.rows[0].count), 2);
  assert.deepEqual(await snapshot(), before, "Real league documents and permanent identity locks must remain byte-equivalent");
  const refs = await c.query(`SELECT ccu.table_name FROM information_schema.constraint_column_usage ccu
    JOIN information_schema.table_constraints tc ON tc.constraint_name=ccu.constraint_name AND tc.constraint_schema=ccu.constraint_schema
    WHERE tc.table_name='classic_mock_picks' AND tc.constraint_type='FOREIGN KEY'`);
  assert.deepEqual(refs.rows.map(r => r.table_name), ["classic_mock_sessions"]);
}));
test("server rejects out-of-turn, unknown players, ineligible seasons and roster overflow", async () => isolated(async (s, c) => {
  await start(c, s);
  await assert.rejects(runMockCommand(c, s, s.teams[1]!.userId!, { action: "pick", playerId: s.players[0]!.id }), /not your team's turn/);
  await assert.rejects(runMockCommand(c, s, s.ownerId, { action: "pick", playerId: "missing" }), /not found/);
  s.poolSource = "league";
  await assert.rejects(runMockCommand(c, s, s.ownerId, { action: "pick", playerId: s.players[0]!.id }), /ineligible/);
  s.poolSource = "illustrative";
  const qb = s.players.find(p => p.position === "QB")!;
  s.picks = Array.from({ length: 7 }, (_, i) => ({ canonicalId: `taken-${i}`, playerId: `taken-${i}`, teamId: s.teams[0]!.id, pickNumber: i + 100, slot: i ? "Bench" : "QB", automated: false, createdAt: new Date().toISOString() }));
  assert.equal(mockSlot(s, s.teams[0]!.id, qb), undefined);
}));
test("private queues persist, reorder, prefer timeout selections and clean all seasons after a pick", async () => isolated(async (s, c) => {
  const first = s.players[0]!, second = s.players[1]!, alt = s.players.find(p => p.canonicalId === first.canonicalId && p.id !== first.id)!;
  for (const playerId of [first.id, second.id, alt.id]) await runMockCommand(c, s, s.ownerId, { action: "queueAdd", playerId });
  await runMockCommand(c, s, s.ownerId, { action: "queueMove", playerId: second.id, direction: -1 });
  await saveMock(c, s);
  const restored = await loadMock(c, s.id);
  assert.deepEqual(mockView(restored, s.ownerId).queue, [second.id, first.id, alt.id]);
  assert.deepEqual(mockView(restored, s.teams[1]!.userId!).queue, []);
  assert.equal("queues" in mockView(restored, s.ownerId), false);
  assert.equal(chooseAutomatic(s, s.teams[0]!)?.id, second.id);
  s.timerSeconds = 5; await start(c, s, 1000);
  assert.equal(await advanceMock(c, s, 6000), 1);
  assert.equal(s.picks[0]!.playerId, second.id);
  await makeMockPick(c, s, first, false, 6001);
  assert.deepEqual(s.queues[s.teams[0]!.id], []);
}));
test("disabled human timer waits; pause/resume preserves remaining time; CPU picks use the same constraints", async () => isolated(async (s, c) => {
  await start(c, s, 1000);
  assert.equal(s.deadlineAt, null);
  assert.equal(await advanceMock(c, s, 999999), 0);
  s.timerSeconds = 30;
  s.deadlineAt = new Date(31000).toISOString();
  await runMockCommand(c, s, s.ownerId, { action: "pause" }, 11000);
  assert.equal(s.remainingMs, 20000);
  assert.equal(await advanceMock(c, s, 999999), 0);
  await runMockCommand(c, s, s.ownerId, { action: "resume" }, 100000);
  assert.equal(s.deadlineAt, new Date(120000).toISOString());
  s.teams[1]!.kind = "cpu"; s.teams[1]!.userId = null;
  await makeMockPick(c, s, s.players[0]!, false, 110000);
  assert.equal(s.deadlineAt, new Date(111000).toISOString());
  assert.equal(await advanceMock(c, s, 111000), 1);
  assert.equal(s.picks[1]!.automated, true);
  assert.notEqual(s.picks[1]!.canonicalId, s.picks[0]!.canonicalId);
}));
test("both basic CPU strategies complete twelve-team mocks with valid full rosters", async () => isolated(async (_s, c) => {
  for (const strategy of ["needs", "balanced"] as const) {
    const s = fixture(12); s.cpuStrategy = strategy; s.timerSeconds = 5;
    s.teams.slice(1).forEach(t => { t.kind = "cpu"; t.userId = null; });
    await insertMock(c, s); await start(c, s, 1000);
    await advanceMock(c, s, 10000000, 1000);
    assert.equal(s.status, "completed", strategy);
    assert.equal(s.picks.length, 180, strategy);
    assert.equal(new Set(s.picks.map(p => p.canonicalId)).size, 180);
    for (const team of s.teams) {
      const picks = s.picks.filter(p => p.teamId === team.id);
      assert.equal(picks.length, 15);
      for (const [slot, cap] of Object.entries(SLOTS)) assert.equal(picks.filter(p => p.slot === slot).length, cap);
    }
    await saveMock(c, s);
    const persisted = await loadMock(c, s.id);
    assert.equal(persisted.picks.length, 180);
    await assert.rejects(runMockCommand(c, persisted, s.ownerId, { action: "pick", playerId: s.players[0]!.id }), /not running/);
  }
}));
test("restart keeps original picks and creates independent mock-only locks", async () => isolated(async (s, c) => {
  await start(c, s); const player = s.players[0]!;
  await makeMockPick(c, s, player, false);
  const result = await runMockCommand(c, s, s.ownerId, { action: "restart" });
  await saveMock(c, s);
  assert.notEqual(result.id, s.id);
  const previous = await loadMock(c, s.id), next = await loadMock(c, result.id);
  assert.equal(previous.picks.length, 1);
  assert.equal(previous.status, "paused");
  assert.equal(next.restartedFrom, s.id);
  assert.equal(next.picks.length, 0);
  assert.equal(next.status, "lobby");
  await start(c, next); await makeMockPick(c, next, next.players.find(p => p.id === player.id)!, false);
  assert.equal(next.picks[0]!.canonicalId, previous.picks[0]!.canonicalId);
}));
test("an insufficient or unapproved real-league snapshot cannot start", async () => isolated(async (s, c) => {
  s.poolSource = "league";
  await assert.rejects(start(c, s), /unique eligible/);
  s.players.forEach(p => { p.retired = true; p.approved = true; p.sample = false; });
  await assert.doesNotReject(start(c, s));
}));
test("concurrent invitations cannot double-assign a human seat", async () => {
  const s = fixture(); s.teams[3]!.userId = null;
  await mockTransaction(c => insertMock(c, s));
  try {
    const results = await Promise.allSettled(["friend-a", "friend-b"].map(userId => mockTransaction(async c => {
      const doc = await loadMock(c, s.id);
      joinMockSeat(doc, userId); await saveMock(c, doc);
    })));
    assert.equal(results.filter(r => r.status === "fulfilled").length, 1);
    assert.equal(results.filter(r => r.status === "rejected").length, 1);
  } finally { await pool.query("DELETE FROM classic_mock_sessions WHERE id=$1", [s.id]); }
});
test("concurrent human draft submissions serialize to one persisted pick", async () => {
  const s = fixture();
  await mockTransaction(async c => { await insertMock(c, s); await start(c, s); await saveMock(c, s); });
  try {
    const results = await Promise.allSettled([s.players[0]!, s.players[1]!].map(p => mockTransaction(async c => {
      const doc = await loadMock(c, s.id);
      await runMockCommand(c, doc, s.ownerId, { action: "pick", playerId: p.id });
      await saveMock(c, doc);
    })));
    assert.equal(results.filter(r => r.status === "fulfilled").length, 1);
    assert.equal(results.filter(r => r.status === "rejected").length, 1);
    await mockTransaction(async c => {
      const doc = await loadMock(c, s.id);
      assert.equal(doc.picks.length, 1); assert.equal(doc.pickNumber, 2);
    });
  } finally {
    await pool.query("DELETE FROM classic_mock_picks WHERE mock_id=$1", [s.id]);
    await pool.query("DELETE FROM classic_mock_sessions WHERE id=$1", [s.id]);
  }
});
