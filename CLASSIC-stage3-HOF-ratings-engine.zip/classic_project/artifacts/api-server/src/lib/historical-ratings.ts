/** Transparent season rating based on percentile within same-season, same-position PPR cohort.
 * This module intentionally refuses incomplete/unverified data; it does not manufacture scores.
 */
export type VerifiedSeasonTotal = {
  playerId: string;
  canonicalId: string;
  season: number;
  position: "QB" | "RB" | "WR" | "TE" | "K" | "DEF";
  pprFantasyPoints: number;
  sourceUrl: string;
  verified: boolean;
};

export type SeasonRating = {
  score: number;
  tier: "Legendary" | "Elite" | "Great" | "Above Average" | "Solid" | "Average" | "Below Average";
  cohortSize: number;
  method: "same-season-position-percentile";
  sourceUrl: string;
};

const MIN_COHORT_SIZE = 10;

function tierFor(score: number): SeasonRating["tier"] {
  if (score >= 95) return "Legendary";
  if (score >= 90) return "Elite";
  if (score >= 80) return "Great";
  if (score >= 70) return "Above Average";
  if (score >= 60) return "Solid";
  if (score >= 45) return "Average";
  return "Below Average";
}

export function calculateSeasonRating(target: VerifiedSeasonTotal, records: VerifiedSeasonTotal[]): SeasonRating | null {
  if (!target.verified || !target.sourceUrl || !Number.isFinite(target.pprFantasyPoints)) return null;
  const cohort = records.filter((record) =>
    record.verified && !!record.sourceUrl && record.season === target.season &&
    record.position === target.position && Number.isFinite(record.pprFantasyPoints)
  );
  if (cohort.length < MIN_COHORT_SIZE || !cohort.some((record) => record.playerId === target.playerId)) return null;
  const less = cohort.filter((record) => record.pprFantasyPoints < target.pprFantasyPoints).length;
  const equal = cohort.filter((record) => record.pprFantasyPoints === target.pprFantasyPoints).length;
  const percentile = ((less + (equal - 1) / 2) / (cohort.length - 1)) * 100;
  const score = Math.round(Math.max(0, Math.min(100, percentile)));
  return { score, tier: tierFor(score), cohortSize: cohort.length, method: "same-season-position-percentile", sourceUrl: target.sourceUrl };
}
