import { test, after } from "node:test";
import assert from "node:assert/strict";
import { pool } from "@workspace/db";
import { applyCommand } from "./classic-actions";
import { availableSlot, teamForPick, uid, type State } from "./classic-model";
import { readState, transaction, writeState, type Client } from "./classic-store";
import { samplePlayers } from "./classic-sample";

function fixture():State {
  const id=uid();
  return {
    league:{id,name:"Automated test",commissionerId:"test-a",inviteCode:uid(),mode:"sample",maxTeams:2,status:"live",pickNumber:1,waiverHours:0},
    teams:[{id:"a",userId:"test-a",name:"A",draftOrder:1,waiverPriority:1},{id:"b",userId:"test-b",name:"B",draftOrder:2,waiverPriority:2}],
    players:samplePlayers(),acquisitions:[],activity:[],trades:[],claims:[],
  };
}
async function insert(client: Client,s:State) {
  await client.query("INSERT INTO classic_leagues (id,invite_code,state) VALUES ($1,$2,$3::jsonb)",[s.league.id,s.league.inviteCode,JSON.stringify(s)]);
}
async function isolated(fn:(s:State,c:Client)=>Promise<void>) {
  const client=await pool.connect();
  try {await client.query("BEGIN");const s=fixture();await insert(client,s);await fn(s,client);}
  finally {await client.query("ROLLBACK");client.release();}
}
test("snake draft reverses order each round and ends after 15 rounds",()=>{
  const s=fixture();
  assert.deepEqual([1,2,3,4,5,6].map(p=>teamForPick(s.teams,p)?.id),["a","b","b","a","a","b"]);
  assert.equal(teamForPick(s.teams,31),undefined);
});
test("a different season of a drafted identity cannot be acquired",async()=>isolated(async(s,c)=>{
  const first=s.players[0]!, alternate=s.players.find(p=>p.canonicalId===first.canonicalId && p.id!==first.id)!;
  await applyCommand(c,s,"test-a",{action:"draft",playerId:first.id});
  await assert.rejects(applyCommand(c,s,"test-b",{action:"draft",playerId:alternate.id}),/permanently locked/);
  const count=await c.query("SELECT count(*) FROM classic_identity_locks WHERE league_id=$1",[s.league.id]);
  assert.equal(Number(count.rows[0].count),1);
}));
test("dropping never releases an identity; other managers cannot acquire it",async()=>isolated(async(s,c)=>{
  const p=s.players[0]!;
  await applyCommand(c,s,"test-a",{action:"draft",playerId:p.id});
  await applyCommand(c,s,"test-a",{action:"drop",playerId:p.id});
  s.league.status="completed";
  await assert.rejects(applyCommand(c,s,"test-b",{action:"acquire",playerId:p.id}),/permanently locked/);
  const lock=await c.query("SELECT active,team_id FROM classic_identity_locks WHERE league_id=$1",[s.league.id]);
  assert.deepEqual(lock.rows[0],{active:false,team_id:"a"});
}));
test("the same identity is available in a separate league",async()=>isolated(async(s,c)=>{
  const other=fixture();await insert(c,other);
  await applyCommand(c,s,"test-a",{action:"draft",playerId:s.players[0]!.id});
  await applyCommand(c,other,"test-a",{action:"draft",playerId:other.players[0]!.id});
  const count=await c.query("SELECT count(*) FROM classic_identity_locks WHERE league_id=ANY($1::text[])",[[s.league.id,other.league.id]]);
  assert.equal(Number(count.rows[0].count),2);
}));
test("trades transfer both database locks atomically and keep draft pick records",async()=>isolated(async(s,c)=>{
  await applyCommand(c,s,"test-a",{action:"draft",playerId:s.players[0]!.id});
  await applyCommand(c,s,"test-b",{action:"draft",playerId:s.players[1]!.id});
  s.league.status="completed";
  await applyCommand(c,s,"test-a",{action:"proposeTrade",teamId:"b",offeredId:s.players[0]!.id,requestedId:s.players[1]!.id});
  const trade=s.trades[0]!;
  await assert.rejects(applyCommand(c,s,"test-a",{action:"acceptTrade",tradeId:trade.id}),/receiving manager/);
  await applyCommand(c,s,"test-b",{action:"acceptTrade",tradeId:trade.id});
  const state=await readState(c,s.league.id);
  assert.equal(state.acquisitions.find(a=>a.playerId===s.players[0]!.id)?.teamId,"b");
  assert.equal(state.acquisitions.find(a=>a.playerId===s.players[1]!.id)?.teamId,"a");
  assert.deepEqual(state.acquisitions.map(a=>a.pickNumber),[1,2]);
}));
test("production excludes sample and unverified records",async()=>isolated(async(s,c)=>{
  s.league.mode="production";
  await assert.rejects(applyCommand(c,s,"test-a",{action:"draft",playerId:s.players[0]!.id}),/retirement-verified/);
}));
test("league and commissioner permissions are enforced",async()=>isolated(async(s,c)=>{
  await assert.rejects(applyCommand(c,s,"stranger",{action:"pause"}),/not a manager/);
  await assert.rejects(applyCommand(c,s,"test-b",{action:"pause"}),/commissioner/);
  await assert.rejects(applyCommand(c,s,"test-b",{action:"draft",playerId:s.players[0]!.id}),/not your team's turn/);
}));
test("waiver claims use priority and preserve the losing claim outcome",async()=>isolated(async(s,c)=>{
  s.league.status="completed";s.league.waiverHours=1;
  const p=s.players[0]!;
  await applyCommand(c,s,"test-b",{action:"claim",playerId:p.id});
  await applyCommand(c,s,"test-a",{action:"claim",playerId:p.id});
  s.claims.forEach(claim=>claim.eligibleAt=new Date(0).toISOString());
  await applyCommand(c,s,"test-a",{action:"processWaivers"});
  assert.equal(s.acquisitions[0]?.teamId,"a");
  assert.equal(s.claims.find(claim=>claim.teamId==="b")?.status,"failed");
}));
test("position limits reject a seventh bench player when no starter slot fits",()=>{
  const s=fixture(),p=s.players.find(p=>p.position==="QB")!;
  s.acquisitions=Array.from({length:7},(_,i)=>({canonicalId:`qb${i}`,playerId:`qb${i}`,teamId:"a",active:true,slot:i?"Bench":"QB",pickNumber:i+1}));
  assert.throws(()=>availableSlot(s,"a",p),/No eligible roster slot/);
});
test("simultaneous picks cannot create duplicate permanent identity locks",async()=>{
  const s=fixture();
  await transaction(c=>insert(c,s));
  const attempt=()=>transaction(async c=>{
    const state=await readState(c,s.league.id,true);
    await applyCommand(c,state,"test-a",{action:"draft",playerId:state.players[0]!.id});
    await writeState(c,state);
  });
  try {
    const result=await Promise.allSettled([attempt(),attempt()]);
    assert.equal(result.filter(r=>r.status==="fulfilled").length,1);
    assert.equal(result.filter(r=>r.status==="rejected").length,1);
    const count=await pool.query("SELECT count(*) FROM classic_identity_locks WHERE league_id=$1",[s.league.id]);
    assert.equal(Number(count.rows[0].count),1);
  } finally {
    await pool.query("DELETE FROM classic_identity_locks WHERE league_id=$1",[s.league.id]);
    await pool.query("DELETE FROM classic_leagues WHERE id=$1",[s.league.id]);
  }
});
test("the database composite primary key rejects duplicate identities independently of UI",async()=>isolated(async(s,c)=>{
  const p=s.players[0]!;
  await applyCommand(c,s,"test-a",{action:"draft",playerId:p.id});
  await c.query("SAVEPOINT constraint_test");
  await assert.rejects(c.query("INSERT INTO classic_identity_locks (league_id,canonical_id,player_id,team_id,slot) VALUES ($1,$2,$3,'b','WR')",[s.league.id,p.canonicalId,p.id]),{code:"23505"});
  await c.query("ROLLBACK TO SAVEPOINT constraint_test");
}));
after(async()=>{await pool.end();});
