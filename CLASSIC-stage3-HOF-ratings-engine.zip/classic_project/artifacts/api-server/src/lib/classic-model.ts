import { randomUUID } from "node:crypto";
import type { LeagueState, LeagueCommand } from "@workspace/api-zod";

export type State = Omit<LeagueState, "currentTeamId" | "nextTeamId" | "viewerTeamId" | "isCommissioner">;
export type Command = LeagueCommand;
export type Player = State["players"][number];
export type Team = State["teams"][number];
export type Acquisition = State["acquisitions"][number];
export class RuleError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}
export function ensure(value: unknown, message: string, status = 400): asserts value {
  if (!value) throw new RuleError(message, status);
}
export const uid = () => randomUUID();
export const SLOTS: Record<string, number> = { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, K: 1, DEF: 1, Bench: 6 };
export function teamForPick(teams: Team[], pick: number): Team | undefined {
  if (!teams.length || pick > teams.length * 15) return undefined;
  const ordered = [...teams].sort((a, b) => a.draftOrder - b.draftOrder);
  const round = Math.floor((pick - 1) / teams.length);
  const offset = (pick - 1) % teams.length;
  return ordered[round % 2 ? teams.length - 1 - offset : offset];
}
export function activity(s: State, message: string) {
  s.activity.unshift({ id: uid(), message, createdAt: new Date().toISOString() });
}
export function eligible(s: State, p: Player) {
  ensure(s.league.mode === "sample" || (!p.sample && p.retired && p.approved),
    "Production drafts require a non-sample, retirement-verified and season-approved player.");
}
export function slotAllowed(position: string, slot: string) {
  return slot === "Bench" || position === slot || (slot === "FLEX" && ["RB", "WR", "TE"].includes(position));
}
export function availableSlot(s: State, teamId: string, player: Player, exceptCanonical?: string): string {
  const roster = s.acquisitions.filter(a => a.teamId === teamId && a.active && a.canonicalId !== exceptCanonical);
  ensure(roster.length < 15, "This team's 15-player roster is full.");
  const slot = Object.keys(SLOTS).find(slot => slotAllowed(player.position, slot) && roster.filter(a => a.slot === slot).length < SLOTS[slot]!);
  ensure(slot, "No eligible roster slot is available. Move or drop a player first.");
  return slot;
}
export function verifyIdentity(s: State, input: NonNullable<Command["player"]>) {
  const existing = s.players.find(p => p.canonicalId === input.canonicalId);
  ensure(!existing || (existing.name.toLowerCase() === input.name.toLowerCase() && existing.position === input.position),
    "This canonical ID already identifies a different player or position.");
  const sameName = s.players.find(p => p.name.toLowerCase() === input.name.toLowerCase() && p.canonicalId !== input.canonicalId);
  ensure(!sameName, "This name already has a canonical ID. Reuse that identity for every season.");
  ensure(!s.players.some(p => p.canonicalId === input.canonicalId && p.season === input.season), "This player-season already exists.");
}
