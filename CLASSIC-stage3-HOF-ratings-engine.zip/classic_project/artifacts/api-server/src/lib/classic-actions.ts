import { activity, availableSlot, eligible, ensure, SLOTS, slotAllowed, teamForPick, uid, verifyIdentity, type Acquisition, type Command, type Player, type State, type Team } from "./classic-model";
import { member, type Client } from "./classic-store";

async function acquire(client: Client, s: State, team: Team, p: Player, pickNumber: number | null) {
  eligible(s,p);
  const lock = s.acquisitions.find(a=>a.canonicalId === p.canonicalId);
  ensure(!lock || lock.teamId === team.id, "This player identity is permanently locked to another team.", 409);
  ensure(!lock?.active, "This identity is already on your roster.", 409);
  const slot = availableSlot(s,team.id,p);
  if (lock) {
    ensure(lock.playerId === p.id, "Reacquire the originally selected season; an identity's season cannot be changed.");
    await client.query("UPDATE classic_identity_locks SET active=true,slot=$3 WHERE league_id=$1 AND canonical_id=$2",[s.league.id,p.canonicalId,slot]);
    lock.active = true; lock.slot = slot;
  } else {
    await client.query("INSERT INTO classic_identity_locks (league_id,canonical_id,player_id,team_id,active,slot,pick_number) VALUES ($1,$2,$3,$4,true,$5,$6)",[s.league.id,p.canonicalId,p.id,team.id,slot,pickNumber]);
    s.acquisitions.push({canonicalId:p.canonicalId,playerId:p.id,teamId:team.id,active:true,slot,pickNumber});
  }
}
function playerFor(s: State, playerId?: string) {
  const p = s.players.find(p=>p.id === playerId);
  ensure(p,"Player-season not found.",404);
  return p;
}
function owned(s: State, team: Team, playerId?: string) {
  const a = s.acquisitions.find(a=>a.playerId === playerId && a.teamId === team.id && a.active);
  ensure(a,"You do not own this active player.",403);
  return a;
}
function postDraft(s: State) { ensure(s.league.status === "completed","Waivers and free agency open after the draft is complete."); }
export async function applyCommand(client: Client, s: State, userId: string, cmd: Command): Promise<string> {
  const me = member(s,userId);
  const commissioner = () => ensure(s.league.commissionerId === userId,"Only the commissioner can perform this action.",403);
  let message = "";
  switch(cmd.action) {
    case "start":
      commissioner();
      ensure(s.league.status === "pre_draft","This draft has already started.");
      ensure(s.teams.length >= 2,"At least two managers must join before starting.");
      ensure(s.teams.every((t,i,ts)=>ts.filter(x=>x.draftOrder === t.draftOrder).length===1 && t.draftOrder>=1 && t.draftOrder<=ts.length),"Every team must have a unique, consecutive draft order.");
      ensure(new Set(s.players.filter(p=>s.league.mode==="sample" || (!p.sample && p.approved && p.retired)).map(p=>p.canonicalId)).size >= s.teams.length*15,
        "Add enough eligible, unique player identities to fill every 15-player roster before starting.");
      s.league.status="live"; message="The snake draft has started."; break;
    case "pause":
      commissioner(); ensure(s.league.status==="live","Only a live draft can be paused.");
      s.league.status="paused"; message="The commissioner paused the draft."; break;
    case "resume":
      commissioner(); ensure(s.league.status==="paused","Only a paused draft can be resumed.");
      s.league.status="live"; message="The commissioner resumed the draft."; break;
    case "draft": {
      ensure(s.league.status==="live","The draft is not live.");
      ensure(teamForPick(s.teams,s.league.pickNumber)?.id===me.id,"It is not your team's turn.",409);
      const p=playerFor(s,cmd.playerId);
      ensure(!s.acquisitions.some(a=>a.canonicalId===p.canonicalId),"This player identity is permanently locked in this league.",409);
      await acquire(client,s,me,p,s.league.pickNumber);
      message=`Pick ${s.league.pickNumber}: ${me.name} drafted ${p.name}, ${p.season}. All seasons identity-locked.`;
      s.league.pickNumber++;
      if(s.league.pickNumber>s.teams.length*15) s.league.status="completed";
      break;
    }
    case "drop": {
      const a=owned(s,me,cmd.playerId);
      await client.query("UPDATE classic_identity_locks SET active=false WHERE league_id=$1 AND canonical_id=$2",[s.league.id,a.canonicalId]);
      a.active=false;
      message=`${me.name} dropped ${playerFor(s,a.playerId).name}. Identity remains permanently locked to ${me.name}.`; break;
    }
    case "setSlot": {
      const a=owned(s,me,cmd.playerId), p=playerFor(s,cmd.playerId);
      ensure(cmd.slot && SLOTS[cmd.slot],"Choose a valid roster slot.");
      ensure(slotAllowed(p.position,cmd.slot),"This position is not eligible for that slot.");
      ensure(s.acquisitions.filter(x=>x.teamId===me.id && x.active && x.canonicalId!==a.canonicalId && x.slot===cmd.slot).length < SLOTS[cmd.slot]!,"That roster slot is full.");
      a.slot=cmd.slot;
      await client.query("UPDATE classic_identity_locks SET slot=$3 WHERE league_id=$1 AND canonical_id=$2",[s.league.id,a.canonicalId,a.slot]);
      message=`${me.name} moved ${p.name} to ${a.slot}.`; break;
    }
    case "acquire": {
      postDraft(s); ensure(s.league.waiverHours===0,"Waivers are enabled. Submit a claim instead.");
      const p=playerFor(s,cmd.playerId); await acquire(client,s,me,p,null);
      message=`${me.name} acquired ${p.name}, ${p.season}.`; break;
    }
    case "claim": {
      postDraft(s); ensure(s.league.waiverHours>0,"Waivers are disabled; use free agency.");
      const p=playerFor(s,cmd.playerId); eligible(s,p);
      const lock=s.acquisitions.find(a=>a.canonicalId===p.canonicalId);
      ensure(!lock || (!lock.active && lock.teamId===me.id && lock.playerId===p.id),"This identity is locked and unavailable to your team.",409);
      availableSlot(s,me.id,p);
      ensure(!s.claims.some(c=>c.teamId===me.id && c.playerId===p.id && c.status==="pending"),"You already have a pending claim.");
      // A shared rolling waiver window allows priority, not submission time,
      // to decide claims that compete for the same canonical identity.
      const competing=s.claims.find(c=>c.status==="pending" && playerFor(s,c.playerId).canonicalId===p.canonicalId && new Date(c.eligibleAt).getTime()>Date.now());
      s.claims.push({id:uid(),teamId:me.id,playerId:p.id,status:"pending",eligibleAt:competing?.eligibleAt ?? new Date(Date.now()+s.league.waiverHours*3600000).toISOString()});
      message=`${me.name} submitted a waiver claim for ${p.name}.`; break;
    }
    case "processWaivers": {
      commissioner(); postDraft(s);
      const due=s.claims.filter(c=>c.status==="pending" && new Date(c.eligibleAt).getTime()<=Date.now())
        .sort((a,b)=>s.teams.find(t=>t.id===a.teamId)!.waiverPriority-s.teams.find(t=>t.id===b.teamId)!.waiverPriority);
      let won=0;
      // One successful claim per team per priority pass, then move winners
      // to the bottom and continue until all due claims have been considered.
      while(due.length) {
        due.sort((a,b)=>s.teams.find(t=>t.id===a.teamId)!.waiverPriority-s.teams.find(t=>t.id===b.teamId)!.waiverPriority);
        const c=due.shift()!, team=s.teams.find(t=>t.id===c.teamId)!;
        const p=playerFor(s,c.playerId);
        const lock=s.acquisitions.find(a=>a.canonicalId===p.canonicalId);
        let slotAvailable=true;
        try { eligible(s,p); availableSlot(s,team.id,p); } catch { slotAvailable=false; }
        if(!slotAvailable || (lock && (lock.active || lock.teamId!==team.id || lock.playerId!==p.id))) { c.status="failed"; continue; }
        await acquire(client,s,team,p,null);
        c.status="awarded"; won++;
        const old=team.waiverPriority;
        s.teams.filter(t=>t.waiverPriority>old).forEach(t=>t.waiverPriority--);
        team.waiverPriority=s.teams.length;
        activity(s,`${team.name} won ${p.name} on waivers.`);
      }
      message=`Processed ${won} successful waiver claim${won===1?"":"s"}. Claims not yet due remain pending.`; break;
    }
    case "updateSettings":
      commissioner(); ensure(cmd.waiverHours!==undefined,"Provide waiver duration.");
      ensure(!s.claims.some(c=>c.status==="pending"),"Process pending claims before changing waiver rules.");
      s.league.waiverHours=cmd.waiverHours; message=`Waiver duration set to ${cmd.waiverHours} hours.`; break;
    case "updateTeam": {
      commissioner();
      const team=s.teams.find(t=>t.id===cmd.teamId); ensure(team,"Team not found.",404);
      if(cmd.name) {
        ensure(cmd.name.trim().length>=2,"Team name must contain at least two characters.");
        team.name=cmd.name.trim();
      }
      if(cmd.draftOrder!==undefined) {
        ensure(s.league.status==="pre_draft","Draft order cannot change after the draft starts.");
        ensure(cmd.draftOrder<=s.teams.length,"Draft order cannot exceed the number of joined teams.");
        const other=s.teams.find(t=>t.draftOrder===cmd.draftOrder);
        if(other) other.draftOrder=team.draftOrder;
        team.draftOrder=cmd.draftOrder;
      }
      message=`Commissioner updated ${team.name}.`; break;
    }
    case "proposeTrade": {
      postDraft(s);
      const receiving=s.teams.find(t=>t.id===cmd.teamId);
      ensure(receiving && receiving.id!==me.id,"Choose another team.");
      const a=owned(s,me,cmd.offeredId), b=owned(s,receiving,cmd.requestedId);
      s.trades.push({id:uid(),fromTeamId:me.id,toTeamId:receiving.id,offeredId:a.playerId,requestedId:b.playerId,status:"pending"});
      message=`${me.name} proposed a trade to ${receiving.name}.`; break;
    }
    case "acceptTrade":
    case "rejectTrade": {
      postDraft(s);
      const trade=s.trades.find(t=>t.id===cmd.tradeId); ensure(trade && trade.status==="pending","Pending trade not found.",404);
      ensure(trade.toTeamId===me.id,"Only the receiving manager may respond to this trade.",403);
      if(cmd.action==="rejectTrade") { trade.status="rejected"; message=`${me.name} declined a trade.`; break; }
      const from=s.teams.find(t=>t.id===trade.fromTeamId)!;
      const a=owned(s,from,trade.offeredId), b=owned(s,me,trade.requestedId);
      const aPlayer=playerFor(s,a.playerId),bPlayer=playerFor(s,b.playerId);
      eligible(s,aPlayer); eligible(s,bPlayer);
      // Remove outgoing players from the capacity calculation before replacing.
      const outgoingA=a.active, outgoingB=b.active;
      a.active=false;b.active=false;
      let fromSlot:string,toSlot:string;
      try { fromSlot=availableSlot(s,from.id,bPlayer); toSlot=availableSlot(s,me.id,aPlayer); }
      finally {a.active=outgoingA;b.active=outgoingB;}
      a.teamId=me.id;a.slot=toSlot;b.teamId=from.id;b.slot=fromSlot;
      await client.query("UPDATE classic_identity_locks SET team_id=$3,slot=$4 WHERE league_id=$1 AND canonical_id=$2",[s.league.id,a.canonicalId,a.teamId,a.slot]);
      await client.query("UPDATE classic_identity_locks SET team_id=$3,slot=$4 WHERE league_id=$1 AND canonical_id=$2",[s.league.id,b.canonicalId,b.teamId,b.slot]);
      trade.status="accepted"; message=`${from.name} and ${me.name} traded ${aPlayer.name} for ${bPlayer.name}. Both permanent identity locks transferred.`; break;
    }
    case "addPlayer":
    case "importPlayers": {
      commissioner();
      const inputs=cmd.action==="addPlayer"?[cmd.player]:cmd.players;
      ensure(inputs?.length,"Provide at least one player record.");
      for(const input of inputs) {
        ensure(input,"Player fields are required.");
        const clean={...input,canonicalId:input.canonicalId.trim().toLowerCase(),name:input.name.trim(),nflTeam:input.nflTeam.trim().toUpperCase()};
        ensure(/^[a-z0-9][a-z0-9_-]*$/.test(clean.canonicalId),"Canonical IDs must contain lowercase letters, numbers, dashes or underscores.");
        ensure(clean.name && clean.nflTeam,"Player name and NFL team cannot be blank.");
        verifyIdentity(s,clean);
        s.players.push({...clean,id:uid(),sample:false});
      }
      message=`Commissioner added ${inputs.length} player-season record${inputs.length===1?"":"s"}. Verification reflects commissioner attestation, not an external data provider.`; break;
    }
    default: ensure(false,"Unknown action.");
  }
  activity(s,message);
  return message;
}
