import test from "node:test";
import assert from "node:assert/strict";
import { calculateSeasonRating, type VerifiedSeasonTotal } from "./historical-ratings";

function cohort(): VerifiedSeasonTotal[] {
  return Array.from({ length: 10 }, (_, i) => ({
    playerId: `p${i}`, canonicalId: `p${i}`, season: 1995, position: "RB" as const,
    pprFantasyPoints: i * 100, sourceUrl: "https://example.test/verified-stats.csv", verified: true,
  }));
}

test("calculates a position-and-season percentile with a transparent cohort size", () => {
  const records = cohort();
  const result = calculateSeasonRating(records[9]!, records);
  assert.equal(result?.score, 100);
  assert.equal(result?.tier, "Legendary");
  assert.equal(result?.cohortSize, 10);
});

test("does not rate unverified data or a cohort smaller than ten", () => {
  const records = cohort();
  assert.equal(calculateSeasonRating({ ...records[0]!, verified: false }, records), null);
  assert.equal(calculateSeasonRating(records[0]!, records.slice(0, 9)), null);
});

test("does not mix positions or seasons in a rating cohort", () => {
  const records = cohort();
  const result = calculateSeasonRating(records[0]!, records.map((r) => ({ ...r, position: "WR" as const })));
  assert.equal(result, null);
});
