import { pool, type PoolClient } from "@workspace/db";
import { ensure, teamForPick, type State, type Acquisition } from "./classic-model";
import { makeSample } from "./classic-sample";

export type Client = PoolClient;
export async function transaction<T>(work: (client: Client) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally { client.release(); }
}
export async function readState(client: Client, id: string, lock = false): Promise<State> {
  const result = await client.query(`SELECT state FROM classic_leagues WHERE id=$1${lock ? " FOR UPDATE" : ""}`, [id]);
  ensure(result.rows[0], "League not found.", 404);
  const state = result.rows[0].state as State;
  const locks = await client.query(`SELECT canonical_id AS "canonicalId",player_id AS "playerId",team_id AS "teamId",active,slot,pick_number AS "pickNumber" FROM classic_identity_locks WHERE league_id=$1 ORDER BY pick_number NULLS LAST,canonical_id`, [id]);
  state.acquisitions = locks.rows as Acquisition[];
  return state;
}
export async function writeState(client: Client, state: State) {
  // Locks are never deleted and are not duplicated in the JSON aggregate.
  await client.query("UPDATE classic_leagues SET state=$2::jsonb WHERE id=$1", [state.league.id, JSON.stringify({...state, acquisitions:[]})]);
}
export function member(state: State, userId: string) {
  const team = state.teams.find(t => t.userId === userId);
  ensure(team, "You are not a manager in this private league.", 403);
  return team;
}
export function viewState(state: State, userId?: string) {
  return {
    ...state,
    currentTeamId: teamForPick(state.teams, state.league.pickNumber)?.id ?? null,
    nextTeamId: teamForPick(state.teams, state.league.pickNumber + 1)?.id ?? null,
    viewerTeamId: state.teams.find(t=>t.userId === userId)?.id ?? null,
    isCommissioner: !!userId && state.league.commissionerId === userId,
  };
}
export const publicSample = makeSample();
