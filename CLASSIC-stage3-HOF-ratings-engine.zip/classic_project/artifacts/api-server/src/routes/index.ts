import { Router, type IRouter } from "express";
import healthRouter from "./health";
import classicRouter from "./classic";
import mockDraftRouter from "./mock-drafts";

const router: IRouter = Router();

router.use(healthRouter);
router.use(classicRouter);
router.use(mockDraftRouter);

export default router;
