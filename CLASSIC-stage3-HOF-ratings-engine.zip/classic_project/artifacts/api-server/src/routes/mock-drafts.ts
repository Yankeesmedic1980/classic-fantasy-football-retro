import { Router, type Request } from "express";
import { getAuth } from "@clerk/express";
import { pool } from "@workspace/db";
import { CreateMockDraftBody, JoinMockDraftBody, GetMockDraftParams, GetMockDraftResponse, MockDraftActionBody, MockDraftActionParams, ExportMockDraftParams, ExportMockDraftResponse, ListMockDraftsResponse, CreateMockDraftResponse, JoinMockDraftResponse, MockDraftActionResponse } from "@workspace/api-zod";
import { ensure, type State } from "../lib/classic-model";
import { samplePlayers } from "../lib/classic-sample";
import { assertMember, createMockDocument, joinMockSeat, mockSummary, mockView, type MockDocument } from "../lib/mock-model";
import { advanceMock, runMockCommand } from "../lib/mock-engine";
import { insertMock, loadMock, mockTransaction, saveMock } from "../lib/mock-store";

const router = Router();
function user(req: Request) {
  const id = getAuth(req).userId;
  ensure(id, "Sign in to create or join private mock drafts.", 401);
  return id;
}
router.use("/mock-drafts", (_req, res, next) => { res.setHeader("Cache-Control", "no-store"); next(); });
router.get("/mock-drafts", async (req, res): Promise<void> => {
  const id = user(req);
  const result = await pool.query(`SELECT state FROM classic_mock_sessions WHERE EXISTS
    (SELECT 1 FROM jsonb_array_elements(state->'teams') AS team WHERE team->>'userId'=$1) ORDER BY created_at DESC`, [id]);
  res.json(ListMockDraftsResponse.parse(result.rows.map(r => mockSummary(r.state as MockDocument))));
});
router.post("/mock-drafts", async (req, res): Promise<void> => {
  const id = user(req), input = CreateMockDraftBody.parse(req.body);
  const result = await mockTransaction(async client => {
    let players = samplePlayers(), label = "Illustrative sample player seasons — unverified, not official historical statistics";
    if (input.poolSource === "league") {
      ensure(input.sourceLeagueId && input.sourceLeagueId !== "sample", "Choose a real league you belong to, not the generated public demo.");
      // A READ ONLY snapshot. No real league or permanent lock is ever modified.
      const source = await client.query("SELECT state FROM classic_leagues WHERE id=$1", [input.sourceLeagueId]);
      ensure(source.rows[0], "Source league not found.", 404);
      const state = source.rows[0].state as State;
      ensure(state.teams.some(t => t.userId === id), "You cannot copy a private league's player records without membership.", 403);
      players = state.players.filter(p => !p.sample && p.retired && p.approved);
      label = `Approved retired player snapshot from ${state.league.name} — commissioner-attested, not externally verified`;
    }
    const doc = createMockDocument(input, id, players, label);
    await insertMock(client, doc);
    return { id: doc.id, message: "Private mock created. Invite friends or start with CPU seats." };
  });
  res.status(201).json(CreateMockDraftResponse.parse(result));
});
router.post("/mock-drafts/join", async (req, res): Promise<void> => {
  const id = user(req), input = JoinMockDraftBody.parse(req.body);
  const result = await mockTransaction(async client => {
    const found = await client.query("SELECT id FROM classic_mock_sessions WHERE invite_code=$1", [input.code.trim().toUpperCase()]);
    ensure(found.rows[0], "Mock invitation not found.", 404);
    const s = await loadMock(client, found.rows[0].id);
    if (!s.teams.some(t => t.userId === id)) {
      joinMockSeat(s, id, input.name);
      await saveMock(client, s);
    }
    return { id: s.id, message: "You joined the mock draft." };
  });
  res.json(JoinMockDraftResponse.parse(result));
});
router.get("/mock-drafts/:mockId", async (req, res): Promise<void> => {
  const id = user(req), { mockId } = GetMockDraftParams.parse(req.params);
  const view = await mockTransaction(async client => {
    const s = await loadMock(client, mockId);
    assertMember(s, id);
    await advanceMock(client, s);
    await saveMock(client, s);
    return mockView(s, id);
  });
  res.json(GetMockDraftResponse.parse(view));
});
router.post("/mock-drafts/:mockId/actions", async (req, res): Promise<void> => {
  const id = user(req), { mockId } = MockDraftActionParams.parse(req.params), cmd = MockDraftActionBody.parse(req.body);
  const result = await mockTransaction(async client => {
    const s = await loadMock(client, mockId);
    assertMember(s, id);
    // Host pause/restart must not wait behind thirty automatic catch-up picks.
    if (cmd.action !== "pause" && cmd.action !== "restart") await advanceMock(client, s);
    const result = await runMockCommand(client, s, id, cmd);
    await saveMock(client, s);
    return result;
  });
  res.json(MockDraftActionResponse.parse(result));
});
router.get("/mock-drafts/:mockId/export", async (req, res): Promise<void> => {
  const id = user(req), { mockId } = ExportMockDraftParams.parse(req.params);
  const result = await mockTransaction(async client => {
    const s = await loadMock(client, mockId);
    return mockView(s, id);
  });
  res.setHeader("Content-Disposition", `attachment; filename="classic-mock-${mockId}.json"`);
  res.json(ExportMockDraftResponse.parse(result));
});
export default router;
