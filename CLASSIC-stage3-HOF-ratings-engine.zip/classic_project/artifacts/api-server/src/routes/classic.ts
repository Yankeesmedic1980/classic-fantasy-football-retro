import { Router, type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { randomBytes } from "node:crypto";
import { CreateLeagueBody, CreateLeagueResponse, JoinLeagueBody, JoinLeagueResponse, GetLeagueParams, GetLeagueResponse, LeagueActionBody, LeagueActionParams, LeagueActionResponse, ListLeaguesResponse, ExportLeagueParams, ExportLeagueResponse } from "@workspace/api-zod";
import { pool } from "@workspace/db";
import { activity, ensure, RuleError, uid, type State } from "../lib/classic-model";
import { member, publicSample, readState, transaction, viewState, writeState } from "../lib/classic-store";
import { samplePlayers } from "../lib/classic-sample";
import { applyCommand } from "../lib/classic-actions";

const router = Router();
function user(req: Request) {
  const id=getAuth(req).userId;
  ensure(id,"Sign in to manage a private league.",401);
  return id;
}
router.use((_req,res,next)=> {res.setHeader("Cache-Control","no-store");next();});
router.get("/leagues",async(req,res):Promise<void>=>{
  const userId=user(req);
  const result=await pool.query("SELECT state FROM classic_leagues WHERE EXISTS (SELECT 1 FROM jsonb_array_elements(state->'teams') AS team WHERE team->>'userId'=$1) ORDER BY created_at DESC",[userId]);
  res.json(ListLeaguesResponse.parse(result.rows.map(r=>(r.state as State).league)));
});
router.post("/leagues",async(req,res):Promise<void>=>{
  const userId=user(req), input=CreateLeagueBody.parse(req.body);
  ensure(input.name.trim().length>=2 && input.teamName.trim().length>=2,"League and team names must contain at least two characters.");
  const id=uid(),code=randomBytes(9).toString("hex").toUpperCase();
  const state:State={
    league:{id,name:input.name.trim(),commissionerId:userId,mode:input.mode,maxTeams:input.maxTeams,status:"pre_draft",pickNumber:1,waiverHours:24,inviteCode:code},
    teams:[{id:uid(),userId,name:input.teamName.trim(),draftOrder:1,waiverPriority:1}],
    players:input.mode==="sample"?samplePlayers():[],acquisitions:[],activity:[],claims:[],trades:[],
  };
  activity(state,`${state.teams[0]!.name} created the league. ${input.mode==="sample"?"Playtest sample data is not verified historical data.":"Production mode: only commissioner-approved, retirement-verified records are eligible."}`);
  await pool.query("INSERT INTO classic_leagues (id,invite_code,state) VALUES ($1,$2,$3::jsonb)",[id,code,JSON.stringify(state)]);
  res.status(201).json(CreateLeagueResponse.parse(state.league));
});
router.post("/leagues/join",async(req,res):Promise<void>=>{
  const userId=user(req),input=JoinLeagueBody.parse(req.body);
  ensure(input.teamName.trim().length>=2,"Team name must contain at least two characters.");
  const league=await transaction(async client=>{
    const result=await client.query("SELECT id FROM classic_leagues WHERE invite_code=$1",[input.code.trim().toUpperCase()]);
    ensure(result.rows[0],"Invitation code not found.",404);
    const state=await readState(client,result.rows[0].id,true);
    if(state.teams.some(t=>t.userId===userId)) return state.league;
    ensure(state.league.status==="pre_draft","This draft has already started; new managers cannot join.");
    ensure(state.teams.length<state.league.maxTeams,"This league is full.",409);
    state.teams.push({id:uid(),name:input.teamName.trim(),userId,draftOrder:state.teams.length+1,waiverPriority:state.teams.length+1});
    activity(state,`${input.teamName.trim()} joined the league.`);
    await writeState(client,state);
    return state.league;
  });
  res.json(JoinLeagueResponse.parse(league));
});
router.get("/leagues/:leagueId",async(req,res):Promise<void>=>{
  const {leagueId}=GetLeagueParams.parse(req.params);
  if(leagueId==="sample") {res.json(GetLeagueResponse.parse(viewState(publicSample)));return;}
  const userId=user(req);
  const state=await transaction(async client=>{
    const state=await readState(client,leagueId,true);
    member(state,userId);
    return viewState(state,userId);
  });
  res.json(GetLeagueResponse.parse(state));
});
router.post("/leagues/:leagueId/actions",async(req,res):Promise<void>=>{
  const userId=user(req),{leagueId}=LeagueActionParams.parse(req.params),cmd=LeagueActionBody.parse(req.body);
  ensure(leagueId!=="sample","The public sample is read-only. Create your own league to play.",403);
  const message=await transaction(async client=>{
    const state=await readState(client,leagueId,true);
    const message=await applyCommand(client,state,userId,cmd);
    await writeState(client,state);
    return message;
  });
  res.json(LeagueActionResponse.parse({message}));
});
router.get("/leagues/:leagueId/export",async(req,res):Promise<void>=>{
  const userId=user(req),{leagueId}=ExportLeagueParams.parse(req.params);
  const state=await transaction(async client=>{
    const state=await readState(client,leagueId,true);
    ensure(state.league.commissionerId===userId,"Only the commissioner can export league data.",403);
    return viewState(state,userId);
  });
  res.setHeader("Content-Disposition",`attachment; filename="classic-league-${leagueId}.json"`);
  res.json(ExportLeagueResponse.parse(state));
});
export function classicErrors(error: unknown, req: Request, res: Response, _next: NextFunction) {
  if(error instanceof RuleError) {res.status(error.status).json({error:error.message});return;}
  if(error && typeof error==="object" && "name" in error && error.name==="ZodError") {
    res.status(400).json({error:"Invalid request. Check required fields, position, season, and numeric limits."});return;
  }
  if(error && typeof error==="object" && "code" in error && error.code==="23505") {
    res.status(409).json({error:"This pick or player identity is already locked. Refresh the league and try another player."});return;
  }
  req.log.error({err:error},"League request failed");
  res.status(500).json({error:"The request could not be saved. No partial changes were applied. Please try again."});
}
export default router;
