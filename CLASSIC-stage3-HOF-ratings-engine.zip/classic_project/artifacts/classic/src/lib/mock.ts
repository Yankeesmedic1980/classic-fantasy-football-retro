import { useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import {
  getGetMockDraftQueryKey,
  getListMockDraftsQueryKey,
  useMockDraftAction,
  type MockCommand,
  type MockState,
  type MockTeam,
} from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { errMsg } from "@/lib/league";

export const TEAM_COUNTS = [4, 6, 8, 10, 12] as const;
export const MOCK_ROUNDS = 15;

export function useMockPageMeta(title: string) {
  useEffect(() => {
    const previous = document.title;
    const meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    const oldDescription = meta?.content;
    document.title = `${title} | CLASSIC`;
    if (meta) meta.content = "Private all-era practice drafts with friends or basic CPU managers. Mock-only identity locks, saved results, and no changes to real leagues.";
    return () => {
      document.title = previous;
      if (meta && oldDescription !== undefined) meta.content = oldDescription;
    };
  }, [title]);
}

export const MOCK_STATUS: Record<string, { label: string; tone: string }> = {
  lobby: { label: "Lobby", tone: "bg-secondary text-secondary-foreground" },
  drafting: { label: "Drafting", tone: "bg-primary text-primary-foreground" },
  paused: { label: "Paused", tone: "bg-[hsl(28_85%_56%/.18)] text-[hsl(28_90%_70%)]" },
  completed: { label: "Completed", tone: "bg-[hsl(152_46%_48%/.16)] text-[hsl(152_55%_66%)]" },
};

/** Team on the clock for a given 1-based pick number in a snake draft. */
export function teamForPick(order: MockTeam[], pick: number): MockTeam | undefined {
  const n = order.length;
  if (!n) return undefined;
  const round = Math.ceil(pick / n);
  const i = (pick - 1) % n;
  return order[round % 2 === 1 ? i : n - 1 - i];
}

export function mockDerive(s: MockState) {
  const order = [...s.teams].sort((a, b) => a.draftOrder - b.draftOrder);
  const n = order.length;
  const total = n * MOCK_ROUNDS;
  const playersById = new Map(s.players.map((p) => [p.id, p]));
  const teamsById = new Map(s.teams.map((t) => [t.id, t]));
  const pickByNumber = new Map(s.picks.map((p) => [p.pickNumber, p]));
  const lockedCanon = new Map(s.picks.map((p) => [p.canonicalId, p.teamId]));
  const upcoming: { pick: number; team: MockTeam }[] = [];
  if (s.status !== "completed") {
    for (let k = s.pickNumber; k <= total && upcoming.length < 8; k++) {
      const t = teamForPick(order, k);
      if (t) upcoming.push({ pick: k, team: t });
    }
  }
  return { order, n, total, playersById, teamsById, pickByNumber, lockedCanon, upcoming };
}

export function pickLabel(pick: number, n: number) {
  const round = Math.ceil(pick / n);
  const inRound = ((pick - 1) % n) + 1;
  return `${round}.${String(inRound).padStart(2, "0")}`;
}

export function useMockAct(mockId: string) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const m = useMockDraftAction({
    mutation: {
      onSuccess: (res, vars) => {
        qc.invalidateQueries({ queryKey: getGetMockDraftQueryKey(mockId) });
        qc.invalidateQueries({ queryKey: getListMockDraftsQueryKey() });
        const quiet = vars.data.action.startsWith("queue");
        if (!quiet) toast({ title: res.message || "Done" });
        if (vars.data.action === "restart" && res.id && res.id !== mockId) {
          toast({ title: "Fresh room ready", description: "The previous mock and its results remain in your history." });
          setLocation(`/mock-lab/${res.id}`);
        }
      },
      onError: (e) => toast({ title: "Action rejected", description: errMsg(e), variant: "destructive" }),
    },
  });
  const run = (data: MockCommand) => m.mutate({ mockId, data });
  return { run, pending: m.isPending, variables: m.isPending ? m.variables?.data : undefined };
}
