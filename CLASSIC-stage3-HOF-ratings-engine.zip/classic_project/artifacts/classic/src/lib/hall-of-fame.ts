import type { HallOfFameStatus } from "@/components/hall-of-fame-mark";

/**
 * Verified player entries matched against the Pro Football Hall of Fame's
 * official year-by-year enshrinement list. This initial registry covers the
 * historical players currently present in CLASSIC's illustrative pool.
 * Unknown names deliberately return undefined (not "not inducted").
 */
export const PRO_FOOTBALL_HOF_SOURCE = "https://www.profootballhof.com/hall-of-famers/years";

type Entry = { name: string; inductionYear: number };

const entries: Entry[] = [
  { name: "Jerry Rice", inductionYear: 2010 },
  { name: "Barry Sanders", inductionYear: 2004 },
  { name: "Peyton Manning", inductionYear: 2021 },
  { name: "LaDainian Tomlinson", inductionYear: 2017 },
  { name: "Randy Moss", inductionYear: 2018 },
  { name: "Tony Gonzalez", inductionYear: 2019 },
  { name: "Joe Montana", inductionYear: 2000 },
  { name: "Walter Payton", inductionYear: 1993 },
  { name: "Emmitt Smith", inductionYear: 2010 },
  { name: "Marvin Harrison", inductionYear: 2016 },
  { name: "Terrell Owens", inductionYear: 2018 },
  { name: "Shannon Sharpe", inductionYear: 2011 },
  { name: "Dan Marino", inductionYear: 2005 },
  { name: "Drew Brees", inductionYear: 2026 },
  { name: "Steve Young", inductionYear: 2005 },
  { name: "Kurt Warner", inductionYear: 2017 },
  { name: "Brett Favre", inductionYear: 2016 },
  { name: "Marshall Faulk", inductionYear: 2011 },
  { name: "Eric Dickerson", inductionYear: 1999 },
  { name: "Jim Brown", inductionYear: 1971 },
  { name: "Roger Craig", inductionYear: 2026 },
  { name: "Edgerrin James", inductionYear: 2020 },
  { name: "Thurman Thomas", inductionYear: 2007 },
  { name: "Marcus Allen", inductionYear: 2003 },
  { name: "Terrell Davis", inductionYear: 2017 },
  { name: "Curtis Martin", inductionYear: 2012 },
  { name: "Calvin Johnson", inductionYear: 2021 },
  { name: "Larry Fitzgerald", inductionYear: 2026 },
  { name: "Cris Carter", inductionYear: 2013 },
  { name: "Isaac Bruce", inductionYear: 2020 },
  { name: "Andre Johnson", inductionYear: 2024 },
  { name: "Tim Brown", inductionYear: 2015 },
  { name: "Michael Irvin", inductionYear: 2007 },
  { name: "Sterling Sharpe", inductionYear: 2025 },
  { name: "Antonio Gates", inductionYear: 2025 },
  { name: "Ozzie Newsome", inductionYear: 1999 },
  { name: "Kellen Winslow", inductionYear: 1995 },
  { name: "Adam Vinatieri", inductionYear: 2026 },
  { name: "Morten Andersen", inductionYear: 2017 },
  { name: "John Elway", inductionYear: 2004 },
  { name: "Warren Moon", inductionYear: 2006 },
  { name: "Jim Kelly", inductionYear: 2002 },
  { name: "Troy Aikman", inductionYear: 2006 },
];

function key(name: string): string {
  return name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

const byName = new Map(entries.map((entry) => [key(entry.name), entry]));

export function getHallOfFameStatus(name: string): HallOfFameStatus | undefined {
  const entry = byName.get(key(name));
  return entry ? { status: "inducted", inductionYear: entry.inductionYear, source: PRO_FOOTBALL_HOF_SOURCE } : undefined;
}

export const VERIFIED_HOF_REGISTRY_SIZE = entries.length;
