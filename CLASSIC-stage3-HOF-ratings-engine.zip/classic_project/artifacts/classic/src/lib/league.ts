import type { LeagueState, Player, PlayerInput } from "@workspace/api-client-react";

export const SAMPLE_ID = "sample";
export const ROUNDS = 15;
export const POSITIONS = ["QB", "RB", "WR", "TE", "K", "DEF"] as const;
export const SLOT_LIMITS: { slot: string; max: number }[] = [
  { slot: "QB", max: 1 },
  { slot: "RB", max: 2 },
  { slot: "WR", max: 2 },
  { slot: "TE", max: 1 },
  { slot: "FLEX", max: 1 },
  { slot: "K", max: 1 },
  { slot: "DEF", max: 1 },
  { slot: "Bench", max: 6 },
];

export const POS_COLOR: Record<string, string> = {
  QB: "bg-[hsl(4_70%_56%/.16)] text-[hsl(4_85%_72%)] ring-[hsl(4_70%_56%/.35)]",
  RB: "bg-[hsl(152_46%_48%/.16)] text-[hsl(152_55%_66%)] ring-[hsl(152_46%_48%/.35)]",
  WR: "bg-[hsl(196_62%_52%/.16)] text-[hsl(196_75%_70%)] ring-[hsl(196_62%_52%/.35)]",
  TE: "bg-[hsl(28_85%_56%/.16)] text-[hsl(28_90%_70%)] ring-[hsl(28_85%_56%/.35)]",
  K: "bg-[hsl(266_40%_64%/.16)] text-[hsl(266_60%_80%)] ring-[hsl(266_40%_64%/.35)]",
  DEF: "bg-[hsl(216_18%_62%/.16)] text-[hsl(216_25%_80%)] ring-[hsl(216_18%_62%/.35)]",
};

export const STATUS_LABEL: Record<string, string> = {
  pre_draft: "Pre-draft",
  live: "Draft live",
  paused: "Draft paused",
  completed: "Season open",
};

export function errMsg(e: unknown): string {
  const data = (e as { data?: unknown } | null)?.data;
  if (data && typeof data === "object" && typeof (data as { error?: unknown }).error === "string") return (data as { error: string }).error;
  if (e instanceof Error) return e.message.replace(/^HTTP \d+[^:]*:\s*/, "");
  return "Something went wrong";
}

export function pickMeta(pick: number, teams: number) {
  const round = Math.ceil(pick / teams);
  const inRound = ((pick - 1) % teams) + 1;
  return { round, inRound, label: `${round}.${String(inRound).padStart(2, "0")}` };
}

/** Pick number for a given round/column in snake order. */
export function snakePick(round: number, col: number, teams: number) {
  return round % 2 === 1 ? (round - 1) * teams + col + 1 : (round - 1) * teams + (teams - col);
}

export function derive(state: LeagueState) {
  const playersById = new Map(state.players.map((p) => [p.id, p]));
  const teamsById = new Map(state.teams.map((t) => [t.id, t]));
  const lockedBy = new Map<string, { teamId: string; active: boolean; playerId: string }>();
  for (const a of state.acquisitions) {
    const cur = lockedBy.get(a.canonicalId);
    if (!cur || a.active) lockedBy.set(a.canonicalId, { teamId: a.teamId, active: a.active, playerId: a.playerId });
  }
  const order = [...state.teams].sort((a, b) => a.draftOrder - b.draftOrder);
  const isProd = state.league.mode === "production";
  const eligible = (p: Player) => !isProd || (!p.sample && p.approved && p.retired);
  return { playersById, teamsById, lockedBy, order, eligible };
}

export function teamInitials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

/* ---------- CSV ---------- */
export const CSV_HEADER = ["canonicalId", "name", "position", "nflTeam", "season", "retired", "approved"] as const;

function parseRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else q = false;
      } else field += c;
    } else if (c === '"') q = true;
    else if (c === ",") {
      row.push(field);
      field = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (field !== "" || row.length) {
    row.push(field);
    rows.push(row);
  }
  if (q) throw new Error("CSV has an unclosed quoted field.");
  return rows.filter((r) => r.some((v) => v.trim() !== ""));
}

function bool(v: string): boolean | null {
  const s = v.trim().toLowerCase();
  if (["true", "1", "yes", "y"].includes(s)) return true;
  if (["false", "0", "no", "n"].includes(s)) return false;
  return null;
}

export function parsePlayersCsv(text: string): { players: PlayerInput[]; errors: string[] } {
  let rows: string[][];
  try { rows = parseRows(text.replace(/^\uFEFF/, "")); }
  catch (error) { return { players: [], errors: [error instanceof Error ? error.message : "Malformed CSV."] }; }
  const errors: string[] = [];
  const players: PlayerInput[] = [];
  if (!rows.length) return { players, errors: ["File is empty."] };
  const header = rows[0].map((h) => h.trim());
  if (new Set(header).size !== header.length) return { players: [], errors: ["CSV headers must not contain duplicate columns."] };
  const idx: Record<string, number> = {};
  for (const h of CSV_HEADER) {
    const i = header.indexOf(h);
    if (i === -1) errors.push(`Missing column "${h}".`);
    idx[h] = i;
  }
  if (errors.length) return { players, errors };
  if (rows.length - 1 > 1000) errors.push("Maximum 1000 rows per import.");
  rows.slice(1).forEach((r, n) => {
    const line = n + 2;
    const g = (k: string) => (r[idx[k]] ?? "").trim();
    const rowErr: string[] = [];
    if (r.length !== header.length) rowErr.push("column count does not match the header");
    const canonicalId = g("canonicalId");
    const name = g("name");
    const position = g("position").toUpperCase();
    const nflTeam = g("nflTeam");
    const season = Number(g("season"));
    const retired = bool(g("retired"));
    const approved = bool(g("approved"));
    if (!canonicalId || canonicalId.length > 100) rowErr.push("canonicalId required (max 100)");
    if (!name || name.length > 100) rowErr.push("name required (max 100)");
    if (!(POSITIONS as readonly string[]).includes(position)) rowErr.push(`position "${g("position")}" invalid`);
    if (!nflTeam || nflTeam.length > 40) rowErr.push("nflTeam required (max 40)");
    if (!Number.isInteger(season) || season < 1920 || season > 2026) rowErr.push("season must be 1920-2026");
    if (retired === null) rowErr.push("retired must be true/false");
    if (approved === null) rowErr.push("approved must be true/false");
    if (rowErr.length) errors.push(`Row ${line}: ${rowErr.join("; ")}`);
    else
      players.push({
        canonicalId,
        name,
        position: position as PlayerInput["position"],
        nflTeam,
        season,
        retired: retired!,
        approved: approved!,
      });
  });
  return { players, errors };
}
