import { useQueryClient } from "@tanstack/react-query";
import {
  getGetLeagueQueryKey,
  getListLeaguesQueryKey,
  useLeagueAction,
  type LeagueCommand,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { errMsg } from "@/lib/league";

export function useAct(leagueId: string) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const m = useLeagueAction({
    mutation: {
      onSuccess: (res) => {
        qc.invalidateQueries({ queryKey: getGetLeagueQueryKey(leagueId) });
        qc.invalidateQueries({ queryKey: getListLeaguesQueryKey() });
        toast({ title: res.message || "Done" });
      },
      onError: (e) => {
        toast({ title: "Action rejected", description: errMsg(e), variant: "destructive" });
      },
    },
  });
  const run = (data: LeagueCommand, onDone?: () => void) =>
    m.mutate({ leagueId, data }, { onSuccess: () => onDone?.() });
  return { run, pending: m.isPending, variables: m.variables?.data };
}
