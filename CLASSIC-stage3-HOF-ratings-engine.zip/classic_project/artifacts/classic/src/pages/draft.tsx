import { useState } from "react";
import { Pause, Play, Lock } from "lucide-react";
import { ActButton, LeagueShell, type LeagueCtx } from "@/components/league-shell";
import { Panel, PosChip, SectionTitle } from "@/components/brand";
import { pickMeta, ROUNDS, snakePick, teamInitials } from "@/lib/league";
import { cn } from "@/lib/utils";
import { PlayerProfile, type PlayerSeason } from "@/components/player-profile";
import { HallOfFameMark } from "@/components/hall-of-fame-mark";
import { getHallOfFameStatus } from "@/lib/hall-of-fame";

function DraftBody({ c }: { c: LeagueCtx }) {
  const { state, d, act } = c;
  const [profilePlayer, setProfilePlayer] = useState<PlayerSeason | null>(null);
  const T = Math.max(d.order.length, 1);
  const byPick = new Map(state.acquisitions.filter((a) => a.pickNumber != null).map((a) => [a.pickNumber!, a]));
  const L = state.league;
  const current = state.currentTeamId ? d.teamsById.get(state.currentTeamId) : null;
  const lockedList = [...d.lockedBy.entries()];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary/80">Snake draft · {ROUNDS} rounds</div>
          <h1 className="font-display text-3xl font-extrabold uppercase">Draft board</h1>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {L.status !== "completed" && (
            <div className="rounded-md border border-primary/40 bg-primary/10 px-3 py-1.5 text-sm">
              <span className="font-mono text-primary">{pickMeta(L.pickNumber, T).label}</span>{" "}
              <span className="font-semibold">{L.status === "pre_draft" ? "Waiting to start" : current?.name ?? "--"}</span>
            </div>
          )}
          {state.isCommissioner && L.status === "pre_draft" && (
            <ActButton ctx={c} data-testid="button-start" disabled={act.pending} onRun={() => act.run({ action: "start" })}><Play className="h-4 w-4" /> Start</ActButton>
          )}
          {state.isCommissioner && L.status === "live" && (
            <ActButton ctx={c} variant="secondary" data-testid="button-pause" disabled={act.pending} onRun={() => act.run({ action: "pause" })}><Pause className="h-4 w-4" /> Pause</ActButton>
          )}
          {state.isCommissioner && L.status === "paused" && (
            <ActButton ctx={c} data-testid="button-resume" disabled={act.pending} onRun={() => act.run({ action: "resume" })}><Play className="h-4 w-4" /> Resume</ActButton>
          )}
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-card-border bg-card/70">
        <table className="w-full min-w-[720px] border-collapse text-left">
          <thead>
            <tr className="border-b border-border">
              <th className="sticky left-0 z-10 w-12 bg-card px-2 py-2 font-mono text-[10px] text-muted-foreground">RD</th>
              {d.order.map((t) => (
                <th key={t.id} className={cn("px-2 py-2", t.id === state.currentTeamId && L.status === "live" && "bg-primary/10")}>
                  <div className="flex items-center gap-2">
                    <span className="grid h-6 w-6 place-items-center rounded bg-secondary font-display text-xs font-bold">{teamInitials(t.name)}</span>
                    <span className="truncate text-xs font-semibold">{t.name}</span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: ROUNDS }, (_, r) => r + 1).map((round) => (
              <tr key={round} className="border-b border-border/50">
                <td className="sticky left-0 z-10 bg-card px-2 font-mono text-[11px] text-muted-foreground">
                  {round}
                  <span className="ml-1 text-primary/60">{round % 2 ? "→" : "←"}</span>
                </td>
                {d.order.map((t, col) => {
                  const pick = snakePick(round, col, T);
                  const a = byPick.get(pick);
                  const p = a ? d.playersById.get(a.playerId) : null;
                  const isNow = pick === L.pickNumber && (L.status === "live" || L.status === "paused");
                  return (
                    <td key={t.id} className="p-1 align-top" data-testid={`cell-pick-${pick}`}>
                      <div
                        className={cn(
                          "h-[58px] rounded-md border px-2 py-1.5 transition-colors",
                          p ? "border-border/70 bg-background/50" : "border-dashed border-border/50",
                          isNow && "border-primary bg-primary/10 ring-1 ring-primary/60",
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-[9px] text-muted-foreground">{pickMeta(pick, T).label}</span>
                          {p && <PosChip pos={p.position} className="h-4 min-w-7 text-[9px]" />}
                        </div>
                        {p ? (
                          <>
                            <div className="flex min-w-0 items-center gap-1"><button type="button" onClick={() => setProfilePlayer(p)} className="block max-w-full truncate text-left text-[12px] font-semibold leading-tight hover:text-primary hover:underline" aria-label={`View ${p.name} ${p.season} player profile`}>{p.name}</button><HallOfFameMark status={p.hallOfFame ?? getHallOfFameStatus(p.name)} compact /></div>
                            <div className="truncate font-mono text-[9px] text-muted-foreground">{p.season} {p.nflTeam}{a && !a.active ? " · dropped" : ""}</div>
                          </>
                        ) : isNow ? (
                          <div className="mt-1 text-[11px] font-bold uppercase text-primary">On the clock</div>
                        ) : null}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Panel>
        <SectionTitle kicker="Permanent reservations" title={`Locked identities (${lockedList.length})`} />
        {lockedList.length === 0 ? (
          <p className="text-sm text-muted-foreground">No identities locked yet.</p>
        ) : (
          <div className="flex flex-wrap gap-1.5">
            {lockedList.map(([cid, l]) => {
              const p = d.playersById.get(l.playerId);
              return (
                <span key={cid} className={cn("inline-flex items-center gap-1.5 rounded-md border border-border/70 px-2 py-1 text-[12px]", !l.active && "opacity-60")}>
                  <Lock className="h-3 w-3 text-primary" />
                  {p?.name ?? cid}
                  <span className="font-mono text-[10px] text-muted-foreground">{d.teamsById.get(l.teamId)?.name}{!l.active && " · released"}</span>
                </span>
              );
            })}
          </div>
        )}
      </Panel>
      <PlayerProfile player={profilePlayer} players={state.players} open={!!profilePlayer} onOpenChange={(open) => !open && setProfilePlayer(null)} />
    </div>
  );
}

export default function DraftPage({ params }: { params: { id: string } }) {
  return <LeagueShell id={params.id} tab="draft">{(c) => <DraftBody c={c} />}</LeagueShell>;
}
