import { useState } from "react";
import { PlayerProfile, type PlayerSeason } from "@/components/player-profile";
import { HallOfFameMark } from "@/components/hall-of-fame-mark";
import { getHallOfFameStatus } from "@/lib/hall-of-fame";
import { ArrowLeftRight, Check, Gavel, X } from "lucide-react";
import { ActButton, LeagueShell, type LeagueCtx } from "@/components/league-shell";
import { Panel, PosChip, SectionTitle } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Empty } from "@/pages/dashboard";
import { SLOT_LIMITS, teamInitials } from "@/lib/league";
import type { LeagueCommandSlot } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

function RostersBody({ c }: { c: LeagueCtx }) {
  const { state, d, act } = c;
  const [teamId, setTeamId] = useState(state.viewerTeamId ?? d.order[0]?.id ?? "");
  const [drop, setDrop] = useState<string | null>(null);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [offered, setOffered] = useState("");
  const [requested, setRequested] = useState("");
  const [profilePlayer, setProfilePlayer] = useState<PlayerSeason | null>(null);
  const team = d.teamsById.get(teamId);
  const mine = !!state.viewerTeamId && teamId === state.viewerTeamId;
  const roster = state.acquisitions.filter((a) => a.teamId === teamId && a.active);
  const myRoster = state.acquisitions.filter((a) => a.teamId === state.viewerTeamId && a.active);
  const released = state.acquisitions.filter((a) => a.teamId === teamId && !a.active);
  const trades = state.trades;
  const claims = state.claims;
  const dropPlayer = drop ? d.playersById.get(drop) : null;
  const pname = (id: string) => d.playersById.get(id)?.name ?? "Unknown";

  return (
    <div className="grid gap-4 lg:grid-cols-12">
      <div className="lg:col-span-8 space-y-4">
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
          {d.order.map((t) => (
            <button
              key={t.id}
              data-testid={`button-team-${t.id}`}
              onClick={() => setTeamId(t.id)}
              className={cn("flex shrink-0 items-center gap-2 rounded-lg border px-2.5 py-1.5 text-[13px] font-semibold transition-colors", t.id === teamId ? "border-primary bg-primary/10" : "border-border bg-card/60 text-muted-foreground hover:text-foreground")}
            >
              <span className="grid h-6 w-6 place-items-center rounded bg-secondary font-display text-xs">{teamInitials(t.name)}</span>
              {t.name}
              {t.id === state.viewerTeamId && <span className="font-mono text-[9px] text-primary">YOU</span>}
            </button>
          ))}
        </div>

        <Panel>
          <SectionTitle
            kicker={`${roster.length}/15 active`}
            title={team?.name ?? "No teams"}
            right={
              !mine && state.viewerTeamId && team ? (
                <ActButton ctx={c} size="sm" variant="secondary" data-testid="button-propose-trade" onRun={() => setTradeOpen(true)}>
                  <ArrowLeftRight className="h-4 w-4" /> Propose trade
                </ActButton>
              ) : null
            }
          />
          <div className="space-y-3">
            {SLOT_LIMITS.map(({ slot, max }) => {
              const inSlot = roster.filter((a) => a.slot === slot);
              return (
                <div key={slot}>
                  <div className="mb-1 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    <span className="text-primary">{slot}</span> {inSlot.length}/{max}
                    <span className="h-px flex-1 bg-border/60" />
                  </div>
                  <div className="grid gap-1.5 sm:grid-cols-2">
                    {inSlot.map((a) => {
                      const p = d.playersById.get(a.playerId);
                      return (
                        <div key={a.playerId} data-testid={`row-roster-${a.playerId}`} className="flex items-center gap-2 rounded-md border border-border/70 bg-background/40 px-2 py-1.5">
                          {p && <PosChip pos={p.position} />}
                          <div className="min-w-0 flex-1">
                            <div className="flex min-w-0 items-center gap-2"><button type="button" disabled={!p} onClick={() => p && setProfilePlayer(p)} className="block max-w-full truncate text-left text-[13px] font-semibold hover:text-primary hover:underline disabled:cursor-default" aria-label={p ? `View ${p.name} ${p.season} player profile` : undefined}>{p?.name ?? a.canonicalId}</button>{p && <HallOfFameMark status={p.hallOfFame ?? getHallOfFameStatus(p.name)} compact />}</div>
                            <div className="font-mono text-[10px] text-muted-foreground">{p?.season} {p?.nflTeam}{a.pickNumber ? ` · pick ${a.pickNumber}` : " · free agency"}</div>
                          </div>
                          {mine && (
                            <>
                              <Select value={a.slot} onValueChange={(v) => c.requireAccess() && act.run({ action: "setSlot", playerId: a.playerId, slot: v as LeagueCommandSlot })}>
                                <SelectTrigger className="h-7 w-[84px] text-[11px]" data-testid={`select-slot-${a.playerId}`}><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {SLOT_LIMITS.map((s) => <SelectItem key={s.slot} value={s.slot}>{s.slot}</SelectItem>)}
                                </SelectContent>
                              </Select>
                              <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-destructive" data-testid={`button-drop-${a.playerId}`} onClick={() => c.requireAccess() && setDrop(a.playerId)}>
                                <X className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      );
                    })}
                    {Array.from({ length: Math.max(0, max - inSlot.length) }).map((_, i) => (
                      <div key={i} className="flex h-[42px] items-center rounded-md border border-dashed border-border/50 px-3 font-mono text-[10px] uppercase text-muted-foreground/60">Empty {slot}</div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          {released.length > 0 && (
            <div className="mt-4 border-t border-border/60 pt-3">
              <div className="mb-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Released, identity still locked to this team</div>
              <div className="flex flex-wrap gap-1.5">
                {released.map((a) => <span key={a.playerId + a.pickNumber} className="rounded border border-border/60 px-2 py-0.5 text-[12px] text-muted-foreground">{pname(a.playerId)}</span>)}
              </div>
            </div>
          )}
        </Panel>
      </div>

      <div className="space-y-4 lg:col-span-4">
        <Panel>
          <SectionTitle kicker="Receiving manager decides" title="Trades" />
          {trades.length === 0 ? (
            <Empty text="No trades proposed." icon={<ArrowLeftRight className="h-4 w-4" />} />
          ) : (
            <ul className="space-y-2">
              {trades.map((t) => {
                const canDecide = t.status === "pending" && t.toTeamId === state.viewerTeamId;
                return (
                  <li key={t.id} data-testid={`row-trade-${t.id}`} className="rounded-md border border-border/70 p-2.5 text-[13px]">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{d.teamsById.get(t.fromTeamId)?.name} to {d.teamsById.get(t.toTeamId)?.name}</span>
                      <span className={cn("font-mono text-[10px] uppercase", t.status === "pending" ? "text-primary" : "text-muted-foreground")}>{t.status}</span>
                    </div>
                    <div className="mt-1 text-muted-foreground">Gives <span className="text-foreground">{pname(t.offeredId)}</span>, wants <span className="text-foreground">{pname(t.requestedId)}</span></div>
                    {canDecide && (
                      <div className="mt-2 flex gap-2">
                        <ActButton ctx={c} size="sm" data-testid={`button-accept-${t.id}`} disabled={act.pending} onRun={() => act.run({ action: "acceptTrade", tradeId: t.id })}><Check className="h-4 w-4" />Accept</ActButton>
                        <ActButton ctx={c} size="sm" variant="secondary" data-testid={`button-reject-${t.id}`} disabled={act.pending} onRun={() => act.run({ action: "rejectTrade", tradeId: t.id })}>Reject</ActButton>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>
        <Panel>
          <SectionTitle
            kicker="Priority order"
            title="Waivers"
            right={state.isCommissioner ? (
              <ActButton ctx={c} size="sm" data-testid="button-process-waivers" disabled={act.pending} onRun={() => act.run({ action: "processWaivers" })}><Gavel className="h-4 w-4" />Process</ActButton>
            ) : null}
          />
          {claims.length === 0 ? (
            <Empty text="No waiver claims." />
          ) : (
            <ul className="space-y-1.5 text-[13px]">
              {claims.map((cl) => (
                <li key={cl.id} className="flex items-center gap-2 rounded-md border border-border/60 px-2.5 py-1.5">
                  <span className="min-w-0 flex-1 truncate">{d.teamsById.get(cl.teamId)?.name}: {pname(cl.playerId)}</span>
                  <span className="font-mono text-[10px] uppercase text-muted-foreground">{cl.status}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[11px] text-muted-foreground">Claims share a {state.league.waiverHours}h window per identity and are processed by the commissioner in waiver priority order. Dropped identities stay locked to their owner.</p>
        </Panel>
      </div>

      <AlertDialog open={!!drop} onOpenChange={(o) => !o && setDrop(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-2xl uppercase">Drop {dropPlayer?.name}?</AlertDialogTitle>
            <AlertDialogDescription>The player leaves your active roster, but this identity stays locked to your team permanently. No other manager can ever select any season of this player.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep</AlertDialogCancel>
            <AlertDialogAction data-testid="button-confirm-drop" className="bg-destructive text-destructive-foreground" onClick={() => drop && act.run({ action: "drop", playerId: drop })}>Drop player</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <PlayerProfile player={profilePlayer} players={state.players} open={!!profilePlayer} onOpenChange={(open) => !open && setProfilePlayer(null)} />

      <Dialog open={tradeOpen} onOpenChange={setTradeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display text-2xl uppercase">Trade with {team?.name}</DialogTitle>
            <DialogDescription>One for one. If accepted, both identity locks transfer together.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <div className="mb-1 font-mono text-[10px] uppercase text-muted-foreground">You give</div>
              <Select value={offered} onValueChange={setOffered}>
                <SelectTrigger data-testid="select-offered"><SelectValue placeholder="Choose your player" /></SelectTrigger>
                <SelectContent>{myRoster.map((a) => <SelectItem key={a.playerId} value={a.playerId}>{pname(a.playerId)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <div className="mb-1 font-mono text-[10px] uppercase text-muted-foreground">You get</div>
              <Select value={requested} onValueChange={setRequested}>
                <SelectTrigger data-testid="select-requested"><SelectValue placeholder="Choose their player" /></SelectTrigger>
                <SelectContent>{roster.map((a) => <SelectItem key={a.playerId} value={a.playerId}>{pname(a.playerId)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              data-testid="button-send-trade"
              disabled={!offered || !requested || act.pending}
              onClick={() => act.run({ action: "proposeTrade", teamId, offeredId: offered, requestedId: requested }, () => { setTradeOpen(false); setOffered(""); setRequested(""); })}
            >
              Send offer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function RostersPage({ params }: { params: { id: string } }) {
  return <LeagueShell id={params.id} tab="rosters">{(c) => <RostersBody c={c} />}</LeagueShell>;
}
