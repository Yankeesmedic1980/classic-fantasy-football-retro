import { Link } from "wouter";
import { ArrowRight, ArrowLeftRight, Clock, Hourglass, Lock, Radio } from "lucide-react";
import { ActButton, LeagueShell, type LeagueCtx } from "@/components/league-shell";
import { Panel, PosChip, SectionTitle } from "@/components/brand";
import { pickMeta, ROUNDS, teamInitials } from "@/lib/league";
import { cn } from "@/lib/utils";

function Stat({ label, value, sub, accent }: { label: string; value: React.ReactNode; sub?: string; accent?: boolean }) {
  return (
    <div className={cn("rounded-lg border border-border/70 bg-background/40 px-3 py-2.5", accent && "border-primary/40 bg-primary/[0.06]")}>
      <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className={cn("font-display text-3xl font-bold tabular leading-tight", accent && "text-primary")}>{value}</div>
      {sub && <div className="truncate text-[11px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

export function DashboardBody({ c }: { c: LeagueCtx }) {
  const { state, d, id, act } = c;
  const T = Math.max(state.teams.length, 1);
  const total = T * ROUNDS;
  const L = state.league;
  const current = state.currentTeamId ? d.teamsById.get(state.currentTeamId) : null;
  const next = state.nextTeamId ? d.teamsById.get(state.nextTeamId) : null;
  const pm = pickMeta(Math.min(L.pickNumber, total), T);
  const picksMade = state.acquisitions.filter((a) => a.pickNumber != null).length;
  const recentPicks = state.acquisitions
    .filter((a) => a.pickNumber != null)
    .sort((a, b) => (b.pickNumber ?? 0) - (a.pickNumber ?? 0))
    .slice(0, 6);
  const pendingTrades = state.trades.filter((t) => t.status === "pending");
  const pendingClaims = state.claims.filter((cl) => cl.status === "pending");
  const lockCount = d.lockedBy.size;
  const myTeam = state.viewerTeamId ? d.teamsById.get(state.viewerTeamId) : null;
  const onClock = L.status === "live" && state.currentTeamId === state.viewerTeamId && !!state.viewerTeamId;

  return (
    <div className="grid gap-4 lg:grid-cols-12">
      {/* Scoreboard */}
      <Panel className="relative overflow-hidden lg:col-span-8">
        <div className="yardlines pointer-events-none absolute inset-0 opacity-40" />
        <div className="relative">
          <div className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            <Radio className="h-3 w-3 text-primary" /> {L.mode === "production" ? "Production league" : "Sample-data league"} · {T}/{L.maxTeams} teams · {ROUNDS} rounds · snake
          </div>
          <div className="mt-3 grid gap-4 sm:grid-cols-[1.3fr_1fr]">
            <div>
              <div className="font-mono text-[11px] uppercase tracking-widest text-primary">
                {L.status === "completed" ? "Draft complete" : L.status === "pre_draft" ? "Draft not started" : "On the clock"}
              </div>
              <div className="mt-1 font-display text-5xl font-extrabold uppercase leading-none sm:text-6xl" data-testid="text-on-clock">
                {L.status === "completed" ? "Free agency" : current?.name ?? "Awaiting start"}
              </div>
              {L.status !== "completed" && (
                <div className="mt-2 text-sm text-muted-foreground">
                  Pick <span className="font-mono text-foreground">{pm.label}</span> · overall #{L.pickNumber}
                  {next && <> · up next <span className="font-semibold text-foreground">{next.name}</span></>}
                </div>
              )}
              <div className="mt-4 flex flex-wrap gap-2">
                {onClock && (
                  <Link href={`/league/${id}/players`} data-testid="link-make-pick" className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">
                    You are on the clock. Make your pick <ArrowRight className="h-4 w-4" />
                  </Link>
                )}
                <Link href={`/league/${id}/draft`} data-testid="link-draft-board" className="inline-flex items-center gap-2 rounded-md border border-border bg-secondary/60 px-4 py-2 text-sm font-semibold hover:bg-secondary">
                  Draft board <ArrowRight className="h-4 w-4" />
                </Link>
                {state.isCommissioner && L.status === "pre_draft" && (
                  <ActButton ctx={c} data-testid="button-start-draft" disabled={act.pending} onRun={() => act.run({ action: "start" })}>Start draft</ActButton>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 self-start">
              <Stat label="Picks made" value={picksMade} sub={`of ${total}`} accent />
              <Stat label="Locked IDs" value={lockCount} sub="permanent reservations" />
              <Stat label="Waiver window" value={`${L.waiverHours}h`} sub={L.waiverHours ? "claim processing window" : "free agency enabled"} />
              <Stat label="My team" value={myTeam ? teamInitials(myTeam.name) : "--"} sub={myTeam?.name ?? "Spectating"} />
            </div>
          </div>
          <div className="mt-5">
            <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
              <div className="h-full origin-left rounded-full bg-primary transition-transform duration-700" style={{ transform: `scaleX(${total ? picksMade / total : 0})` }} />
            </div>
            <div className="mt-1 flex justify-between font-mono text-[10px] text-muted-foreground">
              <span>R1</span>
              <span>Round {Math.min(pm.round, ROUNDS)} of {ROUNDS}</span>
              <span>R{ROUNDS}</span>
            </div>
          </div>
        </div>
      </Panel>

      {/* Activity */}
      <Panel className="lg:col-span-4 lg:row-span-2">
        <SectionTitle kicker="League wire" title="Activity" />
        {state.activity.length === 0 ? (
          <Empty text="Nothing has happened yet. The wire fills as managers draft, drop and trade." />
        ) : (
          <ol className="relative max-h-[560px] space-y-0 overflow-y-auto pr-1">
            {state.activity.map((a) => (
              <li key={a.id} className="relative border-l border-border/80 py-2 pl-4" data-testid={`row-activity-${a.id}`}>
                <span className="absolute -left-[4px] top-3.5 h-[7px] w-[7px] rounded-full bg-primary/70" />
                <div className="text-[13px] leading-snug">{a.message}</div>
                <div className="mt-0.5 font-mono text-[10px] text-muted-foreground">{new Date(a.createdAt).toLocaleString()}</div>
              </li>
            ))}
          </ol>
        )}
      </Panel>

      {/* Teams */}
      <Panel className="lg:col-span-5">
        <SectionTitle kicker="Draft order" title="Managers" right={<Link href={`/league/${id}/rosters`} className="text-xs font-semibold text-primary">Rosters</Link>} />
        <ul className="divide-y divide-border/60">
          {d.order.map((t) => {
            const n = state.acquisitions.filter((a) => a.teamId === t.id && a.active).length;
            const isCur = t.id === state.currentTeamId && L.status === "live";
            return (
              <li key={t.id} className="flex items-center gap-3 py-2" data-testid={`row-team-${t.id}`}>
                <span className="w-5 font-mono text-xs text-muted-foreground">{t.draftOrder}</span>
                <span className={cn("grid h-8 w-8 place-items-center rounded-md font-display text-sm font-bold", isCur ? "bg-primary text-primary-foreground" : "bg-secondary")}>
                  {teamInitials(t.name)}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">
                    {t.name} {t.id === state.viewerTeamId && <span className="ml-1 font-mono text-[10px] text-primary">YOU</span>}
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground">Waiver priority {t.waiverPriority}</span>
                </span>
                <span className="font-mono text-xs tabular text-muted-foreground">{n}/15</span>
              </li>
            );
          })}
        </ul>
      </Panel>

      {/* Recent picks */}
      <Panel className="lg:col-span-3">
        <SectionTitle kicker="Latest" title="Picks" />
        {recentPicks.length === 0 ? (
          <Empty text="No picks yet." />
        ) : (
          <ul className="space-y-2">
            {recentPicks.map((a) => {
              const p = d.playersById.get(a.playerId);
              return (
                <li key={`${a.canonicalId}-${a.pickNumber}`} className="flex items-center gap-2">
                  <span className="w-10 font-mono text-[11px] text-primary">{pickMeta(a.pickNumber!, T).label}</span>
                  {p && <PosChip pos={p.position} />}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-semibold">{p?.name ?? a.canonicalId}</span>
                    <span className="block truncate font-mono text-[10px] text-muted-foreground">
                      {p ? `${p.season} ${p.nflTeam}` : ""} · {d.teamsById.get(a.teamId)?.name}
                    </span>
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      {/* Queues */}
      <Panel className="lg:col-span-8">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <SectionTitle kicker="Pending" title="Trades" />
            {pendingTrades.length === 0 ? (
              <Empty text="No open offers." icon={<ArrowLeftRight className="h-4 w-4" />} />
            ) : (
              <ul className="space-y-2 text-[13px]">
                {pendingTrades.map((t) => (
                  <li key={t.id} className="rounded-md border border-border/70 px-3 py-2">
                    <span className="font-semibold">{d.teamsById.get(t.fromTeamId)?.name}</span> offers{" "}
                    {d.playersById.get(t.offeredId)?.name} for {d.playersById.get(t.requestedId)?.name}
                    <span className="block font-mono text-[10px] text-muted-foreground">to {d.teamsById.get(t.toTeamId)?.name}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div>
            <SectionTitle kicker="Pending" title="Waiver claims" />
            {pendingClaims.length === 0 ? (
              <Empty text="No claims in the queue." icon={<Hourglass className="h-4 w-4" />} />
            ) : (
              <ul className="space-y-2 text-[13px]">
                {pendingClaims.map((cl) => (
                  <li key={cl.id} className="flex items-center gap-2 rounded-md border border-border/70 px-3 py-2">
                    <Clock className="h-3.5 w-3.5 text-primary" />
                    <span className="min-w-0 flex-1 truncate">
                      {d.teamsById.get(cl.teamId)?.name}: {d.playersById.get(cl.playerId)?.name}
                    </span>
                    <span className="font-mono text-[10px] text-muted-foreground">{new Date(cl.eligibleAt).toLocaleString()}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <p className="mt-4 flex items-center gap-2 border-t border-border/60 pt-3 text-[12px] text-muted-foreground">
          <Lock className="h-3.5 w-3.5 text-primary" /> Drafting one season of a player locks that player's identity for this league, permanently. Drops keep the lock.
        </p>
      </Panel>
    </div>
  );
}

export function Empty({ text, icon }: { text: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-dashed border-border/80 px-3 py-5 text-[13px] text-muted-foreground">
      <span className="grid h-8 w-8 place-items-center rounded-md bg-secondary/70 text-primary">{icon ?? <Radio className="h-4 w-4" />}</span>
      {text}
    </div>
  );
}

export default function DashboardPage({ params }: { params: { id: string } }) {
  return <LeagueShell id={params.id} tab="">{(c) => <DashboardBody c={c} />}</LeagueShell>;
}
