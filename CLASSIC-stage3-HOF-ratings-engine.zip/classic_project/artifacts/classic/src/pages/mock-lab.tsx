import { useMemo, useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useUser } from "@clerk/react";
import { useQueryClient } from "@tanstack/react-query";
import {
  getListMockDraftsQueryKey,
  getListLeaguesQueryKey,
  useCreateMockDraft,
  useJoinMockDraft,
  useListLeagues,
  useListMockDrafts,
  type MockInput,
  type MockSeatInputKind,
} from "@workspace/api-client-react";
import { AlertTriangle, ArrowDown, ArrowUp, Bot, Cpu, FlaskConical, History, KeyRound, Shuffle, Timer, User, Users } from "lucide-react";
import { TopBar } from "@/components/league-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { errMsg } from "@/lib/league";
import { MOCK_STATUS, TEAM_COUNTS, useMockPageMeta } from "@/lib/mock";
import { cn } from "@/lib/utils";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

type Seat = { name: string; kind: MockSeatInputKind };

function defaultSeats(n: number, prev: Seat[] = []): Seat[] {
  return Array.from({ length: n }, (_, i) => prev[i] ?? { name: i === 0 ? "My War Room" : `CPU Club ${i + 1}`, kind: i === 0 ? "human" : "cpu" });
}

export default function MockLabPage() {
  useMockPageMeta("Mock Draft Lab");
  const { isLoaded, isSignedIn } = useUser();
  return (
    <div className="min-h-[100dvh]">
      <TopBar />
      <main className="mx-auto max-w-[1400px] px-4 pb-20 pt-6">
        {!isLoaded ? (
          <div className="grid gap-4 md:grid-cols-3"><Skeleton className="h-56 md:col-span-2" /><Skeleton className="h-56" /></div>
        ) : isSignedIn ? (
          <LabHome />
        ) : (
          <LabIntro />
        )}
      </main>
    </div>
  );
}

function Kicker({ children }: { children: React.ReactNode }) {
  return <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-primary">{children}</div>;
}

/* ---------------- Signed-out intro ---------------- */
function LabIntro() {
  const search = useSearch();
  const code = new URLSearchParams(search).get("code");
  const back = `${basePath}/mock-lab${search ? `?${search}` : ""}`;
  const r = `redirect_url=${encodeURIComponent(back)}`;
  const steps = [
    { n: "01", t: "Set the room", d: "4 to 12 seats. Mix friends and CPU managers, set the clock from 5 seconds to 10 minutes, or run it untimed." },
    { n: "02", t: "Send the code", d: "Friends join with a private invite code. Every human seat must be filled before the owner can start." },
    { n: "03", t: "Run the snake", d: "15 rounds. Build a private queue. If your clock expires, the server drafts from your queue first." },
    { n: "04", t: "Keep the tape", d: "Completed boards stay in your history. Restart opens a fresh room and leaves old results untouched." },
  ];
  return (
    <div className="rise">
      <section className="relative overflow-hidden rounded-2xl border border-primary/30 bg-[linear-gradient(115deg,hsl(221_50%_12%),hsl(222_47%_7%))]">
        <div className="yardlines pointer-events-none absolute inset-0 opacity-60" />
        <div className="relative grid gap-8 p-6 sm:p-10 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <Kicker>Mock Draft Lab · practice room</Kicker>
            <h1 className="mt-3 font-display text-5xl font-extrabold uppercase leading-[0.88] sm:text-7xl">
              Rehearse the<br />snake.<br /><span className="text-primary">Risk nothing.</span>
            </h1>
            <p className="mt-5 max-w-xl text-muted-foreground">
              Run full all-era snake drafts with friends or simple CPU managers in a private room that never touches your real leagues. Find out where the run on tight ends starts before it costs you.
            </p>
            {code && (
              <div data-testid="text-invite-pending" className="mt-5 inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-3 py-2 font-mono text-xs">
                <KeyRound className="h-3.5 w-3.5 text-primary" /> Invite code <span className="font-bold text-primary">{code}</span> will be ready after you sign in
              </div>
            )}
            <div className="mt-6 flex flex-wrap gap-2">
              <Link href={`/sign-up?${r}`} data-testid="link-lab-sign-up" className="rounded-md bg-primary px-5 py-2.5 font-bold text-primary-foreground transition-transform hover:-translate-y-0.5">Create an account</Link>
              <Link href={`/sign-in?${r}`} data-testid="link-lab-sign-in" className="rounded-md border border-border bg-secondary/60 px-5 py-2.5 font-semibold">Sign in to open the lab</Link>
            </div>
          </div>
          <BoardPreview />
        </div>
      </section>

      <section className="mt-10 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((s) => (
          <div key={s.n} className="bg-card p-5">
            <div className="font-display text-4xl font-extrabold text-primary/80">{s.n}</div>
            <h3 className="mt-1 font-display text-xl font-bold uppercase">{s.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
          </div>
        ))}
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <Kicker>Honest CPU managers</Kicker>
          <h2 className="mt-2 font-display text-3xl font-bold uppercase">Simple rules. No crystal ball.</h2>
          <p className="mt-3 text-sm text-muted-foreground">CPU seats follow deterministic rules you can read in one line. They are not predictive AI and they do not model your league-mates.</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-5">
            <Cpu className="h-5 w-5 text-primary" />
            <h3 className="mt-2 font-display text-lg font-bold uppercase">Needs</h3>
            <p className="mt-1 text-sm text-muted-foreground">Prioritizes unfilled starting positions by need, then uses snapshot order. No performance ranking.</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <Bot className="h-5 w-5 text-[hsl(196_75%_70%)]" />
            <h3 className="mt-2 font-display text-lg font-bold uppercase">Balanced</h3>
            <p className="mt-1 text-sm text-muted-foreground">Takes the first snapshot entry that fills a starter slot, then fills the bench. No performance ranking.</p>
          </div>
        </div>
      </section>

      <section className="stripe-gold mt-10 rounded-xl border border-primary/30 p-5">
        <div className="flex flex-wrap items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-primary" />
          <p className="flex-1 text-sm">
            <span className="font-bold">About the data.</span> The default pool is illustrative sample player-seasons, unverified and not official records. Members of a real league can instead snapshot that league's approved retired players. Mocks never change any league.
          </p>
        </div>
      </section>
    </div>
  );
}

function BoardPreview() {
  const cols = 6;
  const filled = 9;
  const pos = ["QB", "RB", "WR", "TE", "RB", "WR", "K", "WR", "RB"];
  return (
    <div aria-hidden className="relative hidden rounded-xl border border-border bg-[hsl(223_48%_6%/.7)] p-3 lg:block">
      <div className="mb-2 flex items-center justify-between font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        <span>Board · 6 teams</span><span className="text-primary">Snake</span>
      </div>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${cols},1fr)` }}>
        {Array.from({ length: cols * 4 }, (_, i) => {
          const round = Math.floor(i / cols);
          const col = i % cols;
          const pick = round % 2 === 0 ? round * cols + col : round * cols + (cols - 1 - col);
          const on = pick < filled;
          const cur = pick === filled;
          return (
            <div key={i} className={cn("h-11 rounded border text-[9px]", on ? "border-border bg-secondary/70" : cur ? "border-primary bg-primary/15 pulse-dot" : "border-dashed border-border/60")}>
              {on && <div className="p-1 font-mono text-primary/80">{pos[pick]}</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Signed-in home ---------------- */
function LabHome() {
  const list = useListMockDrafts({ query: { queryKey: getListMockDraftsQueryKey() } });
  return (
    <div className="rise">
      <div className="mb-6 flex flex-wrap items-end gap-4">
        <div className="flex-1">
          <Kicker>Mock Draft Lab</Kicker>
          <h1 className="mt-1 font-display text-4xl font-extrabold uppercase leading-none sm:text-5xl">Practice room</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">Private rehearsal drafts. Nothing here touches your real leagues.</p>
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-[1.35fr_1fr]">
        <CreateMock />
        <div className="space-y-6">
          <JoinMock />
          <section className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3 flex items-center gap-2">
              <History className="h-4 w-4 text-primary" />
              <h2 className="font-display text-xl font-bold uppercase">Your mocks</h2>
              {list.data && <span className="ml-auto font-mono text-[10px] text-muted-foreground">{list.data.length} total</span>}
            </div>
            {list.isLoading ? (
              <div className="space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-14" />)}</div>
            ) : list.isError ? (
              <div className="rounded-md border border-destructive/40 p-4 text-sm">
                <p className="text-destructive">{errMsg(list.error)}</p>
                <Button size="sm" className="mt-3" data-testid="button-retry-mocks" onClick={() => list.refetch()}>Retry</Button>
              </div>
            ) : !list.data?.length ? (
              <div className="rounded-lg border border-dashed border-border p-6 text-center">
                <FlaskConical className="mx-auto h-7 w-7 text-muted-foreground" />
                <p className="mt-2 font-display text-lg font-bold uppercase">No mocks yet</p>
                <p className="text-sm text-muted-foreground">Set up a room on the left or join with a friend's code.</p>
              </div>
            ) : (
              <ul className="divide-y divide-border">
                {[...list.data].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map((m) => {
                  const st = MOCK_STATUS[m.status];
                  const total = m.teamCount * 15;
                  return (
                    <li key={m.id}>
                      <Link href={`/mock-lab/${m.id}`} data-testid={`link-mock-${m.id}`} className="group flex items-center gap-3 py-3">
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-semibold group-hover:text-primary">{m.name}</div>
                          <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                            {m.teamCount} teams · {m.pickCount}/{total} picks · {new Date(m.createdAt).toLocaleDateString()}
                          </div>
                          <div className="mt-1 h-1 overflow-hidden rounded bg-muted"><div className="h-full origin-left bg-primary" style={{ transform: `scaleX(${Math.min(1, m.pickCount / total)})` }} /></div>
                        </div>
                        <span className={cn("rounded-full px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase", st?.tone)}>{st?.label ?? m.status}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function JoinMock() {
  const search = useSearch();
  const initial = new URLSearchParams(search).get("code") ?? "";
  const [code, setCode] = useState(initial);
  const [name, setName] = useState("");
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const join = useJoinMockDraft({
    mutation: {
      onSuccess: (r) => {
        qc.invalidateQueries({ queryKey: getListMockDraftsQueryKey() });
        toast({ title: r.message || "Joined" });
        setLocation(`/mock-lab/${r.id}`);
      },
      onError: (e) => toast({ title: "Could not join", description: errMsg(e), variant: "destructive" }),
    },
  });
  const nameOk = !name.trim() || (name.trim().length >= 2 && name.trim().length <= 50);
  return (
    <section className={cn("rounded-xl border bg-card p-5", initial ? "border-primary/50" : "border-border")}>
      <div className="mb-3 flex items-center gap-2"><KeyRound className="h-4 w-4 text-primary" /><h2 className="font-display text-xl font-bold uppercase">Join with a code</h2></div>
      {initial && <p className="mb-3 text-sm text-primary">You were invited. Confirm below to take the first open human seat.</p>}
      <form
        className="grid gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          join.mutate({ data: { code: code.trim(), ...(name.trim() ? { name: name.trim() } : {}) } });
        }}
      >
        <div className="grid gap-1.5"><Label htmlFor="mock-code">Invite code</Label><Input id="mock-code" data-testid="input-join-code" value={code} onChange={(e) => setCode(e.target.value)} className="font-mono uppercase" maxLength={100} /></div>
        <div className="grid gap-1.5"><Label htmlFor="mock-seat">Team name (optional)</Label><Input id="mock-seat" data-testid="input-join-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={50} placeholder="Keeps the seat's name if blank" /></div>
        {!nameOk && <p className="text-xs text-destructive">Team name must be 2 to 50 characters.</p>}
        <Button type="submit" data-testid="button-join-mock" disabled={!code.trim() || !nameOk || join.isPending}>{join.isPending ? "Joining..." : "Join mock"}</Button>
      </form>
    </section>
  );
}

function CreateMock() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [name, setName] = useState("Saturday Rehearsal");
  const [count, setCount] = useState(8);
  const [seats, setSeats] = useState<Seat[]>(() => defaultSeats(8));
  const [order, setOrder] = useState<number[]>(() => Array.from({ length: 8 }, (_, i) => i));
  const [ownerSeat, setOwnerSeat] = useState(0);
  const [randomOrder, setRandomOrder] = useState(false);
  const [timerOn, setTimerOn] = useState(true);
  const [timer, setTimer] = useState("60");
  const [strategy, setStrategy] = useState<"needs" | "balanced">("needs");
  const [pool, setPool] = useState<"illustrative" | "league">("illustrative");
  const [leagueId, setLeagueId] = useState("");
  const leagues = useListLeagues({ query: { queryKey: getListLeaguesQueryKey(), enabled: pool === "league" } });

  const create = useCreateMockDraft({
    mutation: {
      onSuccess: (r) => {
        qc.invalidateQueries({ queryKey: getListMockDraftsQueryKey() });
        toast({ title: r.message || "Mock created" });
        setLocation(`/mock-lab/${r.id}`);
      },
      onError: (e) => toast({ title: "Could not create mock", description: errMsg(e), variant: "destructive" }),
    },
  });

  const resize = (n: number) => {
    setCount(n);
    setSeats((s) => defaultSeats(n, s));
    setOrder(Array.from({ length: n }, (_, i) => i));
    if (ownerSeat >= n) setOwnerSeat(0);
  };
  const setSeat = (i: number, patch: Partial<Seat>) => setSeats((s) => s.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const move = (pos: number, dir: -1 | 1) =>
    setOrder((o) => {
      const t = pos + dir;
      if (t < 0 || t >= o.length) return o;
      const c = [...o];
      [c[pos], c[t]] = [c[t], c[pos]];
      return c;
    });

  const errors = useMemo(() => {
    const e: string[] = [];
    const nm = name.trim();
    if (nm.length < 2 || nm.length > 80) e.push("Mock name must be 2 to 80 characters.");
    seats.forEach((s, i) => {
      const l = s.name.trim().length;
      if (l < 2 || l > 50) e.push(`Seat ${i + 1} name must be 2 to 50 characters.`);
    });
    const names = seats.map((s) => s.name.trim().toLowerCase());
    if (new Set(names).size !== names.length) e.push("Seat names must be unique.");
    if (seats[ownerSeat]?.kind !== "human") e.push("Your seat must be a human seat.");
    const t = Number(timer);
    if (timerOn && (!Number.isInteger(t) || t < 5 || t > 600)) e.push("Pick clock must be a whole number from 5 to 600 seconds.");
    if (pool === "league" && !leagueId) e.push("Choose a source league or use the illustrative pool.");
    return e;
  }, [name, seats, ownerSeat, timer, timerOn, pool, leagueId]);

  const submit = () => {
    const draftOrderOf = new Map(order.map((seatIdx, pos) => [seatIdx, pos + 1]));
    const input: MockInput = {
      name: name.trim(),
      teams: seats.map((s, i) => ({ name: s.name.trim(), kind: s.kind, draftOrder: draftOrderOf.get(i) ?? i + 1 })),
      ownerSeat,
      randomOrder,
      timerSeconds: timerOn ? Number(timer) : 0,
      cpuStrategy: strategy,
      poolSource: pool,
      ...(pool === "league" ? { sourceLeagueId: leagueId } : {}),
    };
    create.mutate({ data: input });
  };

  const humans = seats.filter((s) => s.kind === "human").length;
  const chip = (on: boolean) => cn("rounded-md border px-3 py-1.5 text-sm font-semibold transition-colors", on ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground hover:text-foreground");

  return (
    <section className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-5">
        <Kicker>New room</Kicker>
        <h2 className="font-display text-2xl font-bold uppercase">Set up a mock</h2>
      </div>
      <div className="grid gap-6 p-5">
        <div className="grid gap-1.5"><Label htmlFor="mock-name">Mock name</Label><Input id="mock-name" data-testid="input-mock-name" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} /></div>

        <div>
          <Label>Teams</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {TEAM_COUNTS.map((n) => (
              <button key={n} type="button" data-testid={`button-teams-${n}`} className={chip(count === n)} onClick={() => resize(n)}>{n}</button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex flex-wrap items-center gap-3">
            <Label>Seats</Label>
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{humans} human · {count - humans} CPU</span>
          </div>
          <div className="mt-2 grid gap-2">
            {seats.map((s, i) => (
              <div key={i} className={cn("flex flex-wrap items-center gap-2 rounded-lg border p-2", ownerSeat === i ? "border-primary/50 bg-primary/5" : "border-border")}>
                <span className="w-6 text-center font-mono text-xs text-muted-foreground">{i + 1}</span>
                <Input data-testid={`input-seat-name-${i}`} value={s.name} maxLength={50} onChange={(e) => setSeat(i, { name: e.target.value })} className="h-8 min-w-0 flex-1" />
                <div className="flex overflow-hidden rounded-md border border-border">
                  {(["human", "cpu"] as const).map((k) => (
                    <button key={k} type="button" data-testid={`button-seat-${k}-${i}`} onClick={() => setSeat(i, { kind: k })}
                      className={cn("flex items-center gap-1 px-2 py-1 text-xs font-semibold", s.kind === k ? "bg-secondary text-foreground" : "text-muted-foreground")}>
                      {k === "human" ? <User className="h-3 w-3" /> : <Cpu className="h-3 w-3" />}{k === "human" ? "Human" : "CPU"}
                    </button>
                  ))}
                </div>
                <button type="button" data-testid={`button-owner-seat-${i}`} disabled={s.kind !== "human"} onClick={() => setOwnerSeat(i)}
                  className={cn("rounded-md px-2 py-1 font-mono text-[10px] uppercase tracking-wider disabled:opacity-30", ownerSeat === i ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground")}>
                  {ownerSeat === i ? "Your seat" : "Take"}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-3">
            <Label>Draft order</Label>
            <label className="ml-auto flex items-center gap-2 text-sm"><Shuffle className="h-3.5 w-3.5 text-primary" />Randomize at creation<Switch data-testid="switch-random-order" checked={randomOrder} onCheckedChange={setRandomOrder} /></label>
          </div>
          {randomOrder ? (
            <p className="mt-2 rounded-md border border-dashed border-border p-3 text-sm text-muted-foreground">The server will shuffle all {count} seats when the room is created.</p>
          ) : (
            <ol className="mt-2 grid gap-1 sm:grid-cols-2">
              {order.map((seatIdx, pos) => (
                <li key={seatIdx} className="flex items-center gap-2 rounded-md bg-secondary/50 px-2 py-1 text-sm">
                  <span className="w-6 font-mono text-xs text-primary">{pos + 1}</span>
                  <span className="min-w-0 flex-1 truncate">{seats[seatIdx]?.name}</span>
                  <Button type="button" size="icon" variant="ghost" className="h-6 w-6" disabled={pos === 0} data-testid={`button-order-up-${pos}`} onClick={() => move(pos, -1)}><ArrowUp className="h-3 w-3" /></Button>
                  <Button type="button" size="icon" variant="ghost" className="h-6 w-6" disabled={pos === order.length - 1} data-testid={`button-order-down-${pos}`} onClick={() => move(pos, 1)}><ArrowDown className="h-3 w-3" /></Button>
                </li>
              ))}
            </ol>
          )}
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <div className="flex items-center gap-2"><Label>Pick clock</Label><Switch data-testid="switch-timer" checked={timerOn} onCheckedChange={setTimerOn} className="ml-auto" /></div>
            <div className="mt-2 flex items-center gap-2">
              <Timer className="h-4 w-4 text-muted-foreground" />
              <Input type="number" min={5} max={600} data-testid="input-timer" disabled={!timerOn} value={timerOn ? timer : ""} placeholder="Untimed" onChange={(e) => setTimer(e.target.value)} className="h-8 w-28" />
              <span className="text-xs text-muted-foreground">seconds</span>
            </div>
          </div>
          <div>
            <Label>CPU strategy</Label>
            <div className="mt-2 flex gap-2">
              <button type="button" data-testid="button-strategy-needs" className={chip(strategy === "needs")} onClick={() => setStrategy("needs")}>Needs</button>
              <button type="button" data-testid="button-strategy-balanced" className={chip(strategy === "balanced")} onClick={() => setStrategy("balanced")}>Balanced</button>
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">{strategy === "needs" ? "Fills unfilled starters first. Deterministic." : "Follows snapshot order, still fills valid slots."}</p>
          </div>
        </div>

        <div>
          <Label>Player pool</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            <button type="button" data-testid="button-pool-illustrative" className={chip(pool === "illustrative")} onClick={() => setPool("illustrative")}>Illustrative sample</button>
            <button type="button" data-testid="button-pool-league" className={chip(pool === "league")} onClick={() => setPool("league")}>From my league</button>
          </div>
          {pool === "illustrative" ? (
            <p className="stripe-gold mt-2 rounded-md border border-primary/30 p-3 text-xs">Illustrative sample player-seasons. Unverified, not official records.</p>
          ) : leagues.isLoading ? (
            <Skeleton className="mt-2 h-9" />
          ) : leagues.isError ? (
            <p className="mt-2 text-xs text-destructive">{errMsg(leagues.error)} <button type="button" className="underline" onClick={() => leagues.refetch()}>Retry</button></p>
          ) : !leagues.data?.length ? (
            <p className="mt-2 text-xs text-muted-foreground">You do not belong to any leagues yet.</p>
          ) : (
            <div className="mt-2 grid gap-1.5">
              <select data-testid="select-source-league" value={leagueId} onChange={(e) => setLeagueId(e.target.value)} className="h-9 rounded-md border border-input bg-background px-2 text-sm">
                <option value="">Choose a league</option>
                {leagues.data.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
              <p className="text-xs text-muted-foreground">Snapshots only approved, retired, non-sample players. The league itself is never changed. Needs {count * 15} unique identities.</p>
            </div>
          )}
        </div>

        {errors.length > 0 && (
          <ul className="space-y-1 rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive" data-testid="list-create-errors">
            {errors.map((e) => <li key={e}>{e}</li>)}
          </ul>
        )}
        <div className="flex items-center gap-3">
          <Users className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">{count} teams · 15 rounds · {count * 15} picks</span>
          <Button className="ml-auto" data-testid="button-create-mock" disabled={errors.length > 0 || create.isPending} onClick={submit}>
            {create.isPending ? "Creating..." : "Create mock"}
          </Button>
        </div>
      </div>
    </section>
  );
}
