import { useEffect, useRef, useState } from "react";
import { Copy, Download, FileUp, Pause, Play, Plus, ShieldAlert } from "lucide-react";
import { getExportLeagueQueryKey, useExportLeague, type PlayerInput } from "@workspace/api-client-react";
import { ActButton, LeagueShell, type LeagueCtx } from "@/components/league-shell";
import { Panel, SectionTitle } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { CSV_HEADER, errMsg, parsePlayersCsv, POSITIONS } from "@/lib/league";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function TeamRow({ c, teamId }: { c: LeagueCtx; teamId: string }) {
  const t = c.d.teamsById.get(teamId)!;
  const [name, setName] = useState(t.name);
  const previousName = useRef(t.name);
  useEffect(() => {
    const oldName = previousName.current;
    setName(current => current === oldName ? t.name : current);
    previousName.current = t.name;
  }, [t.name]);
  return (
    <li className="flex flex-wrap items-center gap-2 py-2">
      <Select value={String(t.draftOrder)} onValueChange={(v) => c.requireAccess() && c.act.run({ action: "updateTeam", teamId, draftOrder: Number(v) })} disabled={c.state.league.status !== "pre_draft"}>
        <SelectTrigger className="w-16" data-testid={`select-order-${teamId}`}><SelectValue /></SelectTrigger>
        <SelectContent>{c.d.order.map((_, i) => <SelectItem key={i} value={String(i + 1)}>{i + 1}</SelectItem>)}</SelectContent>
      </Select>
      <Input className="min-w-[140px] flex-1" value={name} onChange={(e) => setName(e.target.value)} data-testid={`input-team-name-${teamId}`} />
      <ActButton ctx={c} size="sm" variant="secondary" disabled={name.trim().length < 2 || name === t.name} data-testid={`button-rename-${teamId}`} onRun={() => c.act.run({ action: "updateTeam", teamId, name: name.trim() })}>Rename</ActButton>
    </li>
  );
}

const blank: PlayerInput = { canonicalId: "", name: "", position: "QB", nflTeam: "", season: 1985, retired: false, approved: false };

function SettingsBody({ c }: { c: LeagueCtx }) {
  const { state, act, id } = c;
  const { toast } = useToast();
  const L = state.league;
  const [hours, setHours] = useState(String(L.waiverHours));
  const previousHours = useRef(L.waiverHours);
  useEffect(() => {
    const oldHours = String(previousHours.current);
    setHours(current => current === oldHours ? String(L.waiverHours) : current);
    previousHours.current = L.waiverHours;
  }, [L.waiverHours]);
  const [player, setPlayer] = useState<PlayerInput>(blank);
  const [csv, setCsv] = useState<{ players: PlayerInput[]; errors: string[]; file: string } | null>(null);
  const exp = useExportLeague(id, { query: { enabled: false, queryKey: getExportLeagueQueryKey(id) } });
  const invite = `${window.location.origin}${basePath}/leagues?code=${L.inviteCode}`;
  const canManage = state.isCommissioner;

  const doExport = async () => {
    const r = await exp.refetch();
    if (r.error || !r.data) {
      toast({ title: "Export failed", description: errMsg(r.error), variant: "destructive" });
      return;
    }
    const blob = new Blob([JSON.stringify(r.data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `classic-${L.name.replace(/\W+/g, "-").toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    const text = await f.text();
    setCsv({ ...parsePlayersCsv(text), file: f.name });
  };

  const validPlayer = player.canonicalId.trim() && player.name.trim() && player.nflTeam.trim() && player.season >= 1920 && player.season <= 2026;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {!canManage && (
        <div className="flex items-center gap-3 rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm lg:col-span-2">
          <ShieldAlert className="h-5 w-5 text-primary" /> Only the commissioner can change settings or export league data.
        </div>
      )}
      <Panel>
        <SectionTitle kicker="Bring your managers" title="Invite" />
        <div className="flex gap-2">
          <Input readOnly value={invite} data-testid="input-invite" className="font-mono text-xs" />
          <Button variant="secondary" data-testid="button-copy-invite" disabled={c.isSample} onClick={async () => {
            try { await navigator.clipboard.writeText(invite); toast({ title: "Invite link copied" }); }
            catch { toast({ title: "Could not copy", description: "Select and copy the invitation link above.", variant: "destructive" }); }
          }}><Copy className="h-4 w-4" /></Button>
        </div>
        <div className="mt-2 font-mono text-[11px] text-muted-foreground">Code <span className="text-primary">{L.inviteCode}</span> · {state.teams.length}/{L.maxTeams} seats filled</div>
      </Panel>

      <Panel>
        <SectionTitle kicker="Draft control" title="League status" />
        <div className="flex flex-wrap gap-2">
          {L.status === "pre_draft" && <ActButton ctx={c} disabled={!canManage || act.pending} data-testid="button-start" onRun={() => act.run({ action: "start" })}><Play className="h-4 w-4" />Start draft</ActButton>}
          {L.status === "live" && <ActButton ctx={c} variant="secondary" disabled={!canManage || act.pending} data-testid="button-pause" onRun={() => act.run({ action: "pause" })}><Pause className="h-4 w-4" />Pause</ActButton>}
          {L.status === "paused" && <ActButton ctx={c} disabled={!canManage || act.pending} data-testid="button-resume" onRun={() => act.run({ action: "resume" })}><Play className="h-4 w-4" />Resume</ActButton>}
          {L.status === "completed" && <span className="text-sm text-muted-foreground">Draft complete. Free agency and waivers are open.</span>}
        </div>
        <div className="mt-4 flex items-end gap-2">
          <div className="flex-1">
            <Label className="text-[12px]">Waiver period (hours, 0-168)</Label>
            <Input type="number" min={0} max={168} value={hours} onChange={(e) => setHours(e.target.value)} data-testid="input-waiver-hours" />
          </div>
          <ActButton ctx={c} variant="secondary" disabled={!canManage || act.pending || Number(hours) === L.waiverHours} data-testid="button-save-waivers" onRun={() => act.run({ action: "updateSettings", waiverHours: Number(hours) })}>Save</ActButton>
        </div>
      </Panel>

      <Panel>
        <SectionTitle kicker={L.status === "pre_draft" ? "Choosing a slot swaps two teams" : "Order locked after start"} title="Teams & draft order" />
        <ul className="divide-y divide-border/60">
          {c.d.order.map((t) => canManage ? <TeamRow key={t.id} c={c} teamId={t.id} /> : (
            <li key={t.id} className="flex gap-3 py-2 text-sm"><span className="w-5 font-mono text-muted-foreground">{t.draftOrder}</span>{t.name}</li>
          ))}
        </ul>
      </Panel>

      <Panel>
        <SectionTitle kicker="Commissioner attestation" title="Add player season" />
        <div className="grid grid-cols-2 gap-2">
          <Input placeholder="canonicalId (e.g. walter-payton)" value={player.canonicalId} onChange={(e) => setPlayer({ ...player, canonicalId: e.target.value })} className="col-span-2" data-testid="input-canonical" />
          <Input placeholder="Name" value={player.name} onChange={(e) => setPlayer({ ...player, name: e.target.value })} className="col-span-2" data-testid="input-player-name" />
          <Select value={player.position} onValueChange={(v) => setPlayer({ ...player, position: v as PlayerInput["position"] })}>
            <SelectTrigger data-testid="select-position"><SelectValue /></SelectTrigger>
            <SelectContent>{POSITIONS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
          <Input placeholder="NFL team" value={player.nflTeam} onChange={(e) => setPlayer({ ...player, nflTeam: e.target.value })} data-testid="input-nfl-team" />
          <Input type="number" placeholder="Season" value={player.season} onChange={(e) => setPlayer({ ...player, season: Number(e.target.value) })} data-testid="input-season" />
          <div className="flex items-center justify-around gap-2 text-[12px]">
            <label className="flex items-center gap-1.5"><Switch checked={player.retired} onCheckedChange={(v) => setPlayer({ ...player, retired: v })} />Retired</label>
            <label className="flex items-center gap-1.5"><Switch checked={player.approved} onCheckedChange={(v) => setPlayer({ ...player, approved: v })} />Approved</label>
          </div>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">You attest this season is accurate. CLASSIC does not externally verify records. Production leagues only use retired, approved seasons.</p>
        <ActButton ctx={c} className="mt-3" disabled={!canManage || !validPlayer || act.pending} data-testid="button-add-player" onRun={() => act.run({ action: "addPlayer", player: { ...player, canonicalId: player.canonicalId.trim(), name: player.name.trim(), nflTeam: player.nflTeam.trim() } }, () => setPlayer(blank))}>
          <Plus className="h-4 w-4" />Add season
        </ActButton>
      </Panel>

      <Panel className="lg:col-span-2">
        <SectionTitle kicker={`Header: ${CSV_HEADER.join(",")}`} title="CSV import & export" right={
          <Button variant="secondary" size="sm" data-testid="button-export" disabled={!canManage || exp.isFetching} onClick={doExport}><Download className="h-4 w-4" />{exp.isFetching ? "Exporting" : "Export JSON"}</Button>
        } />
        <label className={`flex cursor-pointer items-center gap-3 rounded-lg border border-dashed border-border px-4 py-5 text-sm hover:border-primary/60 ${!canManage ? "pointer-events-none opacity-50" : ""}`}>
          <FileUp className="h-5 w-5 text-primary" />
          <span>{csv ? csv.file : "Choose a .csv file of player seasons (max 1000 rows)"}</span>
          <input type="file" accept=".csv,text/csv" className="hidden" data-testid="input-csv" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
        {csv && (
          <div className="mt-3 space-y-2">
            <div className="font-mono text-[12px]"><span className="text-[hsl(152_55%_66%)]">{csv.players.length} valid</span> · <span className={csv.errors.length ? "text-destructive" : "text-muted-foreground"}>{csv.errors.length} errors</span></div>
            {csv.errors.length > 0 && (
              <ul className="max-h-40 overflow-y-auto rounded-md border border-destructive/40 bg-destructive/5 p-2 font-mono text-[11px] text-destructive" data-testid="list-csv-errors">
                {csv.errors.map((e, i) => <li key={i}>{e}</li>)}
              </ul>
            )}
            <div className="flex gap-2">
              <ActButton ctx={c} disabled={!canManage || csv.errors.length > 0 || csv.players.length === 0 || act.pending} data-testid="button-import" onRun={() => act.run({ action: "importPlayers", players: csv.players }, () => setCsv(null))}>
                Import {csv.players.length} seasons
              </ActButton>
              <Button variant="ghost" onClick={() => setCsv(null)}>Clear</Button>
            </div>
            {csv.errors.length > 0 && <p className="text-[11px] text-muted-foreground">Fix every error before importing. Nothing is imported partially.</p>}
          </div>
        )}
      </Panel>
    </div>
  );
}

export default function SettingsPage({ params }: { params: { id: string } }) {
  return <LeagueShell id={params.id} tab="settings">{(c) => <SettingsBody c={c} />}</LeagueShell>;
}
