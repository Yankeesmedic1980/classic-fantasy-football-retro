import { useMemo, useState } from "react";
import { Lock, Search, ShieldCheck } from "lucide-react";
import { ActButton, LeagueShell, type LeagueCtx } from "@/components/league-shell";
import { PosChip } from "@/components/brand";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Empty } from "@/pages/dashboard";
import { POSITIONS } from "@/lib/league";
import { cn } from "@/lib/utils";
import { PlayerProfile, type PlayerSeason } from "@/components/player-profile";
import { HallOfFameMark } from "@/components/hall-of-fame-mark";
import { getHallOfFameStatus } from "@/lib/hall-of-fame";

function PlayersBody({ c }: { c: LeagueCtx }) {
  const { state, d, act } = c;
  const [q, setQ] = useState("");
  const [pos, setPos] = useState("ALL");
  const [hideLocked, setHideLocked] = useState(true);
  const [profilePlayer, setProfilePlayer] = useState<PlayerSeason | null>(null);
  const L = state.league;
  const myTurn = L.status === "live" && !!state.viewerTeamId && state.currentTeamId === state.viewerTeamId;

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return state.players
      .filter((p) => d.eligible(p))
      .filter((p) => pos === "ALL" || p.position === pos)
      .filter((p) => !term || `${p.name} ${p.nflTeam} ${p.season} ${p.canonicalId}`.toLowerCase().includes(term))
      .filter((p) => !hideLocked || !d.lockedBy.has(p.canonicalId))
      .sort((a, b) => a.name.localeCompare(b.name) || a.season - b.season);
  }, [state.players, q, pos, hideLocked, d]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary/80">
            {L.mode === "production" ? "Approved retired seasons only" : "Includes unverified sample data"}
          </div>
          <h1 className="font-display text-3xl font-extrabold uppercase">Player seasons</h1>
        </div>
        <div className="ml-auto text-[12px] text-muted-foreground">
          {L.status === "live" ? (myTurn ? <span className="font-bold text-primary">You are on the clock.</span> : "Drafting opens on your pick.") : L.status === "completed" ? "Free agents and waiver claims are open." : "Free agency opens after the draft."}
        </div>
      </div>

      <div className="sticky top-[104px] z-20 -mx-4 flex flex-wrap items-center gap-2 border-y border-border/60 bg-background/90 px-4 py-2 backdrop-blur">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input data-testid="input-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name, team, season..." className="pl-8" />
        </div>
        <div className="no-scrollbar flex gap-1 overflow-x-auto">
          {["ALL", ...POSITIONS].map((p) => (
            <button
              key={p}
              data-testid={`filter-pos-${p}`}
              onClick={() => setPos(p)}
              className={cn("rounded-md px-2.5 py-1.5 font-mono text-[11px] font-semibold transition-colors", pos === p ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground")}
            >
              {p}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Switch id="hide" checked={hideLocked} onCheckedChange={setHideLocked} data-testid="switch-hide-locked" />
          <Label htmlFor="hide" className="text-[12px]">Hide locked</Label>
        </div>
      </div>

      {rows.length === 0 ? (
        <Empty text={state.players.length === 0 ? "No player seasons in this league yet. The commissioner can add or import them in Settings." : "No player seasons match these filters."} icon={<Search className="h-4 w-4" />} />
      ) : (
        <div className="overflow-hidden rounded-xl border border-card-border bg-card/70">
          <div className="hidden grid-cols-[48px_1fr_80px_70px_120px_200px] gap-2 border-b border-border px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground md:grid">
            <span>Pos</span><span>Player</span><span>Season</span><span>Team</span><span>Status</span><span className="text-right">Action</span>
          </div>
          <ul className="divide-y divide-border/50">
            {rows.slice(0, 300).map((p) => {
              const lock = d.lockedBy.get(p.canonicalId);
              const pending = act.pending && act.variables?.playerId === p.id;
              return (
                <li key={p.id} data-testid={`row-player-${p.id}`} className="grid grid-cols-[48px_1fr_auto] items-center gap-2 px-3 py-2 md:grid-cols-[48px_1fr_80px_70px_120px_200px]">
                  <PosChip pos={p.position} />
                  <div className="min-w-0">
                    <div className="flex min-w-0 items-center gap-2"><button type="button" onClick={() => setProfilePlayer(p)} className="truncate text-left text-sm font-semibold hover:text-primary hover:underline" aria-label={`View ${p.name} ${p.season} player profile`}>{p.name}</button><HallOfFameMark status={p.hallOfFame ?? getHallOfFameStatus(p.name)} compact /></div>
                    <div className="truncate font-mono text-[10px] text-muted-foreground md:hidden">{p.season} · {p.nflTeam}</div>
                    <div className="flex gap-1.5 font-mono text-[9px] uppercase">
                      {p.sample && <span className="text-[hsl(28_90%_70%)]">Sample · unverified</span>}
                      {!p.sample && p.approved && <span className="inline-flex items-center gap-0.5 text-[hsl(152_55%_66%)]"><ShieldCheck className="h-2.5 w-2.5" />Commissioner-approved</span>}
                      {!p.sample && !p.retired && <span className="text-muted-foreground">Active career</span>}
                    </div>
                  </div>
                  <span className="hidden font-mono text-sm tabular md:block">{p.season}</span>
                  <span className="hidden font-mono text-sm md:block">{p.nflTeam}</span>
                  <span className="hidden md:block">
                    {lock ? (
                      <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground"><Lock className="h-3 w-3 text-primary" />{d.teamsById.get(lock.teamId)?.name}</span>
                    ) : (
                      <span className="text-[11px] text-[hsl(152_55%_66%)]">Available</span>
                    )}
                  </span>
                  <div className="flex justify-end gap-1.5">
                    {lock && (lock.active || lock.teamId !== state.viewerTeamId || lock.playerId !== p.id || L.status !== "completed") ? (
                      <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase text-muted-foreground md:hidden"><Lock className="h-3 w-3" />Locked</span>
                    ) : L.status === "completed" ? (
                      <>
                        {L.waiverHours > 0 ? (
                          <ActButton ctx={c} size="sm" data-testid={`button-claim-${p.id}`} disabled={pending} onRun={() => act.run({ action: "claim", playerId: p.id })}>Claim</ActButton>
                        ) : (
                          <ActButton ctx={c} size="sm" data-testid={`button-acquire-${p.id}`} disabled={pending} onRun={() => act.run({ action: "acquire", playerId: p.id })}>{lock ? "Reacquire" : "Add"}</ActButton>
                        )}
                      </>
                    ) : (
                      <ActButton ctx={c} size="sm" data-testid={`button-draft-${p.id}`} disabled={pending || (!c.readOnly && !myTurn)} onRun={() => act.run({ action: "draft", playerId: p.id })}>Draft</ActButton>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
          {rows.length > 300 && <div className="border-t border-border px-3 py-2 text-center text-[12px] text-muted-foreground">Showing 300 of {rows.length}. Refine your search.</div>}
        </div>
      )}
      <PlayerProfile player={profilePlayer} players={state.players} open={!!profilePlayer} onOpenChange={(open) => !open && setProfilePlayer(null)} />
    </div>
  );
}

export default function PlayersPage({ params }: { params: { id: string } }) {
  return <LeagueShell id={params.id} tab="players">{(c) => <PlayersBody c={c} />}</LeagueShell>;
}
