import { useEffect, useMemo, useState } from "react";
import { Link, Redirect, useParams } from "wouter";
import { useUser } from "@clerk/react";
import {
  getExportMockDraftQueryKey,
  getGetMockDraftQueryKey,
  useExportMockDraft,
  useGetMockDraft,
  type MockState,
} from "@workspace/api-client-react";
import { AlertTriangle, ArrowDown, ArrowUp, Copy, Cpu, Download, FlaskConical, ListPlus, Pause, Play, RefreshCw, RotateCcw, Search, Timer, User, X } from "lucide-react";
import { TopBar } from "@/components/league-shell";
import { PosChip } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { errMsg, POSITIONS, SLOT_LIMITS } from "@/lib/league";
import { MOCK_STATUS, mockDerive, pickLabel, useMockAct, useMockPageMeta } from "@/lib/mock";
import { cn } from "@/lib/utils";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function MockRoomPage() {
  const params = useParams<{ id: string }>();
  const id = params.id ?? "";
  const { isLoaded, isSignedIn } = useUser();
  if (isLoaded && !isSignedIn) {
    return <Redirect to={`/sign-in?redirect_url=${encodeURIComponent(`${basePath}/mock-lab/${id}`)}`} />;
  }
  return (
    <div className="min-h-[100dvh]">
      <TopBar />
      {isLoaded ? <Room id={id} /> : <RoomSkeleton />}
    </div>
  );
}

function RoomSkeleton() {
  return (
    <main className="mx-auto grid max-w-[1400px] gap-4 px-4 pt-6 lg:grid-cols-[1fr_340px]">
      <Skeleton className="h-28 lg:col-span-2" /><Skeleton className="h-[480px]" /><Skeleton className="h-[480px]" />
    </main>
  );
}

function Room({ id }: { id: string }) {
  const q = useGetMockDraft(id, { query: { queryKey: getGetMockDraftQueryKey(id), refetchInterval: 3000 } });
  const s = q.data;
  if (q.isLoading) return <RoomSkeleton />;
  if (q.isError || !s) {
    return (
      <div className="mx-auto mt-16 max-w-md rounded-xl border border-destructive/40 bg-card p-6 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
        <h2 className="mt-3 font-display text-2xl font-bold uppercase">Mock unavailable</h2>
        <p className="mt-2 text-sm text-muted-foreground">{errMsg(q.error)}</p>
        <div className="mt-5 flex justify-center gap-2">
          <Button data-testid="button-retry" onClick={() => q.refetch()}>Retry</Button>
          <Link href="/mock-lab" className="rounded-md border border-border px-4 py-2 text-sm font-semibold">Back to lab</Link>
        </div>
      </div>
    );
  }
  return <RoomBody s={s} fetching={q.isFetching} syncedAt={q.dataUpdatedAt} />;
}

function useCountdown(s: MockState, syncedAt: number) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(t);
  }, []);
  if (!s.deadlineAt || s.status !== "drafting") return null;
  const offset = new Date(s.serverNow).getTime() - syncedAt;
  const left = new Date(s.deadlineAt).getTime() - (now + offset);
  return Math.max(0, Math.ceil(left / 1000));
}

function RoomBody({ s, fetching, syncedAt }: { s: MockState; fetching: boolean; syncedAt: number }) {
  useMockPageMeta(`${s.name} — Mock Draft Lab`);
  const d = useMemo(() => mockDerive(s), [s]);
  const act = useMockAct(s.id);
  const { toast } = useToast();
  const secs = useCountdown(s, syncedAt);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const exp = useExportMockDraft(s.id, { query: { enabled: false, queryKey: getExportMockDraftQueryKey(s.id) } });

  const current = s.currentTeamId ? d.teamsById.get(s.currentTeamId) : undefined;
  const myTurn = s.status === "drafting" && !!s.viewerTeamId && s.currentTeamId === s.viewerTeamId;
  const openHumans = s.teams.filter((t) => t.kind === "human" && !t.userId).length;
  const st = MOCK_STATUS[s.status];
  const inviteUrl = `${window.location.origin}${basePath}/mock-lab?code=${encodeURIComponent(s.inviteCode)}`;

  const download = async () => {
    const r = await exp.refetch();
    if (r.error || !r.data) {
      toast({ title: "Export failed", description: errMsg(r.error), variant: "destructive" });
      return;
    }
    const blob = new Blob([JSON.stringify(r.data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `mock-${s.name.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-${s.id.slice(0, 8)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const copy = (text: string, what: string) =>
    navigator.clipboard.writeText(text).then(
      () => toast({ title: `${what} copied` }),
      () => toast({ title: "Copy failed", description: text, variant: "destructive" }),
    );

  return (
    <>
      <div className="stripe-gold border-b border-primary/30" data-testid="banner-data-label">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2 text-[13px]">
          <span className="inline-flex items-center gap-1.5 rounded bg-primary px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-widest text-primary-foreground"><FlaskConical className="h-3 w-3" /> Mock</span>
          <span className="text-foreground/85">{s.dataLabel}</span>
          <span className="ml-auto text-xs text-muted-foreground">Practice only. No league is changed.</span>
        </div>
      </div>
      <main className="mx-auto max-w-[1400px] px-4 pb-16 pt-5 rise">
        {/* header */}
        <div className="flex flex-wrap items-start gap-4">
          <div className="min-w-0 flex-1">
            <Link href="/mock-lab" className="font-mono text-[10px] uppercase tracking-[0.25em] text-primary hover:underline" data-testid="link-back-lab">Mock Draft Lab</Link>
            <h1 className="mt-1 truncate font-display text-3xl font-extrabold uppercase sm:text-4xl" data-testid="text-mock-name">{s.name}</h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <span className={cn("rounded-full px-2.5 py-0.5 font-semibold", st?.tone)} data-testid="status-mock">{st?.label}</span>
              <span>{d.n} teams</span><span>·</span>
              <span>{s.timerSeconds ? `${s.timerSeconds}s clock` : "Untimed"}</span><span>·</span>
              <span>CPU {s.cpuStrategy}</span><span>·</span>
              <span className="inline-flex items-center gap-1" data-testid="status-sync"><RefreshCw className={cn("h-3 w-3", fetching && "animate-spin text-primary")} />Polling 3s</span>
              {s.restartedFrom && <><span>·</span><Link href={`/mock-lab/${s.restartedFrom}`} className="text-primary hover:underline" data-testid="link-restarted-from">Restart of earlier mock</Link></>}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {s.isOwner && s.status === "lobby" && (
              <Button data-testid="button-start" disabled={act.pending || openHumans > 0} onClick={() => act.run({ action: "start" })}><Play className="h-4 w-4" />Start draft</Button>
            )}
            {s.isOwner && s.status === "drafting" && (
              <Button variant="secondary" data-testid="button-pause" disabled={act.pending} onClick={() => act.run({ action: "pause" })}><Pause className="h-4 w-4" />Pause</Button>
            )}
            {s.isOwner && s.status === "paused" && (
              <Button data-testid="button-resume" disabled={act.pending} onClick={() => act.run({ action: "resume" })}><Play className="h-4 w-4" />Resume</Button>
            )}
            {s.isOwner && s.status !== "lobby" && (
              <Button variant="secondary" data-testid="button-restart" disabled={act.pending} onClick={() => setConfirmRestart(true)}><RotateCcw className="h-4 w-4" />Restart</Button>
            )}
            <Button variant="secondary" data-testid="button-export" disabled={exp.isFetching} onClick={download}><Download className="h-4 w-4" />{exp.isFetching ? "Exporting..." : "Export JSON"}</Button>
          </div>
        </div>

        {/* clock strip */}
        <section className="mt-5 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-[minmax(260px,1fr)_2fr]">
          <div className={cn("relative bg-card p-4", myTurn && "bg-[linear-gradient(110deg,hsl(40_96%_56%/.18),hsl(221_42%_10%))]")}>
            {s.status === "lobby" ? (
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Lobby</div>
                <div className="mt-1 font-display text-2xl font-bold uppercase">{openHumans ? `Waiting on ${openHumans} human seat${openHumans > 1 ? "s" : ""}` : "All seats filled"}</div>
                <p className="mt-1 text-xs text-muted-foreground">{s.isOwner ? (openHumans ? "Share the invite code. Start unlocks when every human seat is joined." : "Ready when you are.") : "The owner starts the draft once every human seat is joined."}</p>
              </div>
            ) : s.status === "completed" ? (
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-[hsl(152_55%_66%)]">Final</div>
                <div className="mt-1 font-display text-2xl font-bold uppercase">Draft complete</div>
                <p className="mt-1 text-xs text-muted-foreground">{s.picks.length} picks made · {s.picks.filter((p) => p.automated).length} automated</p>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <div className="min-w-0 flex-1">
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">On the clock · pick {pickLabel(s.pickNumber, d.n)}</div>
                  <div className="mt-1 flex items-center gap-2 truncate font-display text-2xl font-bold uppercase" data-testid="text-current-team">
                    {current?.kind === "cpu" ? <Cpu className="h-5 w-5 shrink-0 text-muted-foreground" /> : <User className="h-5 w-5 shrink-0 text-primary" />}
                    <span className="truncate">{current?.name ?? "Waiting"}</span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {s.status === "paused" ? "Paused by the owner." : myTurn ? "You are up. Pick from the pool." : current?.kind === "cpu" ? "CPU picks in about a second." : "Waiting on their pick."}
                  </p>
                </div>
                <div className="text-right" data-testid="text-timer">
                  <Timer className={cn("ml-auto h-4 w-4", secs !== null && secs <= 10 ? "text-destructive" : "text-muted-foreground")} />
                  <div className={cn("font-mono text-3xl font-bold tabular", secs !== null && secs <= 10 && "text-destructive")}>
                    {secs === null ? "--" : `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}`}
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className="bg-card p-4">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Up next</div>
            {d.upcoming.length ? (
              <div className="no-scrollbar flex gap-2 overflow-x-auto">
                {d.upcoming.map((u, i) => (
                  <div key={u.pick} className={cn("min-w-[120px] shrink-0 rounded-md border px-2.5 py-1.5", i === 0 && s.status !== "lobby" ? "border-primary/60 bg-primary/10" : "border-border", u.team.id === s.viewerTeamId && "ring-1 ring-primary/50")}>
                    <div className="font-mono text-[10px] text-muted-foreground">{pickLabel(u.pick, d.n)}</div>
                    <div className="truncate text-sm font-semibold">{u.team.name}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No picks remaining.</p>
            )}
          </div>
        </section>

        {s.status === "lobby" && <Lobby s={s} inviteUrl={inviteUrl} copy={copy} />}

        <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_340px]">
          <Tabs defaultValue={s.status === "completed" ? "rosters" : "pool"} className="min-w-0">
            <TabsList className="bg-secondary/60">
              <TabsTrigger value="pool" data-testid="tab-pool">Pool</TabsTrigger>
              <TabsTrigger value="board" data-testid="tab-board">Board</TabsTrigger>
              <TabsTrigger value="rosters" data-testid="tab-rosters">{s.status === "completed" ? "Results" : "Rosters"}</TabsTrigger>
            </TabsList>
            <TabsContent value="pool"><Pool s={s} d={d} act={act} myTurn={myTurn} /></TabsContent>
            <TabsContent value="board"><Board s={s} d={d} /></TabsContent>
            <TabsContent value="rosters"><Rosters s={s} d={d} /></TabsContent>
          </Tabs>
          <div className="space-y-5">
            <Queue s={s} d={d} act={act} myTurn={myTurn} />
            <ActivityFeed s={s} />
          </div>
        </div>
      </main>

      <AlertDialog open={confirmRestart} onOpenChange={setConfirmRestart}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-2xl uppercase">Restart in a new room?</AlertDialogTitle>
            <AlertDialogDescription>
              This creates a new mock with the same seats, members, pool and settings, and no picks. This mock and its results stay in your history untouched.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-restart">Cancel</AlertDialogCancel>
            <AlertDialogAction data-testid="button-confirm-restart" onClick={() => act.run({ action: "restart" })}>Create new room</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

type D = ReturnType<typeof mockDerive>;
type Act = ReturnType<typeof useMockAct>;

function Lobby({ s, inviteUrl, copy }: { s: MockState; inviteUrl: string; copy: (t: string, w: string) => void }) {
  const order = [...s.teams].sort((a, b) => a.draftOrder - b.draftOrder);
  return (
    <section className="mt-5 grid gap-4 rounded-xl border border-border bg-card p-4 md:grid-cols-[1fr_1.4fr]">
      <div>
        <div className="font-mono text-[10px] uppercase tracking-widest text-primary">Invite</div>
        <div className="mt-2 flex items-center gap-2">
          <code className="rounded-md border border-primary/40 bg-background px-3 py-2 font-mono text-lg font-bold tracking-widest text-primary" data-testid="text-invite-code">{s.inviteCode}</code>
          <Button size="icon" variant="ghost" data-testid="button-copy-code" onClick={() => copy(s.inviteCode, "Code")}><Copy className="h-4 w-4" /></Button>
        </div>
        <Button size="sm" variant="secondary" className="mt-2" data-testid="button-copy-link" onClick={() => copy(inviteUrl, "Invite link")}>Copy invite link</Button>
        <p className="mt-2 text-xs text-muted-foreground">Each join takes the first empty human seat.</p>
      </div>
      <ol className="grid gap-1.5 sm:grid-cols-2">
        {order.map((t) => (
          <li key={t.id} className="flex items-center gap-2 rounded-md bg-secondary/50 px-2 py-1.5 text-sm" data-testid={`row-seat-${t.id}`}>
            <span className="w-5 font-mono text-xs text-primary">{t.draftOrder}</span>
            {t.kind === "cpu" ? <Cpu className="h-3.5 w-3.5 text-muted-foreground" /> : <User className="h-3.5 w-3.5 text-primary" />}
            <span className="min-w-0 flex-1 truncate">{t.name}</span>
            <span className={cn("font-mono text-[10px] uppercase", t.kind === "cpu" ? "text-muted-foreground" : t.userId ? "text-[hsl(152_55%_66%)]" : "text-primary")}>
              {t.kind === "cpu" ? "CPU" : t.userId ? (t.id === s.viewerTeamId ? "You" : "Joined") : "Open"}
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}

function Pool({ s, d, act, myTurn }: { s: MockState; d: D; act: Act; myTurn: boolean }) {
  const [term, setTerm] = useState("");
  const [pos, setPos] = useState<string>("ALL");
  const [showTaken, setShowTaken] = useState(false);
  const queued = useMemo(() => new Set(s.queue), [s.queue]);
  const rows = useMemo(() => {
    const t = term.trim().toLowerCase();
    return s.players.filter((p) => {
      if (pos !== "ALL" && p.position !== pos) return false;
      if (!showTaken && d.lockedCanon.has(p.canonicalId)) return false;
      if (t && !`${p.name} ${p.nflTeam} ${p.season}`.toLowerCase().includes(t)) return false;
      return true;
    });
  }, [s.players, term, pos, showTaken, d.lockedCanon]);
  const canQueue = s.status !== "completed" && !!s.viewerTeamId;
  const shown = rows.slice(0, 200);

  return (
    <section className="rounded-xl border border-border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b border-border p-3">
        <div className="relative min-w-[180px] flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input data-testid="input-pool-search" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search name, team, season" className="h-9 pl-8" />
        </div>
        <div className="flex flex-wrap gap-1">
          {["ALL", ...POSITIONS].map((p) => (
            <button key={p} data-testid={`button-pos-${p}`} onClick={() => setPos(p)} className={cn("rounded px-2 py-1 font-mono text-[11px] font-semibold", pos === p ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary")}>{p}</button>
          ))}
        </div>
        <label className="flex items-center gap-1.5 text-xs text-muted-foreground"><input type="checkbox" data-testid="checkbox-show-taken" checked={showTaken} onChange={(e) => setShowTaken(e.target.checked)} />Show locked</label>
      </div>
      {s.players.length === 0 ? (
        <p className="p-8 text-center text-sm text-muted-foreground">This mock has no player snapshot.</p>
      ) : rows.length === 0 ? (
        <p className="p-8 text-center text-sm text-muted-foreground">No players match. Clear the search or switch positions.</p>
      ) : (
        <div className="max-h-[560px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-card font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-3 py-2 text-left">Player</th><th className="hidden px-2 text-left sm:table-cell">Team</th><th className="px-2 text-left">Season</th><th className="px-3 text-right">Action</th></tr>
            </thead>
            <tbody>
              {shown.map((p) => {
                const lockedTeam = d.lockedCanon.get(p.canonicalId);
                const pending = act.pending && act.variables?.playerId === p.id;
                return (
                  <tr key={p.id} className={cn("border-t border-border/60", lockedTeam && "opacity-45")} data-testid={`row-player-${p.id}`}>
                    <td className="px-3 py-2"><div className="flex items-center gap-2"><PosChip pos={p.position} /><span className="font-semibold">{p.name}</span></div></td>
                    <td className="hidden px-2 text-muted-foreground sm:table-cell">{p.nflTeam}</td>
                    <td className="px-2 font-mono text-xs">{p.season}</td>
                    <td className="px-3 py-1.5 text-right">
                      {lockedTeam ? (
                        <span className="font-mono text-[10px] uppercase text-muted-foreground">{d.teamsById.get(lockedTeam)?.name ?? "Locked"}</span>
                      ) : (
                        <div className="flex justify-end gap-1">
                          {canQueue && (
                            <Button size="sm" variant="ghost" className="h-7 px-2" data-testid={`button-queue-${p.id}`} disabled={act.pending || queued.has(p.id)}
                              onClick={() => act.run({ action: "queueAdd", playerId: p.id })}>
                              <ListPlus className="h-3.5 w-3.5" />{queued.has(p.id) ? "Queued" : "Queue"}
                            </Button>
                          )}
                          <Button size="sm" className="h-7 px-3" data-testid={`button-pick-${p.id}`} disabled={!myTurn || act.pending} onClick={() => act.run({ action: "pick", playerId: p.id })}>
                            {pending ? "..." : "Draft"}
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {rows.length > shown.length && <p className="border-t border-border p-3 text-center text-xs text-muted-foreground">Showing 200 of {rows.length}. Narrow the search to see more.</p>}
        </div>
      )}
    </section>
  );
}

function Board({ s, d }: { s: MockState; d: D }) {
  const rounds = Array.from({ length: 15 }, (_, i) => i + 1);
  return (
    <section className="overflow-x-auto rounded-xl border border-border bg-card p-3">
      <div className="grid min-w-[720px] gap-1" style={{ gridTemplateColumns: `40px repeat(${d.n}, minmax(96px,1fr))` }}>
        <div />
        {d.order.map((t) => (
          <div key={t.id} className={cn("truncate rounded px-1.5 py-1 text-center text-[11px] font-bold uppercase", t.id === s.viewerTeamId ? "bg-primary/20 text-primary" : "bg-secondary/60")}>{t.name}</div>
        ))}
        {rounds.map((r) => (
          <BoardRow key={r} r={r} s={s} d={d} />
        ))}
      </div>
    </section>
  );
}

function BoardRow({ r, s, d }: { r: number; s: MockState; d: D }) {
  return (
    <>
      <div className="flex items-center justify-center font-mono text-[10px] text-muted-foreground">R{r}</div>
      {d.order.map((t, col) => {
        const pickNo = r % 2 === 1 ? (r - 1) * d.n + col + 1 : (r - 1) * d.n + (d.n - col);
        const pk = d.pickByNumber.get(pickNo);
        const pl = pk ? d.playersById.get(pk.playerId) : undefined;
        const isCur = s.status !== "completed" && s.status !== "lobby" && pickNo === s.pickNumber;
        return (
          <div key={t.id} data-testid={`cell-pick-${pickNo}`}
            className={cn("h-14 rounded border p-1 text-[11px]", pk ? "border-border bg-secondary/60" : isCur ? "border-primary bg-primary/10" : "border-dashed border-border/50")}>
            <div className="flex items-center justify-between font-mono text-[9px] text-muted-foreground">
              <span>{pickLabel(pickNo, d.n)}</span>
              {pk?.automated && <span className="text-primary/80">AUTO</span>}
            </div>
            {pl ? (
              <div className="mt-0.5"><div className="truncate font-semibold leading-tight">{pl.name}</div><div className="font-mono text-[9px] text-muted-foreground">{pl.position} · {pl.season}</div></div>
            ) : isCur ? <div className="mt-1 font-mono text-[9px] uppercase text-primary">On clock</div> : null}
          </div>
        );
      })}
    </>
  );
}

function Rosters({ s, d }: { s: MockState; d: D }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {d.order.map((t) => {
        const mine = s.picks.filter((p) => p.teamId === t.id).sort((a, b) => a.pickNumber - b.pickNumber);
        return (
          <section key={t.id} className={cn("rounded-xl border bg-card p-3", t.id === s.viewerTeamId ? "border-primary/50" : "border-border")} data-testid={`card-roster-${t.id}`}>
            <div className="mb-2 flex items-center gap-2">
              {t.kind === "cpu" ? <Cpu className="h-4 w-4 text-muted-foreground" /> : <User className="h-4 w-4 text-primary" />}
              <h3 className="min-w-0 flex-1 truncate font-display text-lg font-bold uppercase">{t.name}</h3>
              <span className="font-mono text-[10px] text-muted-foreground">{mine.length}/15</span>
            </div>
            <ul className="space-y-0.5 text-sm">
              {SLOT_LIMITS.flatMap(({ slot, max }) => {
                const inSlot = mine.filter((p) => p.slot === slot);
                return Array.from({ length: max }, (_, i) => {
                  const pk = inSlot[i];
                  const pl = pk ? d.playersById.get(pk.playerId) : undefined;
                  return (
                    <li key={`${slot}-${i}`} className="flex items-center gap-2 border-b border-border/40 py-0.5">
                      <span className="w-11 font-mono text-[10px] text-muted-foreground">{slot === "Bench" ? "BN" : slot}</span>
                      {pl ? <><PosChip pos={pl.position} /><span className="min-w-0 flex-1 truncate">{pl.name}</span><span className="font-mono text-[10px] text-muted-foreground">{pl.season}</span></> : <span className="text-xs text-muted-foreground/50">Empty</span>}
                    </li>
                  );
                });
              })}
            </ul>
          </section>
        );
      })}
    </div>
  );
}

function Queue({ s, d, act, myTurn }: { s: MockState; d: D; act: Act; myTurn: boolean }) {
  const editable = s.status !== "completed" && !!s.viewerTeamId;
  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <div className="mb-1 flex items-center gap-2">
        <h2 className="font-display text-xl font-bold uppercase">My queue</h2>
        <span className="ml-auto font-mono text-[10px] uppercase text-muted-foreground">Private</span>
      </div>
      <p className="mb-3 text-xs text-muted-foreground">If your clock runs out, the server drafts your first eligible queued player.</p>
      {!s.viewerTeamId ? (
        <p className="text-sm text-muted-foreground">You are viewing without a seat.</p>
      ) : s.queue.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">Queue is empty. Add players from the pool.</div>
      ) : (
        <ol className="space-y-1">
          {s.queue.map((pid, i) => {
            const p = d.playersById.get(pid);
            return (
              <li key={pid} className="flex items-center gap-1.5 rounded-md bg-secondary/50 px-2 py-1 text-sm" data-testid={`row-queue-${pid}`}>
                <span className="w-4 font-mono text-[10px] text-primary">{i + 1}</span>
                {p && <PosChip pos={p.position} />}
                <span className="min-w-0 flex-1 truncate">{p ? `${p.name} '${String(p.season).slice(2)}` : "Unknown player"}</span>
                {myTurn && i === 0 && (
                  <Button size="sm" className="h-6 px-2 text-xs" data-testid={`button-queue-pick-${pid}`} disabled={act.pending} onClick={() => act.run({ action: "pick", playerId: pid })}>Draft</Button>
                )}
                <Button size="icon" variant="ghost" className="h-6 w-6" data-testid={`button-queue-up-${pid}`} disabled={!editable || i === 0 || act.pending} onClick={() => act.run({ action: "queueMove", playerId: pid, direction: -1 })}><ArrowUp className="h-3 w-3" /></Button>
                <Button size="icon" variant="ghost" className="h-6 w-6" data-testid={`button-queue-down-${pid}`} disabled={!editable || i === s.queue.length - 1 || act.pending} onClick={() => act.run({ action: "queueMove", playerId: pid, direction: 1 })}><ArrowDown className="h-3 w-3" /></Button>
                <Button size="icon" variant="ghost" className="h-6 w-6" data-testid={`button-queue-remove-${pid}`} disabled={!editable || act.pending} onClick={() => act.run({ action: "queueRemove", playerId: pid })}><X className="h-3 w-3" /></Button>
              </li>
            );
          })}
        </ol>
      )}
    </section>
  );
}

function ActivityFeed({ s }: { s: MockState }) {
  const items = [...s.activity].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 40);
  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <h2 className="mb-3 font-display text-xl font-bold uppercase">Activity</h2>
      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground">Nothing yet.</p>
      ) : (
        <ul className="max-h-[360px] space-y-2 overflow-y-auto">
          {items.map((a) => (
            <li key={a.id} className="border-l-2 border-primary/40 pl-2 text-sm" data-testid={`row-activity-${a.id}`}>
              <div>{a.message}</div>
              <div className="font-mono text-[10px] text-muted-foreground">{new Date(a.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

