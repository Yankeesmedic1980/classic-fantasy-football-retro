import { useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Plus, Ticket, Trophy } from "lucide-react";
import { getListLeaguesQueryKey, useCreateLeague, useJoinLeague, useListLeagues } from "@workspace/api-client-react";
import { TopBar } from "@/components/league-shell";
import { StatusPill } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { errMsg, SAMPLE_ID } from "@/lib/league";
import { cn } from "@/lib/utils";

export default function LeaguesPage() {
  const search = useSearch();
  const code0 = new URLSearchParams(search).get("code") ?? "";
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const list = useListLeagues();
  const create = useCreateLeague();
  const join = useJoinLeague();
  const [name, setName] = useState("");
  const [teamName, setTeamName] = useState("");
  const [mode, setMode] = useState<"sample" | "production">("sample");
  const [maxTeams, setMaxTeams] = useState("10");
  const [code, setCode] = useState(code0);
  const [joinTeam, setJoinTeam] = useState("");

  const done = (id: string) => {
    qc.invalidateQueries({ queryKey: getListLeaguesQueryKey() });
    setLocation(`/league/${id}`);
  };

  return (
    <div className="min-h-[100dvh]">
      <TopBar />
      <main className="mx-auto max-w-[1200px] px-4 pb-16 pt-8">
        <div className="rise">
          <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary/80">Fantasy football. Every era. One draft.</div>
          <h1 className="font-display text-5xl font-extrabold uppercase leading-none">My leagues</h1>
        </div>
        <div className="mt-6 grid gap-5 lg:grid-cols-12">
          <section className="space-y-2 lg:col-span-7">
            {list.isLoading ? (
              [0, 1, 2].map((i) => <Skeleton key={i} className="h-20" />)
            ) : list.isError ? (
              <div className="rounded-xl border border-destructive/40 bg-card p-5 text-sm">
                {errMsg(list.error)} <Button size="sm" className="ml-2" onClick={() => list.refetch()} data-testid="button-retry">Retry</Button>
              </div>
            ) : (list.data ?? []).length === 0 ? (
              <div className="rounded-xl border border-dashed border-border bg-card/50 p-8 text-center">
                <Trophy className="mx-auto h-8 w-8 text-primary" />
                <h2 className="mt-3 font-display text-2xl font-bold uppercase">No leagues yet</h2>
                <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">Start one and send the invite link, or paste a code from your commissioner.</p>
              </div>
            ) : (
              list.data!.map((l, i) => (
                <Link key={l.id} href={`/league/${l.id}`} data-testid={`card-league-${l.id}`} style={{ animationDelay: `${i * 50}ms` }}
                  className="rise group flex items-center gap-4 rounded-xl border border-card-border bg-card/80 p-4 transition-colors hover:border-primary/50">
                  <span className="grid h-11 w-11 place-items-center rounded-lg bg-secondary font-display text-lg font-bold text-primary">{l.name.slice(0, 2).toUpperCase()}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-display text-xl font-bold uppercase">{l.name}</span>
                    <span className="font-mono text-[10px] uppercase text-muted-foreground">{l.mode === "production" ? "Production" : "Sample data"} · {l.maxTeams} teams · pick {l.pickNumber}</span>
                  </span>
                  <StatusPill status={l.status} />
                  <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
                </Link>
              ))
            )}
            <Link href={`/league/${SAMPLE_ID}`} data-testid="link-sample" className="block pt-2 text-[13px] text-muted-foreground hover:text-primary">Browse the read-only sample league</Link>
          </section>

          <aside className="space-y-4 lg:col-span-5">
            <form
              className={cn("rounded-xl border bg-card/80 p-4", code0 ? "border-primary/60" : "border-card-border")}
              onSubmit={(e) => {
                e.preventDefault();
                join.mutate({ data: { code: code.trim(), teamName: joinTeam.trim() } }, { onSuccess: (l) => done(l.id) });
              }}
            >
              <h2 className="flex items-center gap-2 font-display text-xl font-bold uppercase"><Ticket className="h-5 w-5 text-primary" />Join with invite</h2>
              <div className="mt-3 grid gap-2">
                <Input placeholder="Invite code" value={code} onChange={(e) => setCode(e.target.value)} className="font-mono" data-testid="input-join-code" />
                <Input placeholder="Your team name" value={joinTeam} onChange={(e) => setJoinTeam(e.target.value)} data-testid="input-join-team" />
                {join.isError && <p className="text-[12px] text-destructive">{errMsg(join.error)}</p>}
                <Button type="submit" disabled={!code.trim() || joinTeam.trim().length < 2 || join.isPending} data-testid="button-join">{join.isPending ? "Joining" : "Join league"}</Button>
              </div>
            </form>

            <form
              className="rounded-xl border border-card-border bg-card/80 p-4"
              onSubmit={(e) => {
                e.preventDefault();
                create.mutate({ data: { name: name.trim(), teamName: teamName.trim(), mode, maxTeams: Number(maxTeams) } }, { onSuccess: (l) => done(l.id) });
              }}
            >
              <h2 className="flex items-center gap-2 font-display text-xl font-bold uppercase"><Plus className="h-5 w-5 text-primary" />Create a league</h2>
              <div className="mt-3 grid gap-3">
                <div><Label className="text-[12px]">League name</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sunday Ironmen" data-testid="input-league-name" /></div>
                <div><Label className="text-[12px]">Your team name</Label><Input value={teamName} onChange={(e) => setTeamName(e.target.value)} placeholder="Frozen Tundra" data-testid="input-team-name" /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[12px]">Teams</Label>
                    <Select value={maxTeams} onValueChange={setMaxTeams}>
                      <SelectTrigger data-testid="select-max-teams"><SelectValue /></SelectTrigger>
                      <SelectContent>{Array.from({ length: 11 }, (_, i) => i + 2).map((n) => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[12px]">Player pool</Label>
                    <Select value={mode} onValueChange={(v) => setMode(v as "sample" | "production")}>
                      <SelectTrigger data-testid="select-mode"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sample">Sample data</SelectItem>
                        <SelectItem value="production">Production</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {mode === "sample" ? "Includes unverified sample seasons for trying things out." : "Excludes all sample, unapproved and active-career seasons. You add verified seasons yourself."}
                </p>
                {create.isError && <p className="text-[12px] text-destructive">{errMsg(create.error)}</p>}
                <Button type="submit" disabled={name.trim().length < 2 || teamName.trim().length < 2 || create.isPending} data-testid="button-create">{create.isPending ? "Creating" : "Create league"}</Button>
              </div>
            </form>
          </aside>
        </div>
      </main>
    </div>
  );
}
