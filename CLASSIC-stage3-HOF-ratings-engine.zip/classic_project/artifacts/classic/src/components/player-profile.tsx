import { useMemo, useState } from "react";
import { Award, BarChart3, BookOpen, GitCompareArrows, ShieldAlert } from "lucide-react";
import { PosChip } from "@/components/brand";
import { HallOfFameMark, type HallOfFameStatus } from "@/components/hall-of-fame-mark";
import { getHallOfFameStatus } from "@/lib/hall-of-fame";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export type PlayerSeason = {
  id: string;
  canonicalId: string;
  name: string;
  position: string;
  nflTeam: string;
  season: number;
  retired: boolean;
  approved: boolean;
  sample: boolean;
  hallOfFame?: HallOfFameStatus;
};

export function PlayerProfile({ player, players, open, onOpenChange }: {
  player: PlayerSeason | null;
  players: PlayerSeason[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [compareId, setCompareId] = useState("");
  const related = useMemo(() => player ? players.filter(p => p.canonicalId === player.canonicalId && p.id !== player.id).sort((a,b) => b.season-a.season) : [], [player, players]);
  const comparison = related.find(p => p.id === compareId);
  if (!player) return null;
  const verified = !player.sample && player.approved;
  const hallOfFame = player.hallOfFame ?? getHallOfFameStatus(player.name);

  return <Dialog open={open} onOpenChange={(value) => { onOpenChange(value); if (!value) setCompareId(""); }}>
    <DialogContent className="max-w-2xl border-primary/25 bg-card">
      <DialogHeader>
        <div className="flex flex-wrap items-center gap-2"><PosChip pos={player.position}/><span className="font-mono text-xs uppercase tracking-widest text-primary">{player.season} season · {player.nflTeam}</span></div>
        <div className="flex flex-wrap items-center gap-2"><DialogTitle className="font-display text-3xl font-extrabold uppercase">{player.name}</DialogTitle><HallOfFameMark status={hallOfFame} /></div>
        <p className="text-xs text-muted-foreground">{hallOfFame?.status === "inducted" ? `Pro Football Hall of Fame${hallOfFame.inductionYear ? ` · inducted ${hallOfFame.inductionYear}` : ""}${hallOfFame.source ? ` · Source: ${hallOfFame.source}` : ""}` : hallOfFame?.status === "not_inducted" ? "Hall of Fame status checked: not inducted" : "Hall of Fame status has not yet been verified for this player."}</p>
        <DialogDescription>Historical player-season profile</DialogDescription>
      </DialogHeader>

      <div className="grid gap-3 sm:grid-cols-2">
        <section className="rounded-lg border border-border bg-background/50 p-4 sm:col-span-2">
          <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-primary"><Award className="h-4 w-4"/> CLASSIC Performance Rating</div>
          <div className="flex flex-wrap items-end justify-between gap-2"><div className="font-display text-4xl font-extrabold text-muted-foreground">— <span className="text-sm font-semibold">/ 100</span></div><span className="rounded bg-secondary px-2 py-1 font-mono text-[10px] uppercase text-muted-foreground">Rating unavailable</span></div>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">A verified season-statistics dataset and position/era comparison group are not present in this project’s player records. CLASSIC will not guess a score or assign a performance tier.</p>
        </section>
        <section className="rounded-lg border border-border bg-background/50 p-4">
          <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-primary"><BookOpen className="h-4 w-4"/> Biography</div>
          <p className="text-sm leading-relaxed text-muted-foreground">Historical biography and career overview are not yet available in the verified player data source.</p>
        </section>
        <section className="rounded-lg border border-border bg-background/50 p-4">
          <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-primary"><BarChart3 className="h-4 w-4"/> Season statistics</div>
          <p className="text-sm leading-relaxed text-muted-foreground">No verified statistics are attached to this player-season record.</p>
        </section>
        <section className="rounded-lg border border-border bg-background/50 p-4 sm:col-span-2">
          <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-primary"><ShieldAlert className="h-4 w-4"/> Data integrity</div>
          <div className="flex flex-wrap items-center gap-2 text-sm"><span className={`h-2 w-2 rounded-full ${verified ? "bg-emerald-400" : "bg-amber-400"}`}/><strong>{verified ? "Commissioner-approved record" : player.sample ? "Illustrative sample record" : "Unverified record"}</strong></div>
          <p className="mt-1 text-xs text-muted-foreground">Approval confirms league eligibility only; it does not independently verify biographies, awards, or statistical performance. No external source is currently attached.</p>
        </section>
      </div>

      <section className="rounded-lg border border-border bg-background/50 p-4">
        <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-primary"><GitCompareArrows className="h-4 w-4"/> Compare another season</div>
        {related.length ? <>
          <Select value={compareId} onValueChange={setCompareId}><SelectTrigger><SelectValue placeholder="Choose another season of this player"/></SelectTrigger><SelectContent>{related.map(p => <SelectItem key={p.id} value={p.id}>{p.season} · {p.nflTeam}</SelectItem>)}</SelectContent></Select>
          {comparison && <div className="mt-3 grid grid-cols-2 gap-2 text-sm"><div className="rounded border border-border p-3"><div className="font-mono text-[10px] text-muted-foreground">SELECTED</div><strong>{player.season} · {player.nflTeam}</strong><p className="mt-1 text-xs text-muted-foreground">Rating and stats unavailable</p></div><div className="rounded border border-border p-3"><div className="font-mono text-[10px] text-muted-foreground">COMPARISON</div><strong>{comparison.season} · {comparison.nflTeam}</strong><p className="mt-1 text-xs text-muted-foreground">Rating and stats unavailable</p></div></div>}
        </> : <p className="text-sm text-muted-foreground">No other season for this player is currently in this league’s player pool.</p>}
      </section>
    </DialogContent>
  </Dialog>;
}
