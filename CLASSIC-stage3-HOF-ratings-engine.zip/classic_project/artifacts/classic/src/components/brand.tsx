import { cn } from "@/lib/utils";
import { POS_COLOR, STATUS_LABEL } from "@/lib/league";

const base = import.meta.env.BASE_URL.replace(/\/$/, "");

export function Logo({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <img src={`${base}/logo.svg`} alt="" className="h-8 w-8" />
      {!compact && (
        <span className="leading-none">
          <span className="font-display text-[22px] font-800 font-extrabold tracking-[0.14em] text-foreground">CLASSIC</span>
          <span className="block font-mono text-[9px] uppercase tracking-[0.28em] text-primary/80">Retro Edition</span>
        </span>
      )}
    </span>
  );
}

export function PosChip({ pos, className }: { pos: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex h-5 min-w-9 items-center justify-center rounded-[4px] px-1.5 font-mono text-[10px] font-semibold ring-1 ring-inset",
        POS_COLOR[pos] ?? "bg-muted text-muted-foreground ring-border",
        className,
      )}
    >
      {pos}
    </span>
  );
}

export function StatusPill({ status }: { status: string }) {
  const tone =
    status === "live"
      ? "bg-primary text-primary-foreground"
      : status === "paused"
        ? "bg-[hsl(28_85%_56%/.18)] text-[hsl(28_90%_70%)]"
        : status === "completed"
          ? "bg-[hsl(152_46%_48%/.16)] text-[hsl(152_55%_66%)]"
          : "bg-secondary text-secondary-foreground";
  return (
    <span
      data-testid="status-league"
      className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider", tone)}
    >
      {status === "live" && <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-primary-foreground" />}
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function SectionTitle({ kicker, title, right }: { kicker?: string; title: string; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        {kicker && <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary/80">{kicker}</div>}
        <h2 className="font-display text-xl font-bold uppercase tracking-wide">{title}</h2>
      </div>
      {right}
    </div>
  );
}

export function Panel({ className, children }: { className?: string; children: React.ReactNode }) {
  return <section className={cn("rounded-xl border border-card-border bg-card/80 p-4 backdrop-blur-sm", className)}>{children}</section>;
}
