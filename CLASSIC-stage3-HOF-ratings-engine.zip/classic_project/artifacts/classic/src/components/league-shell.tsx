import { createContext, useContext, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Show, useClerk, useUser } from "@clerk/react";
import { getGetLeagueQueryKey, useGetLeague, type LeagueState } from "@workspace/api-client-react";
import { AlertTriangle, FlaskConical, LayoutDashboard, ListOrdered, Lock, LogOut, RefreshCw, Search, Settings, Shirt, Trophy } from "lucide-react";
import { Logo, StatusPill } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAct } from "@/hooks/use-act";
import { derive, errMsg, SAMPLE_ID } from "@/lib/league";
import { cn } from "@/lib/utils";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export type LeagueCtx = {
  id: string;
  state: LeagueState;
  d: ReturnType<typeof derive>;
  readOnly: boolean;
  isSample: boolean;
  act: ReturnType<typeof useAct>;
  requireAccess: () => boolean;
};

const Ctx = createContext<LeagueCtx | null>(null);
export function useLeagueCtx() {
  const c = useContext(Ctx);
  if (!c) throw new Error("League context missing");
  return c;
}

export function TopBar({ children }: { children?: ReactNode }) {
  const { signOut } = useClerk();
  const { user } = useUser();
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(223_48%_6%/.86)] backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-2 px-3 sm:gap-3 sm:px-4">
        <Link href="/" data-testid="link-home" className="shrink-0">
          <Logo />
        </Link>
        <div className="min-w-0 flex-1">{children}</div>
        <Link href="/mock-lab" data-testid="link-mock-lab" className="flex shrink-0 items-center gap-1.5 rounded-md border border-primary/30 px-2 py-1 text-sm font-semibold text-primary hover:bg-primary/10" title="Mock Draft Lab">
          <FlaskConical className="h-4 w-4" />
          <span className="hidden sm:inline">Mock Draft Lab</span>
          <span className="sm:hidden">Mock</span>
        </Link>
        <Show when="signed-in">
          <Link href="/leagues" data-testid="link-leagues" className="hidden text-sm font-semibold text-muted-foreground hover:text-foreground sm:block">
            My leagues
          </Link>
          <span className="hidden max-w-[140px] truncate font-mono text-[11px] text-muted-foreground md:block">
            {user?.primaryEmailAddress?.emailAddress}
          </span>
          <Button size="icon" variant="ghost" data-testid="button-sign-out" title="Sign out" onClick={() => signOut({ redirectUrl: basePath || "/" })}>
            <LogOut className="h-4 w-4" />
          </Button>
        </Show>
        <Show when="signed-out">
          <Link href="/sign-in" data-testid="link-sign-in" className="shrink-0 whitespace-nowrap text-sm font-semibold text-muted-foreground hover:text-foreground">
            Sign in
          </Link>
          <Link
            href="/sign-up"
            data-testid="link-sign-up"
            className="shrink-0 whitespace-nowrap rounded-md bg-primary px-3 py-1.5 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-px"
          >
            <span className="sm:hidden">Join</span><span className="hidden sm:inline">Create your league</span>
          </Link>
        </Show>
      </div>
    </header>
  );
}

const TABS = [
  { key: "", label: "Dashboard", icon: LayoutDashboard },
  { key: "draft", label: "Draft", icon: ListOrdered },
  { key: "players", label: "Players", icon: Search },
  { key: "rosters", label: "Rosters", icon: Shirt },
  { key: "settings", label: "Settings", icon: Settings },
];

export function SampleBanner() {
  return (
    <div data-testid="banner-sample" className="stripe-gold border-b border-primary/30">
      <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-x-4 gap-y-2 px-4 py-2 text-[13px]">
        <span className="inline-flex items-center gap-1.5 rounded bg-primary px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-widest text-primary-foreground">
          <Lock className="h-3 w-3" /> Sample league
        </span>
        <span className="text-foreground/85">Read-only demo. Player seasons here are unverified sample data, not official records.</span>
        <Link href="/sign-up" data-testid="link-banner-create" className="ml-auto font-bold text-primary underline-offset-4 hover:underline">
          Create your league
        </Link>
      </div>
    </div>
  );
}

export function LeagueShell({ id, tab, children }: { id: string; tab: string; children: (c: LeagueCtx) => ReactNode }) {
  const { isSignedIn } = useUser();
  const [, setLocation] = useLocation();
  const [gate, setGate] = useState(false);
  const act = useAct(id);
  const q = useGetLeague(id, { query: { queryKey: getGetLeagueQueryKey(id), refetchInterval: 3000 } });
  const state = q.data;
  const isSample = id === SAMPLE_ID || state?.league.mode === "sample" && !state?.viewerTeamId;
  const readOnly = !isSignedIn || id === SAMPLE_ID || (!!state && !state.viewerTeamId && !state.isCommissioner);
  const href = (k: string) => (id === SAMPLE_ID && !isSignedIn && k === "" ? "/" : `/league/${id}${k ? `/${k}` : ""}`);

  return (
    <div className="min-h-[100dvh]">
      <TopBar>
        {state && (
          <div className="hidden min-w-0 items-center gap-2 border-l border-border pl-3 md:flex">
            <Trophy className="h-4 w-4 shrink-0 text-primary" />
            <span className="truncate font-display text-lg font-bold uppercase" data-testid="text-league-name">{state.league.name}</span>
            <StatusPill status={state.league.status} />
          </div>
        )}
      </TopBar>
      {(id === SAMPLE_ID || isSample) && <SampleBanner />}
      <nav className="sticky top-14 z-30 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="no-scrollbar mx-auto flex max-w-[1400px] gap-1 overflow-x-auto px-2">
          {TABS.map((t) => {
            const on = t.key === tab;
            return (
              <Link
                key={t.key}
                href={href(t.key)}
                data-testid={`tab-${t.key || "dashboard"}`}
                className={cn(
                  "relative flex shrink-0 items-center gap-2 px-3 py-3 text-[13px] font-semibold transition-colors",
                  on ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                )}
              >
                <t.icon className={cn("h-4 w-4", on && "text-primary")} />
                {t.label}
                <span className={cn("absolute inset-x-2 -bottom-px h-[2px] origin-left bg-primary transition-transform duration-300", on ? "scale-x-100" : "scale-x-0")} />
              </Link>
            );
          })}
          {state && (
            <div className="ml-auto hidden shrink-0 items-center gap-2 pr-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground sm:flex" data-testid="status-sync">
              <RefreshCw className={cn("h-3 w-3", q.isFetching && "animate-spin text-primary")} />
              Polling 3s · synced {new Date(q.dataUpdatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </div>
          )}
        </div>
      </nav>
      <main className="mx-auto max-w-[1400px] px-4 pb-16 pt-5">
        {q.isLoading ? (
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-40 md:col-span-2" />
            <Skeleton className="h-40" />
            <Skeleton className="h-72 md:col-span-3" />
          </div>
        ) : q.isError || !state ? (
          <div className="mx-auto mt-16 max-w-md rounded-xl border border-destructive/40 bg-card p-6 text-center">
            <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
            <h2 className="mt-3 font-display text-2xl font-bold uppercase">League unavailable</h2>
            <p className="mt-2 text-sm text-muted-foreground">{errMsg(q.error)}</p>
            <div className="mt-5 flex justify-center gap-2">
              <Button data-testid="button-retry" onClick={() => q.refetch()}>Retry</Button>
              {isSignedIn ? (
                <Button variant="secondary" onClick={() => setLocation("/leagues")}>My leagues</Button>
              ) : (
                <Button variant="secondary" onClick={() => setLocation("/sign-in")}>Sign in</Button>
              )}
            </div>
          </div>
        ) : (
          <Ctx.Provider value={buildCtx(id, state, readOnly, isSample, act, setGate)}>
            <div key={tab} className="rise">{children(buildCtx(id, state, readOnly, isSample, act, setGate))}</div>
          </Ctx.Provider>
        )}
      </main>
      <Dialog open={gate} onOpenChange={setGate}>
        <DialogContent className="border-primary/30">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl uppercase">This league is read-only</DialogTitle>
            <DialogDescription>
              {isSignedIn
                ? "You are viewing a league you do not manage. Create or join your own league to draft, trade and claim."
                : "The sample league is for browsing. Sign in and create your own private league to draft legends from every era."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-wrap justify-end gap-2">
            {!isSignedIn && (
              <Button variant="secondary" data-testid="button-gate-sign-in" onClick={() => setLocation("/sign-in")}>Sign in</Button>
            )}
            <Button data-testid="button-gate-create" onClick={() => setLocation(isSignedIn ? "/leagues" : "/sign-up")}>Create your league</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function buildCtx(
  id: string,
  state: LeagueState,
  readOnly: boolean,
  isSample: boolean,
  act: ReturnType<typeof useAct>,
  setGate: (b: boolean) => void,
): LeagueCtx {
  return {
    id,
    state,
    d: derive(state),
    readOnly,
    isSample,
    act,
    requireAccess: () => {
      if (readOnly) {
        setGate(true);
        return false;
      }
      return true;
    },
  };
}

/** Button that opens the read-only prompt when the viewer cannot act. */
export function ActButton({
  ctx,
  onRun,
  children,
  ...rest
}: { ctx: LeagueCtx; onRun: () => void; children: ReactNode } & Omit<React.ComponentProps<typeof Button>, "onClick">) {
  return (
    <Button
      {...rest}
      onClick={() => {
        if (ctx.requireAccess()) onRun();
      }}
      className={cn(rest.className, ctx.readOnly && "opacity-60")}
    >
      {ctx.readOnly && <Lock className="h-3 w-3" />}
      {children}
    </Button>
  );
}
