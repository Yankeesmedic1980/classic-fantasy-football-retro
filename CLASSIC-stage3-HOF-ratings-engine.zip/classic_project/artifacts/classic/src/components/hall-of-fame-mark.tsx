import { Award } from "lucide-react";

export type HallOfFameStatus = {
  status: "inducted" | "not_inducted" | "unknown";
  inductionYear?: number;
  source?: string;
};

/** A CLASSIC-created Hall of Fame indicator; it is not an official Hall of Fame logo. */
export function HallOfFameMark({ status, compact = false }: { status?: HallOfFameStatus; compact?: boolean }) {
  if (!status || status.status !== "inducted") return null;
  const label = `Pro Football Hall of Fame${status.inductionYear ? ` · inducted ${status.inductionYear}` : ""}`;
  return (
    <span
      title={label}
      aria-label={label}
      className={`inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-400/60 bg-amber-500/10 font-mono font-bold uppercase tracking-wide text-amber-300 shadow-sm shadow-amber-950/20 ${compact ? "px-1.5 py-0.5 text-[9px]" : "px-2 py-1 text-[10px]"}`}
    >
      <Award className={compact ? "h-3 w-3" : "h-3.5 w-3.5"} aria-hidden="true" />
      HOF{!compact && status.inductionYear ? ` · ${status.inductionYear}` : ""}
    </span>
  );
}
