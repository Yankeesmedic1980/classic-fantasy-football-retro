import { useEffect, useRef, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Redirect, Route, Switch, useLocation, useSearch, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { LeagueShell } from '@/components/league-shell';
import { Logo } from '@/components/brand';
import NotFound from '@/pages/not-found';
import DashboardPage, { DashboardBody } from '@/pages/dashboard';
import DraftPage from '@/pages/draft';
import PlayersPage from '@/pages/players';
import RostersPage from '@/pages/rosters';
import SettingsPage from '@/pages/settings';
import LeaguesPage from '@/pages/leagues';
import MockLabPage from '@/pages/mock-lab';
import MockRoomPage from '@/pages/mock-room';
import { SAMPLE_ID } from '@/lib/league';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1 } } });

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: 'hsl(40 96% 56%)',
    colorForeground: 'hsl(40 30% 94%)',
    colorMutedForeground: 'hsl(216 18% 66%)',
    colorDanger: 'hsl(4 74% 60%)',
    colorBackground: 'hsl(221 42% 10%)',
    colorInput: 'hsl(222 45% 8%)',
    colorInputForeground: 'hsl(40 30% 94%)',
    colorNeutral: 'hsl(40 30% 94%)',
    fontFamily: "'Manrope', sans-serif",
    borderRadius: '0.5rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[hsl(221_42%_10%)] border border-[hsl(218_32%_20%)] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-2xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: "text-[hsl(40_30%_94%)] uppercase tracking-wide font-bold text-2xl [font-family:'Barlow_Condensed',sans-serif]",
    headerSubtitle: 'text-[hsl(216_18%_70%)]',
    socialButtonsBlockButtonText: 'text-[hsl(40_30%_94%)] font-semibold',
    formFieldLabel: 'text-[hsl(40_25%_88%)]',
    footerActionLink: 'text-[hsl(40_96%_60%)] font-semibold',
    footerActionText: 'text-[hsl(216_18%_66%)]',
    dividerText: 'text-[hsl(216_18%_62%)]',
    identityPreviewEditButton: 'text-[hsl(40_96%_60%)]',
    formFieldSuccessText: 'text-[hsl(152_55%_66%)]',
    alertText: 'text-[hsl(40_30%_94%)]',
    logoBox: 'justify-center',
    logoImage: 'h-12 w-12',
    socialButtonsBlockButton: 'bg-[hsl(219_33%_14%)] border border-[hsl(218_32%_22%)]',
    formButtonPrimary: 'bg-[hsl(40_96%_56%)] text-[hsl(222_50%_8%)] font-bold uppercase tracking-wider',
    formFieldInput: 'bg-[hsl(222_45%_8%)] border border-[hsl(218_30%_24%)] text-[hsl(40_30%_94%)]',
    footerAction: 'bg-transparent',
    dividerLine: 'bg-[hsl(218_32%_20%)]',
    alert: 'bg-[hsl(4_74%_56%/.1)] border border-[hsl(4_74%_56%/.4)]',
    otpCodeFieldInput: 'bg-[hsl(222_45%_8%)] border border-[hsl(218_30%_24%)] text-[hsl(40_30%_94%)]',
    formFieldRow: 'gap-2',
    main: 'gap-5',
  },
};

function AuthFrame({ children }: { children: ReactNode }) {
  return (
    <div className="relative grid min-h-[100dvh] lg:grid-cols-[1.1fr_1fr]">
      <div className="yardlines relative hidden flex-col justify-between overflow-hidden border-r border-border p-10 lg:flex">
        <Link href="/"><Logo /></Link>
        <div>
          <div className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">Every era. One draft.</div>
          <h1 className="mt-3 font-display text-7xl font-extrabold uppercase leading-[0.9]">
            Draft the<br />legends.<br /><span className="text-primary">Lock the name.</span>
          </h1>
          <p className="mt-5 max-w-md text-muted-foreground">Pick one season of any player and that identity belongs to your team for the life of the league. Nobody else gets him. Not even after you drop him.</p>
        </div>
        <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Private leagues · 2 to 12 teams · 15-round snake</div>
      </div>
      <div className="flex items-center justify-center px-4 py-10">
        <div className="w-full">
          <div className="mb-6 flex justify-center lg:hidden"><Link href="/"><Logo /></Link></div>
          {children}
        </div>
      </div>
    </div>
  );
}

function SignInPage() {
  return (
    <AuthFrame>
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </AuthFrame>
  );
}

function SignUpPage() {
  return (
    <AuthFrame>
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </AuthFrame>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function SampleHome() {
  return (
    <LeagueShell id={SAMPLE_ID} tab="">
      {(c) => (
        <>
          <div className="relative mb-5 overflow-hidden rounded-xl border border-primary/30 bg-[linear-gradient(110deg,hsl(221_50%_12%),hsl(222_47%_8%))] p-5 sm:p-7">
            <div className="yardlines pointer-events-none absolute inset-0 opacity-50" />
            <div className="relative flex flex-wrap items-end gap-5">
              <div className="max-w-2xl">
                <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">Fantasy football. Every era. One draft.</div>
                <h1 className="mt-2 font-display text-4xl font-extrabold uppercase leading-[0.95] sm:text-6xl">
                  One season drafted.<br /><span className="text-primary">One identity locked.</span>
                </h1>
                <p className="mt-3 text-sm text-muted-foreground sm:text-base">This is a live look at a sample league. Draft any player-season from any era into your private league, and that player's name is reserved for your team, permanently.</p>
              </div>
              <div className="flex gap-2">
                <Link href="/sign-up" data-testid="link-hero-create" className="rounded-md bg-primary px-5 py-2.5 font-bold text-primary-foreground transition-transform hover:-translate-y-0.5">Create your league</Link>
                <Link href="/sign-in" data-testid="link-hero-sign-in" className="rounded-md border border-border bg-secondary/60 px-5 py-2.5 font-semibold">Sign in</Link>
              </div>
            </div>
          </div>
          <DashboardBody c={c} />
        </>
      )}
    </LeagueShell>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/leagues" />
      </Show>
      <Show when="signed-out">
        <SampleHome />
      </Show>
    </>
  );
}

function LeaguesGate() {
  const search = useSearch();
  const back = `${basePath}/leagues${search ? `?${search}` : ''}`;
  return (
    <>
      <Show when="signed-in">
        <LeaguesPage />
      </Show>
      <Show when="signed-out">
        <Redirect to={`/sign-in?redirect_url=${encodeURIComponent(back)}`} />
      </Show>
    </>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/leagues" component={LeaguesGate} />
        <Route path="/mock-lab" component={MockLabPage} />
        <Route path="/mock-lab/:id" component={MockRoomPage} />
        <Route path="/league/:id" component={DashboardPage} />
        <Route path="/league/:id/draft" component={DraftPage} />
        <Route path="/league/:id/players" component={PlayersPage} />
        <Route path="/league/:id/rosters" component={RostersPage} />
        <Route path="/league/:id/settings" component={SettingsPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Back to the war room', subtitle: 'Sign in to run your CLASSIC league' } },
        signUp: { start: { title: 'Claim your seat', subtitle: 'Create an account to start or join a league' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
