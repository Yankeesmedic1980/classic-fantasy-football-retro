import { pgTable, text, jsonb, timestamp, integer, boolean, primaryKey, uniqueIndex, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Deliberately no foreign keys to live leagues, players, or permanent locks.
export const mockSessionsTable = pgTable("classic_mock_sessions", {
  id: text("id").primaryKey(),
  inviteCode: text("invite_code").notNull().unique(),
  state: jsonb("state").notNull(),
  nextActionAt: timestamp("next_action_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, t => [index("classic_mock_due").on(t.nextActionAt)]);
export const insertMockSessionSchema = createInsertSchema(mockSessionsTable);
export type MockSessionRecord = typeof mockSessionsTable.$inferSelect;

export const mockPicksTable = pgTable("classic_mock_picks", {
  mockId: text("mock_id").notNull().references(() => mockSessionsTable.id),
  canonicalId: text("canonical_id").notNull(),
  playerId: text("player_id").notNull(),
  teamId: text("team_id").notNull(),
  pickNumber: integer("pick_number").notNull(),
  slot: text("slot").notNull(),
  automated: boolean("automated").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
}, t => [
  primaryKey({ columns: [t.mockId, t.canonicalId] }),
  uniqueIndex("classic_mock_pick_number").on(t.mockId, t.pickNumber),
]);
export const insertMockPickSchema = createInsertSchema(mockPicksTable);
export type MockPickRecord = typeof mockPicksTable.$inferSelect;
