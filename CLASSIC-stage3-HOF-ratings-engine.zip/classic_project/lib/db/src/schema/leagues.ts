import { pgTable, text, jsonb, timestamp, primaryKey, boolean, integer, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// League row is the aggregate transaction boundary. Every league write first
// locks this row; identity locks are also protected by a composite primary key.
export const leaguesTable = pgTable("classic_leagues", {
  id: text("id").primaryKey(),
  inviteCode: text("invite_code").notNull().unique(),
  state: jsonb("state").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export const insertLeagueSchema = createInsertSchema(leaguesTable);
export type LeagueRecord = typeof leaguesTable.$inferSelect;

export const identityLocksTable = pgTable("classic_identity_locks", {
  leagueId: text("league_id").notNull().references(() => leaguesTable.id),
  canonicalId: text("canonical_id").notNull(),
  playerId: text("player_id").notNull(),
  teamId: text("team_id").notNull(),
  active: boolean("active").notNull().default(true),
  slot: text("slot").notNull(),
  pickNumber: integer("pick_number"),
}, (table) => [
  primaryKey({ columns: [table.leagueId, table.canonicalId] }),
  uniqueIndex("classic_unique_draft_pick").on(table.leagueId, table.pickNumber),
]);
export const insertIdentityLockSchema = createInsertSchema(identityLocksTable);
export type IdentityLockRecord = typeof identityLocksTable.$inferSelect;
