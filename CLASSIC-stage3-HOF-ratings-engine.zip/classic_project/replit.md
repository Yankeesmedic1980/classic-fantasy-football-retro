# CLASSIC — Fantasy Football Retro Edition

Private multiplayer historical fantasy-football leagues. Tagline: “Fantasy football. Every era. One draft.”

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API service, through its managed workflow.
- `pnpm --filter @workspace/classic run dev` — web app, through its managed workflow.
- `pnpm run typecheck` — full workspace typecheck.
- `pnpm --filter @workspace/api-server test` — database-backed domain and concurrency tests. Uses temporary fixtures and cleans them up; never run against production.
- `pnpm --filter @workspace/api-spec run codegen` — regenerate client hooks and server validation after contract changes.
- `pnpm --filter @workspace/db run push` — apply development schema. Publish manages production schema changes; no startup migrations.
- Runtime configuration: integrated PostgreSQL and Replit-managed Clerk. Never print credentials.

## Stack and Map

- pnpm monorepo, React/Vite, Wouter, Tailwind, React Query; Express, PostgreSQL/Drizzle, Zod.
- `artifacts/classic/` — responsive web app at `/`.
- `artifacts/api-server/src/routes/classic.ts` — authenticated API routes at `/api`.
- `artifacts/api-server/src/lib/classic-{model,store,actions,sample}.ts` — domain rules, persistence, actions, labeled sample records.
- `lib/db/src/schema/leagues.ts` — database schema.
- `lib/api-spec/openapi.yaml` — API source of truth.
- `artifacts/classic/src/index.css` — navy/slate/gold theme.

## User Requirements

- First deliverable is a deployable private multiplayer league playtest, not a local-only prototype or visual mockup.
- Prioritize shared drafts and permanent identity locks. Never use localStorage as league persistence.
- Original CLASSIC branding; do not copy Sleeper.
- Up to 12 managers; 15-round snake draft. QB1, RB2, WR2, TE1, FLEX1, K1, DEF1, Bench6.
- A canonical identity is exclusive per league regardless of season, survives dropping, transfers with a trade, and is independently available in other leagues.
- Sample data must never be represented as verified historical records.

## Decisions and Boundaries

- League state is an aggregate serialized by a PostgreSQL row lock. Every league mutation (including join) uses that boundary. A separate `(league_id, canonical_id)` primary key independently prevents duplicate identities.
- All acquisition-changing operations must update both the aggregate and permanent identity-lock records in one transaction. No app route deletes identity locks.
- Draft pick numbers remain immutable on acquisition records, including after dropping or trading. Activity records retain the original selection event.
- User creates a league and becomes its commissioner without hardcoded privileged accounts. Other managers join through a high-entropy invitation code.
- Browser authentication is Clerk session cookies. Do not introduce bearer-token handling or local passwords. Keep the canonical Clerk proxy before body parsers.
- Shared screens poll every three seconds; do not claim socket-based synchronization or manager presence.
- Production eligibility requires a non-sample record with both retirement and season approval attested by the commissioner. There is no external historical statistics/retirement verification provider.
- Player pools are league-scoped: commissioners manage the records they trust for their league. All seasons must reuse a canonical ID.
- Trades are consensual one-for-one, accepted by the receiving manager after the draft. Ownership and both locks transfer atomically.
- Waiver windows begin when the first pending claim is submitted for an identity; competing claims in that window share its deadline. Commissioner processes matured claims using rolling priority; zero-hour configuration enables free agency.
- JSON export is a one-time commissioner data download, not an automated database backup or restore facility.

## Mock Draft Lab Boundaries

- Mock drafts are practice sessions, not real leagues. Never write their picks, queues, locks, restarts, or CPU/timer actions to live league tables or permanent identity locks.
- Keep mock identity exclusion per session at the database layer, not only in the UI. Reuse pure snake-order and roster rules without changing live draft behavior.
- Default mock player records are explicitly illustrative and unverified. An approved-player source copies a member league's eligible records without mutating its pool or transactions.
- Restart means a fresh session; preserve the old session's selections and completed results. Pause an unfinished original so it does not keep drafting unexpectedly.
- Mock automation uses deterministic positional heuristics, not predictive AI. Persist turn deadlines, serialize session mutations, and use due-time catch-up after host restarts or idle periods.

## Verification

Initial backend tests cover snake order, cross-season exclusion, permanent drops, independent leagues, atomic trades, production eligibility, permissions, waivers, lineup capacity, concurrent draft requests, and database uniqueness. Public screens were visually inspected; signed-in browser flows still require an authenticated playtest and are not claimed to have been browser-tested.
